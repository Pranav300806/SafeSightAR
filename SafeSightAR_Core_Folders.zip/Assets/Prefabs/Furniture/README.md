# SmartSpace AR - Furniture Prefabs Directory

This directory stores reusable furniture prefabs for SmartSpace AR:
- `Chair.prefab`: Ergonomic Scandinavian accent chair
- `Sofa.prefab`: Modern 3-seater living room couch
- `Table.prefab`: Scandinavian dining and study table
- `Bed.prefab`: Platform queen bed with headboard
- `Cabinet.prefab`: Mid-century 2-door storage cabinet
- `Bookshelf.prefab`: 5-tier architectural bookshelf
- `Lamp.prefab`: Minimalist floor lamp
- `Plant.prefab`: Potted indoor monstera floor plant

Note: `FurnitureManager.cs` includes procedural fallbacks that automatically generate stylish, scaled 3D models with bottom-center pivots if external FBX models are not provided.
