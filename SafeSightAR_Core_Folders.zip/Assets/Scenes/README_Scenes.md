# SafeSight AR Unity Scene Configurations

This project includes two main pre-configured scenes:

### 1. `Simulation_Test.unity` (Desktop Virtual Room Sandbox)
- **Main Camera / Simulated Camera Feeder**: Contains `SimulatedCameraFeed.cs` capturing 640x640 frame textures at 30 FPS.
- **Environment Hierarchy**:
  - `Desk` (Box Collider, Y = 0.75m)
  - `Laptop` (Target Label: "laptop")
  - `WaterBottle` (Target Label: "bottle", draggable object)
  - `Knife` (Target Label: "knife", draggable object near edge)
  - `Drawer` (Target Label: "drawer", open/close state toggler)
  - `Cable` (Target Label: "cable", floor path crossing)
  - `Walkway` (Floor Walkway Bounds Y = 0m)
- **System Controllers**:
  - `[SystemManager]` attached with:
    - `YOLOInferenceEngine.cs`
    - `SpatialRelationshipAnalyzer.cs`
    - `RiskEvaluator.cs`
    - `HazardSimulatorController.cs`
    - `HazardHUD.cs`
    - `ARHazardOverlay.cs`

### 2. `MobileAR_Main.unity` (Hardware AR Foundation / ARCore Mode)
- **AR Session & Session Origin**: `ARCameraManager`, `ARRaycastManager`, `ARPlaneManager`.
- **Plane Anchors**: Real-world surface plane detection for anchoring 3D spatial warning cards.
- **Live Camera Feed**: Feeds live mobile camera frames into `YOLOInferenceEngine.cs`.
