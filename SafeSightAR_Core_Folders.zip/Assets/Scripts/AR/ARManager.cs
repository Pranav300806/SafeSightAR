using System;
using UnityEngine;

namespace SmartSpaceAR.AR
{
    public enum ExecutionMode
    {
        MobileAR,
        DesktopSimulation
    }

    /// <summary>
    /// AR Manager coordinating AR Foundation XR Origin, camera streams, plane tracking,
    /// and mode switching between Mobile AR and desktop 3D in-editor simulation.
    /// Operates completely locally in-memory with zero localhost or network processes.
    /// </summary>
    [DefaultExecutionOrder(-120)]
    public class ARManager : MonoBehaviour
    {
        [Header("System Execution Mode")]
        [SerializeField] private ExecutionMode currentMode = ExecutionMode.DesktopSimulation;

        [Header("AR Foundation References")]
        [Tooltip("Active AR camera or fallback simulation camera.")]
        [SerializeField] private Camera activeCamera;

        [Tooltip("XR Origin / AR Session Origin root transform.")]
        [SerializeField] private Transform arSessionOrigin;

        [Tooltip("Optional AR Session component GameObject.")]
        [SerializeField] private GameObject arSessionObject;

        [Header("Desktop Simulation Rig")]
        [Tooltip("Simulated room rig GameObject activated during desktop testing.")]
        [SerializeField] private GameObject desktopRoomRig;

        public static ARManager Instance { get; private set; }
        public ExecutionMode CurrentMode => currentMode;
        public Camera ActiveCamera => activeCamera != null ? activeCamera : Camera.main;

        public event Action<ExecutionMode> OnModeChanged;

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
                return;
            }

            if (activeCamera == null)
            {
                activeCamera = Camera.main ?? FindFirstObjectByType<Camera>();
            }

            ConfigureSystemMode();
        }

        public void SetMode(ExecutionMode mode)
        {
            currentMode = mode;
            ConfigureSystemMode();
            OnModeChanged?.Invoke(currentMode);
        }

        private void ConfigureSystemMode()
        {
            bool isSim = (currentMode == ExecutionMode.DesktopSimulation);

            if (desktopRoomRig != null)
            {
                desktopRoomRig.SetActive(isSim);
            }

            if (arSessionObject != null)
            {
                arSessionObject.SetActive(!isSim);
            }

            if (isSim)
            {
                Debug.Log("[SmartSpace AR] Active Mode: Desktop Virtual Room Simulation (Hardware-Free Testing).");
            }
            else
            {
                Debug.Log("[SmartSpace AR] Active Mode: Mobile AR (AR Foundation / ARCore Plane Tracking).");
            }
        }
    }
}

namespace SafeSightAR.AR
{
    // Alias ensuring compatibility with existing SafeSight AR codebase
    public enum ExecutionMode
    {
        MobileAR = SmartSpaceAR.AR.ExecutionMode.MobileAR,
        DesktopSimulation = SmartSpaceAR.AR.ExecutionMode.DesktopSimulation
    }

    public class ARManager : SmartSpaceAR.AR.ARManager
    {
    }
}
