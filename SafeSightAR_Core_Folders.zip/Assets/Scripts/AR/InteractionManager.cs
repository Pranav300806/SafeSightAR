using System;
using UnityEngine;
using UnityEngine.EventSystems;
using SmartSpaceAR.Furniture;

namespace SmartSpaceAR.AR
{
    /// <summary>
    /// Interaction Manager handling mobile touch gestures (1-finger drag, 2-finger twist rotation, 2-finger pinch scale)
    /// and mouse/keyboard desktop fallbacks for testing in the Unity Editor.
    /// </summary>
    public class InteractionManager : MonoBehaviour
    {
        [Header("Touch Gesture Sensitivity")]
        [SerializeField] private float rotationSensitivity = 0.4f;
        [SerializeField] private float pinchScaleSensitivity = 0.005f;
        [SerializeField] private float minUniformScale = 0.35f;
        [SerializeField] private float maxUniformScale = 2.5f;

        [Header("Plane Snapping")]
        [SerializeField] private LayerMask surfaceLayerMask = ~0;

        private Camera activeCam;
        private GameObject targetObject;
        private Vector3 initialScale;
        private float initialDistance;
        private float initialAngle;

        private void Start()
        {
            activeCam = ARManager.Instance != null ? ARManager.Instance.ActiveCamera : (Camera.main ?? FindFirstObjectByType<Camera>());
        }

        private void Update()
        {
            if (activeCam == null)
            {
                activeCam = ARManager.Instance != null ? ARManager.Instance.ActiveCamera : (Camera.main ?? FindFirstObjectByType<Camera>());
                if (activeCam == null) return;
            }

            targetObject = FurnitureManager.Instance != null ? FurnitureManager.Instance.ActiveSelectedObject : null;

            if (Application.isMobilePlatform)
            {
                HandleMobileTouchGestures();
            }
        }

        #region Mobile Multi-Touch Gestures

        private void HandleMobileTouchGestures()
        {
            if (targetObject == null) return;

            // 1. Single Finger Drag (Reposition along horizontal floor plane)
            if (Input.touchCount == 1)
            {
                Touch touch = Input.GetTouch(0);

                if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                {
                    return;
                }

                if (touch.phase == TouchPhase.Moved)
                {
                    Ray ray = activeCam.ScreenPointToRay(touch.position);
                    if (Physics.Raycast(ray, out RaycastHit hit, 30f, surfaceLayerMask))
                    {
                        targetObject.transform.position = new Vector3(hit.point.x, targetObject.transform.position.y, hit.point.z);
                    }
                }
            }
            // 2. Two-Finger Gestures (Pinch Scale + Twist Rotation)
            else if (Input.touchCount == 2)
            {
                Touch t0 = Input.GetTouch(0);
                Touch t1 = Input.GetTouch(1);

                Vector2 pos0 = t0.position;
                Vector2 pos1 = t1.position;

                float currentDistance = Vector2.Distance(pos0, pos1);
                float currentAngle = Mathf.Atan2(pos1.y - pos0.y, pos1.x - pos0.x) * Mathf.Rad2Deg;

                if (t0.phase == TouchPhase.Began || t1.phase == TouchPhase.Began)
                {
                    initialDistance = currentDistance;
                    initialAngle = currentAngle;
                    initialScale = targetObject.transform.localScale;
                }
                else if (t0.phase == TouchPhase.Moved || t1.phase == TouchPhase.Moved)
                {
                    // Twist Rotation around vertical Up axis
                    float angleDelta = Mathf.DeltaAngle(initialAngle, currentAngle);
                    targetObject.transform.Rotate(Vector3.up, -angleDelta * rotationSensitivity, Space.World);
                    initialAngle = currentAngle;

                    // Pinch Scale
                    float distDelta = currentDistance - initialDistance;
                    float scaleFactor = 1.0f + (distDelta * pinchScaleSensitivity);
                    Vector3 newScale = initialScale * scaleFactor;

                    float clampedX = Mathf.Clamp(newScale.x, minUniformScale, maxUniformScale);
                    targetObject.transform.localScale = Vector3.one * clampedX;
                }
            }
        }

        #endregion
    }
}
