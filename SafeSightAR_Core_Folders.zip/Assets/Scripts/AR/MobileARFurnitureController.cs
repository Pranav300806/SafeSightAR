using System;
using System.Collections.Generic;
using UnityEngine;

namespace SafeSightAR.AR
{
    public enum FurnitureType
    {
        Sofa,
        Chair,
        Desk,
        Drawer,
        Lamp,
        CoffeeTable
    }

    [Serializable]
    public class PlacedFurniture
    {
        public string id;
        public FurnitureType type;
        public string displayName;
        public GameObject instance;
        public float clearanceRadius;
        public LineRenderer boundaryLine;
    }

    /// <summary>
    /// Runtime Controller for Mobile AR Furniture Placement and SafeSight Spatial Clearance.
    /// Works seamlessly on mobile devices (touch input / ARCore) and inside Unity Editor (mouse / simulation).
    /// </summary>
    public class MobileARFurnitureController : MonoBehaviour
    {
        [Header("AR Camera & Surface Settings")]
        [SerializeField] private Camera mainCamera;
        [SerializeField] private LayerMask floorLayerMask = ~0;
        [SerializeField] private float walkwaySafetyClearance = 0.50f; // 50 cm

        [Header("Materials & Colors")]
        [SerializeField] private Color safeColor = new Color(0.1f, 0.9f, 0.4f, 0.8f);
        [SerializeField] private Color warningColor = new Color(1.0f, 0.2f, 0.2f, 0.9f);
        [SerializeField] private Color reticleColor = new Color(0.2f, 0.8f, 1.0f, 0.7f);

        // Runtime State
        private FurnitureType selectedType = FurnitureType.Sofa;
        private GameObject reticleObj;
        private Vector3 currentReticlePos = new Vector3(0, 0.005f, 1.2f);
        private float currentRotationDeg = 0f;
        private PlacedFurniture selectedFurniture = null;
        private List<PlacedFurniture> placedList = new List<PlacedFurniture>();
        private bool isDragging = false;
        private string activeClearanceWarning = "";

        // Camera Orbit Controls for Editor testing
        private Vector3 cameraTarget = new Vector3(0, 0.4f, 0.5f);
        private float cameraDistance = 2.8f;
        private float cameraYaw = 0f;
        private float cameraPitch = 30f;

        public static MobileARFurnitureController Instance { get; private set; }

        #region Unity Lifecycle

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            if (mainCamera == null) mainCamera = Camera.main;

            CreateARReticle();
        }

        private void Start()
        {
            // Spawn an initial demo sofa to showcase the system immediately
            SpawnFurniture(FurnitureType.Sofa, new Vector3(0, 0, 0), 0);
        }

        private void Update()
        {
            UpdateReticlePosition();
            HandleInput();
            EvaluateClearances();
        }

        #endregion

        #region AR Surface Reticle

        private void CreateARReticle()
        {
            reticleObj = new GameObject("AR_Placement_Reticle");
            
            // Outer Ring using LineRenderer
            LineRenderer lr = reticleObj.AddComponent<LineRenderer>();
            lr.useWorldSpace = false;
            lr.startWidth = 0.02f;
            lr.endWidth = 0.02f;
            lr.loop = true;
            lr.positionCount = 36;
            lr.material = new Material(Shader.Find("Sprites/Default"));
            lr.startColor = reticleColor;
            lr.endColor = reticleColor;

            float radius = 0.35f;
            for (int i = 0; i < 36; i++)
            {
                float angle = i * (360f / 36f) * Mathf.Deg2Rad;
                lr.SetPosition(i, new Vector3(Mathf.Cos(angle) * radius, 0.005f, Mathf.Sin(angle) * radius));
            }

            // Center Point
            GameObject centerDot = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            centerDot.transform.SetParent(reticleObj.transform, false);
            centerDot.transform.localScale = new Vector3(0.06f, 0.002f, 0.06f);
            Destroy(centerDot.GetComponent<Collider>());
            centerDot.GetComponent<Renderer>().material = lr.material;
            centerDot.GetComponent<Renderer>().material.color = reticleColor;

            reticleObj.transform.position = currentReticlePos;
        }

        private void UpdateReticlePosition()
        {
            if (mainCamera == null) return;

            Ray ray;
            if (Application.isMobilePlatform && Input.touchCount > 0)
            {
                ray = mainCamera.ScreenPointToRay(Input.GetTouch(0).position);
            }
            else
            {
                ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            }

            Plane floor = new Plane(Vector3.up, Vector3.zero);
            if (floor.Raycast(ray, out float enter))
            {
                Vector3 hitPoint = ray.GetPoint(enter);
                currentReticlePos = new Vector3(hitPoint.x, 0.005f, hitPoint.z);

                if (reticleObj != null)
                {
                    reticleObj.transform.position = Vector3.Lerp(reticleObj.transform.position, currentReticlePos, Time.deltaTime * 25f);
                }
            }
        }

        #endregion

        #region User Interaction & Manipulation

        private void HandleInput()
        {
            // Mobile Touch Camera Navigation (1-finger drag to orbit, 2-finger pinch to zoom)
            if (Input.touchCount == 1 && !isDragging)
            {
                Touch t = Input.GetTouch(0);
                // Only orbit if touch is above the bottom toolbar (above 130 pixels from bottom)
                if (t.position.y > 130f && t.phase == TouchPhase.Moved)
                {
                    cameraYaw += t.deltaPosition.x * 0.35f;
                    cameraPitch = Mathf.Clamp(cameraPitch - t.deltaPosition.y * 0.25f, 10f, 80f);
                }
            }
            else if (Input.touchCount == 2)
            {
                Touch t0 = Input.GetTouch(0);
                Touch t1 = Input.GetTouch(1);
                if (t0.phase == TouchPhase.Moved || t1.phase == TouchPhase.Moved)
                {
                    float prevDist = Vector2.Distance(t0.position - t0.deltaPosition, t1.position - t1.deltaPosition);
                    float curDist = Vector2.Distance(t0.position, t1.position);
                    float delta = curDist - prevDist;
                    cameraDistance = Mathf.Clamp(cameraDistance - delta * 0.008f, 1.2f, 6.0f);
                }
            }

            // Desktop Camera Navigation (Right Click Orbit, Scroll Zoom)
            if (Input.GetMouseButton(1))
            {
                cameraYaw += Input.GetAxis("Mouse X") * 3.5f;
                cameraPitch = Mathf.Clamp(cameraPitch - Input.GetAxis("Mouse Y") * 3.0f, 10f, 80f);
            }

            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (Mathf.Abs(scroll) > 0.001f)
            {
                cameraDistance = Mathf.Clamp(cameraDistance - scroll * 2.0f, 1.2f, 6.0f);
            }

            // Apply camera orbit transform (Works on both Mobile and Desktop)
            if (mainCamera != null)
            {
                Quaternion rot = Quaternion.Euler(cameraPitch, cameraYaw, 0);
                Vector3 offset = rot * new Vector3(0, 0, -cameraDistance);
                mainCamera.transform.position = cameraTarget + offset;
                mainCamera.transform.LookAt(cameraTarget);
            }

            // Object Selection or Floor Tap-to-Place
            if (Input.GetMouseButtonDown(0))
            {
                // Prevent raycasting through the bottom GUI toolbar (bottom 110 pixels)
                if (Input.mousePosition.y < 110f) return;

                Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

                // 1. Check if clicking an existing placed furniture item to select / drag it
                if (Physics.Raycast(ray, out RaycastHit hit))
                {
                    PlacedFurniture clicked = placedList.Find(p => p.instance == hit.collider.gameObject || hit.collider.transform.IsChildOf(p.instance.transform));
                    if (clicked != null)
                    {
                        SelectFurniture(clicked);
                        isDragging = true;
                        return;
                    }
                }

                // 2. Direct Tap-to-Place on floor surface!
                Plane floor = new Plane(Vector3.up, Vector3.zero);
                if (floor.Raycast(ray, out float enter))
                {
                    Vector3 floorClickPos = ray.GetPoint(enter);
                    SpawnFurniture(selectedType, floorClickPos, currentRotationDeg);
                    return;
                }
            }

            // Drag repositioning along floor
            if (isDragging && selectedFurniture != null && Input.GetMouseButton(0))
            {
                selectedFurniture.instance.transform.position = new Vector3(currentReticlePos.x, 0, currentReticlePos.z);
            }

            if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;
            }

            // Keyboard Shortcuts
            if (Input.GetKeyDown(KeyCode.Space)) PlaceSelectedAtReticle();
            if (Input.GetKeyDown(KeyCode.T)) SpawnFurniture(FurnitureType.CoffeeTable, currentReticlePos, currentRotationDeg);
            if (Input.GetKeyDown(KeyCode.D)) SpawnFurniture(FurnitureType.Desk, currentReticlePos, currentRotationDeg);
            if (Input.GetKeyDown(KeyCode.S)) SpawnFurniture(FurnitureType.Sofa, currentReticlePos, currentRotationDeg);
            if (Input.GetKeyDown(KeyCode.C)) SpawnFurniture(FurnitureType.Chair, currentReticlePos, currentRotationDeg);
            if (Input.GetKeyDown(KeyCode.R)) RotateSelected(45f);
            if (Input.GetKeyDown(KeyCode.Delete) || Input.GetKeyDown(KeyCode.Backspace)) DeleteSelected();
        }

        #endregion

        #region Furniture Factory & Placement

        public void PlaceSelectedAtReticle()
        {
            SpawnFurniture(selectedType, currentReticlePos, currentRotationDeg);
        }

        public PlacedFurniture SpawnFurniture(FurnitureType type, Vector3 position, float rotationDeg)
        {
            GameObject model = CreateProceduralModel(type);
            model.transform.position = new Vector3(position.x, 0, position.z);
            model.transform.rotation = Quaternion.Euler(0, rotationDeg, 0);

            PlacedFurniture pf = new PlacedFurniture
            {
                id = $"{type}_{Guid.NewGuid().ToString().Substring(0, 5)}",
                type = type,
                displayName = GetDisplayName(type),
                instance = model,
                clearanceRadius = GetClearanceRadius(type)
            };

            // Add Ground Clearance Ring
            GameObject ringObj = new GameObject("Clearance_Ring");
            ringObj.transform.SetParent(model.transform, false);
            LineRenderer lr = ringObj.AddComponent<LineRenderer>();
            lr.useWorldSpace = false;
            lr.startWidth = 0.015f;
            lr.endWidth = 0.015f;
            lr.loop = true;
            lr.positionCount = 32;
            lr.material = new Material(Shader.Find("Sprites/Default"));
            lr.startColor = safeColor;
            lr.endColor = safeColor;

            float r = pf.clearanceRadius;
            for (int i = 0; i < 32; i++)
            {
                float ang = i * (360f / 32f) * Mathf.Deg2Rad;
                lr.SetPosition(i, new Vector3(Mathf.Cos(ang) * r, 0.01f, Mathf.Sin(ang) * r));
            }
            pf.boundaryLine = lr;

            placedList.Add(pf);
            SelectFurniture(pf);

            return pf;
        }

        public void SelectFurniture(PlacedFurniture pf)
        {
            selectedFurniture = pf;
            if (pf != null)
            {
                currentRotationDeg = pf.instance.transform.eulerAngles.y;
            }
        }

        public void RotateSelected(float deltaAngle)
        {
            if (selectedFurniture != null)
            {
                currentRotationDeg = (currentRotationDeg + deltaAngle) % 360f;
                selectedFurniture.instance.transform.rotation = Quaternion.Euler(0, currentRotationDeg, 0);
            }
        }

        public void DeleteSelected()
        {
            if (selectedFurniture != null)
            {
                placedList.Remove(selectedFurniture);
                Destroy(selectedFurniture.instance);
                selectedFurniture = null;
            }
        }

        public void ClearAll()
        {
            for (int i = 0; i < placedList.Count; i++)
            {
                if (placedList[i] != null && placedList[i].instance != null)
                {
                    Destroy(placedList[i].instance);
                }
            }
            placedList.Clear();
            selectedFurniture = null;
        }

        #endregion

        #region SafeSight Spatial Clearance Engine

        private void EvaluateClearances()
        {
            activeClearanceWarning = "";
            bool hasHazard = false;

            for (int i = 0; i < placedList.Count; i++)
            {
                bool itemHasRisk = false;
                PlacedFurniture a = placedList[i];

                for (int j = 0; j < placedList.Count; j++)
                {
                    if (i == j) continue;
                    PlacedFurniture b = placedList[j];

                    float centerDist = Vector3.Distance(a.instance.transform.position, b.instance.transform.position);
                    float edgeDist = centerDist - (a.clearanceRadius + b.clearanceRadius);

                    if (edgeDist < walkwaySafetyClearance)
                    {
                        itemHasRisk = true;
                        hasHazard = true;
                        activeClearanceWarning = $"⚠️ Walkway Obstruction: {a.displayName} and {b.displayName} are too close ({Mathf.Max(0, edgeDist * 100f):F0} cm). Safe clearance is 50 cm.";
                    }
                }

                // Update boundary line colors
                if (a.boundaryLine != null)
                {
                    Color targetColor = itemHasRisk ? warningColor : safeColor;
                    a.boundaryLine.startColor = targetColor;
                    a.boundaryLine.endColor = targetColor;
                }
            }
        }

        #endregion

        #region 3D Furniture Procedural Modeling

        private GameObject CreateProceduralModel(FurnitureType type)
        {
            GameObject root = new GameObject($"Furniture_{type}");

            Material darkWood = CreateMat(new Color(0.2f, 0.12f, 0.08f), 0.3f);
            Material fabricSlate = CreateMat(new Color(0.22f, 0.28f, 0.38f), 0.8f);
            Material metal = CreateMat(new Color(0.7f, 0.72f, 0.75f), 0.2f, 0.85f);
            Material lampGlow = CreateMat(new Color(1f, 0.95f, 0.75f), 0.1f);

            switch (type)
            {
                case FurnitureType.Sofa:
                    // Nordic Sofa (1.8m x 0.8m x 0.75m)
                    CreateBox(root, new Vector3(0, 0.25f, 0), new Vector3(1.7f, 0.25f, 0.8f), fabricSlate);
                    CreateBox(root, new Vector3(0, 0.55f, -0.3f), new Vector3(1.7f, 0.45f, 0.2f), fabricSlate);
                    CreateBox(root, new Vector3(-0.85f, 0.40f, 0), new Vector3(0.18f, 0.35f, 0.8f), fabricSlate);
                    CreateBox(root, new Vector3(0.85f, 0.40f, 0), new Vector3(0.18f, 0.35f, 0.8f), fabricSlate);
                    break;

                case FurnitureType.Chair:
                    // Ergonomic Office Chair (0.6m x 0.6m x 0.95m)
                    CreateBox(root, new Vector3(0, 0.45f, 0), new Vector3(0.5f, 0.06f, 0.5f), fabricSlate);
                    CreateBox(root, new Vector3(0, 0.75f, -0.22f), new Vector3(0.48f, 0.55f, 0.05f), fabricSlate);
                    CreateCylinder(root, new Vector3(0, 0.20f, 0), new Vector3(0.04f, 0.20f, 0.04f), metal);
                    CreateCylinder(root, new Vector3(0, 0.02f, 0), new Vector3(0.35f, 0.02f, 0.35f), metal);
                    break;

                case FurnitureType.Desk:
                    // Executive Work Desk (1.5m x 0.75m x 0.75m)
                    CreateBox(root, new Vector3(0, 0.75f, 0), new Vector3(1.5f, 0.05f, 0.75f), darkWood);
                    CreateBox(root, new Vector3(-0.68f, 0.36f, -0.32f), new Vector3(0.05f, 0.72f, 0.05f), metal);
                    CreateBox(root, new Vector3(0.68f, 0.36f, -0.32f), new Vector3(0.05f, 0.72f, 0.05f), metal);
                    CreateBox(root, new Vector3(-0.68f, 0.36f, 0.32f), new Vector3(0.05f, 0.72f, 0.05f), metal);
                    CreateBox(root, new Vector3(0.68f, 0.36f, 0.32f), new Vector3(0.05f, 0.72f, 0.05f), metal);
                    break;

                case FurnitureType.Drawer:
                    // Storage Drawer (0.5m x 0.5m x 0.65m)
                    CreateBox(root, new Vector3(0, 0.325f, 0), new Vector3(0.5f, 0.65f, 0.5f), darkWood);
                    CreateBox(root, new Vector3(0, 0.50f, 0.26f), new Vector3(0.44f, 0.16f, 0.02f), metal);
                    CreateBox(root, new Vector3(0, 0.30f, 0.26f), new Vector3(0.44f, 0.16f, 0.02f), metal);
                    CreateBox(root, new Vector3(0, 0.10f, 0.26f), new Vector3(0.44f, 0.16f, 0.02f), metal);
                    break;

                case FurnitureType.Lamp:
                    // Arc Floor Lamp (0.4m x 0.4m x 1.6m)
                    CreateCylinder(root, new Vector3(0, 0.015f, 0), new Vector3(0.25f, 0.015f, 0.25f), metal);
                    CreateCylinder(root, new Vector3(0, 0.75f, 0), new Vector3(0.025f, 0.75f, 0.025f), metal);
                    CreateCylinder(root, new Vector3(0, 1.45f, 0), new Vector3(0.20f, 0.15f, 0.20f), lampGlow);
                    break;

                case FurnitureType.CoffeeTable:
                    // Coffee Table (0.9m x 0.5m x 0.42m)
                    CreateBox(root, new Vector3(0, 0.42f, 0), new Vector3(0.9f, 0.04f, 0.5f), darkWood);
                    CreateCylinder(root, new Vector3(-0.38f, 0.20f, -0.2f), new Vector3(0.03f, 0.20f, 0.03f), metal);
                    CreateCylinder(root, new Vector3(0.38f, 0.20f, -0.2f), new Vector3(0.03f, 0.20f, 0.03f), metal);
                    CreateCylinder(root, new Vector3(-0.38f, 0.20f, 0.2f), new Vector3(0.03f, 0.20f, 0.03f), metal);
                    CreateCylinder(root, new Vector3(0.38f, 0.20f, 0.2f), new Vector3(0.03f, 0.20f, 0.03f), metal);
                    break;
            }

            // Collider for raycast selection
            BoxCollider col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0, 0.45f, 0);
            col.size = new Vector3(GetClearanceRadius(type) * 1.5f, 0.9f, GetClearanceRadius(type) * 1.5f);

            return root;
        }

        private void CreateBox(GameObject parent, Vector3 localPos, Vector3 size, Material mat)
        {
            GameObject b = GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.transform.SetParent(parent.transform, false);
            b.transform.localPosition = localPos;
            b.transform.localScale = size;
            b.GetComponent<Renderer>().material = mat;
            Destroy(b.GetComponent<Collider>());
        }

        private void CreateCylinder(GameObject parent, Vector3 localPos, Vector3 size, Material mat)
        {
            GameObject c = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            c.transform.SetParent(parent.transform, false);
            c.transform.localPosition = localPos;
            c.transform.localScale = size;
            c.GetComponent<Renderer>().material = mat;
            Destroy(c.GetComponent<Collider>());
        }

        private Material CreateMat(Color c, float rough = 0.5f, float metal = 0.0f)
        {
            Material m = new Material(Shader.Find("Standard"));
            m.color = c;
            m.SetFloat("_Glossiness", 1.0f - rough);
            m.SetFloat("_Metallic", metal);
            return m;
        }

        private string GetDisplayName(FurnitureType t)
        {
            switch (t)
            {
                case FurnitureType.Sofa: return "Nordic Sofa";
                case FurnitureType.Chair: return "Ergonomic Chair";
                case FurnitureType.Desk: return "Executive Desk";
                case FurnitureType.Drawer: return "Modular Drawer";
                case FurnitureType.Lamp: return "Arc Floor Lamp";
                case FurnitureType.CoffeeTable: return "Coffee Table";
                default: return "Furniture";
            }
        }

        private float GetClearanceRadius(FurnitureType t)
        {
            switch (t)
            {
                case FurnitureType.Sofa: return 0.95f;
                case FurnitureType.Desk: return 0.85f;
                case FurnitureType.CoffeeTable: return 0.55f;
                case FurnitureType.Chair: return 0.45f;
                case FurnitureType.Drawer: return 0.45f;
                case FurnitureType.Lamp: return 0.30f;
                default: return 0.5f;
            }
        }

        #endregion

        #region OnGUI Mobile AR Dashboard

        private void OnGUI()
        {
            float screenW = Screen.width;
            float screenH = Screen.height;

            // 1. Top Header Banner (Responsive width)
            float topBannerW = Mathf.Min(screenW - 160f, 380f);
            GUI.Box(new Rect(15, 15, topBannerW, 50), GUIContent.none);
            GUIStyle titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 13, fontStyle = FontStyle.Bold };
            titleStyle.normal.textColor = Color.cyan;
            GUI.Label(new Rect(25, 20, topBannerW - 20, 20), "📱 SafeSight AR · Mobile Furniture Rig", titleStyle);

            GUIStyle statusStyle = new GUIStyle(GUI.skin.label) { fontSize = 11 };
            statusStyle.normal.textColor = Color.green;
            GUI.Label(new Rect(25, 40, topBannerW - 20, 20), "● AR Surface Detected · Ready to Place", statusStyle);

            // Top-Right Scene Switcher Button
            GUI.color = new Color(0.3f, 0.85f, 1.0f);
            if (GUI.Button(new Rect(screenW - 145, 15, 130, 45), "<b>🔬 Hazard Sim</b>"))
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene("AntiGravity_Simulation");
            }
            GUI.color = Color.white;

            // 2. Active Clearance Hazard Warning Banner
            if (!string.IsNullOrEmpty(activeClearanceWarning))
            {
                GUI.color = new Color(1f, 0.2f, 0.2f, 0.95f);
                float warnW = Mathf.Min(screenW - 30f, 480f);
                GUI.Box(new Rect(15, 75, warnW, 40), GUIContent.none);
                GUIStyle warnStyle = new GUIStyle(GUI.skin.label) { fontSize = 11, fontStyle = FontStyle.Bold };
                warnStyle.normal.textColor = Color.yellow;
                GUI.Label(new Rect(25, 80, warnW - 20, 30), activeClearanceWarning, warnStyle);
                GUI.color = Color.white;
            }

            // 3. Bottom Furniture Catalog Bar (Fully Responsive on any mobile screen)
            float barW = Mathf.Clamp(screenW - 20f, 320f, 680f);
            float barH = 110f;
            float barX = (screenW - barW) * 0.5f;
            float barY = screenH - barH - 12f;

            GUI.Box(new Rect(barX, barY, barW, barH), GUIContent.none);

            // Placement Instruction Hint
            GUIStyle hintStyle = new GUIStyle(GUI.skin.label) { fontSize = 11, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            hintStyle.normal.textColor = new Color(0.3f, 0.9f, 1.0f);
            GUI.Label(new Rect(barX, barY + 4, barW, 18), $"👉 Tap FLOOR to place <b>{GetDisplayName(selectedType)}</b> | Or click [✨ Place at Reticle]", hintStyle);

            string[] names = { "🛋️ Sofa", "🪑 Chair", "🪵 Desk", "🗄️ Drawer", "💡 Lamp", "☕ Table" };
            FurnitureType[] types = { FurnitureType.Sofa, FurnitureType.Chair, FurnitureType.Desk, FurnitureType.Drawer, FurnitureType.Lamp, FurnitureType.CoffeeTable };

            float btnGap = 4f;
            float btnW = (barW - 20f - (btnGap * (names.Length - 1))) / names.Length;

            for (int i = 0; i < names.Length; i++)
            {
                Rect bRect = new Rect(barX + 10f + (i * (btnW + btnGap)), barY + 26f, btnW, 32f);
                bool isCurSelected = (selectedType == types[i]);
                if (isCurSelected) GUI.color = new Color(0.2f, 0.9f, 1.0f);
                else GUI.color = Color.white;

                if (GUI.Button(bRect, names[i]))
                {
                    if (selectedType == types[i])
                    {
                        PlaceSelectedAtReticle();
                    }
                    else
                    {
                        selectedType = types[i];
                    }
                }
            }

            GUI.color = Color.white;
            // Actions Row (Responsive)
            float actionGap = 6f;
            float totalActionW = barW - 20f;
            float actBtnW = (totalActionW - 85f - (actionGap * 3)) / 4f;

            Rect placeRect = new Rect(barX + 10f, barY + 68f, actBtnW * 1.25f, 30f);
            GUI.color = new Color(0.1f, 1.0f, 0.5f);
            if (GUI.Button(placeRect, "<b>✨ Place</b>")) PlaceSelectedAtReticle();
            GUI.color = Color.white;

            Rect rotRect = new Rect(placeRect.xMax + actionGap, barY + 68f, actBtnW * 0.95f, 30f);
            if (GUI.Button(rotRect, "🔄 Rotate")) RotateSelected(45f);

            Rect delRect = new Rect(rotRect.xMax + actionGap, barY + 68f, actBtnW * 0.9f, 30f);
            if (GUI.Button(delRect, "🗑️ Delete")) DeleteSelected();

            Rect clearRect = new Rect(delRect.xMax + actionGap, barY + 68f, actBtnW * 0.9f, 30f);
            if (GUI.Button(clearRect, "↺ Clear")) ClearAll();

            // Item count
            GUI.Label(new Rect(clearRect.xMax + actionGap, barY + 72f, 75f, 24f), $"<b>Total: {placedList.Count}</b>");
        }

        #endregion
    }
}
