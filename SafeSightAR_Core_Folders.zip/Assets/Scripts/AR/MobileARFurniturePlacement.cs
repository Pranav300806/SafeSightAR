using System;
using System.Collections.Generic;
using UnityEngine;

namespace SafeSightAR.AR
{
    [Serializable]
    public class FurnitureItem
    {
        public string id;
        public string displayName;
        public string category; // "Desk", "Chair", "Drawer", "Sofa", "Lamp"
        public GameObject prefab;
        public Vector3 dimensionsMeters = new Vector3(1.0f, 0.75f, 0.6f);
        public float safetyClearanceRadius = 0.40f; // Minimum safe passage buffer
    }

    /// <summary>
    /// Production Mobile AR Furniture Placement Controller for Unity AR Foundation (ARCore / ARKit).
    /// Features:
    /// 1. Surface plane raycasting & dynamic AR target placement reticle.
    /// 2. Tap-to-place selected 3D furniture from catalog.
    /// 3. Mobile touch gestures: 1-finger drag, 2-finger twist rotation, 2-finger pinch scale.
    /// 4. Live SafeSight clearance envelope checks preventing walkway obstructions.
    /// </summary>
    public class MobileARFurniturePlacement : MonoBehaviour
    {
        [Header("AR References")]
        [SerializeField] private Camera arCamera;
        [SerializeField] private GameObject placementReticlePrefab;
        [SerializeField] private LayerMask planeLayerMask = ~0;

        [Header("Furniture Catalog")]
        [SerializeField] private List<FurnitureItem> furnitureCatalog = new List<FurnitureItem>();
        [SerializeField] private int selectedCatalogIndex = 0;

        [Header("Placement & Manipulation Settings")]
        [SerializeField] private bool snapToTrueScale = true;
        [SerializeField] private float rotationSensitivity = 0.5f;
        [SerializeField] private float minPinchScale = 0.5f;
        [SerializeField] private float maxPinchScale = 2.0f;

        [Header("SafeSight Hazard Feedback")]
        [SerializeField] private Material safeHighlightMaterial;
        [SerializeField] private Material dangerHighlightMaterial;
        [SerializeField] private float walkwayClearanceRequired = 0.50f;

        // Runtime State
        private GameObject activeReticle;
        private Pose currentPlacementPose;
        private bool isPoseValid = false;
        private GameObject selectedPlacedObject = null;
        private List<GameObject> spawnedFurniture = new List<GameObject>();

        // Mobile Touch State
        private float initialPinchDistance;
        private Vector3 initialScale;
        private float initialAngle;

        public static MobileARFurniturePlacement Instance { get; private set; }

        public event Action<GameObject, FurnitureItem> OnFurniturePlaced;
        public event Action<GameObject> OnFurnitureSelected;
        public event Action<bool> OnPlacementValidityChanged;

        #region Unity Lifecycle

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            if (arCamera == null) arCamera = Camera.main;

            InitializeDefaultCatalog();
            CreatePlacementReticle();
        }

        private void Update()
        {
            UpdatePlacementPose();
            UpdateReticleVisual();
            HandleTouchGestures();
        }

        #endregion

        #region AR Reticle & Plane Raycasting

        private void CreatePlacementReticle()
        {
            if (placementReticlePrefab != null)
            {
                activeReticle = Instantiate(placementReticlePrefab);
            }
            else
            {
                // Procedural AR Reticle fallback
                activeReticle = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                activeReticle.name = "AR_Placement_Reticle";
                activeReticle.transform.localScale = new Vector3(0.35f, 0.005f, 0.35f);
                Collider col = activeReticle.GetComponent<Collider>();
                if (col != null) Destroy(col);

                Renderer rend = activeReticle.GetComponent<Renderer>();
                if (rend != null)
                {
                    rend.material.color = new Color(0.2f, 0.8f, 1.0f, 0.5f);
                }
            }

            activeReticle.SetActive(false);
        }

        private void UpdatePlacementPose()
        {
            if (arCamera == null) return;

            Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
            Ray ray = arCamera.ScreenPointToRay(screenCenter);

            // Raycast against physics plane or ground collider (compatible with ARRaycastManager and Physics.Raycast)
            if (Physics.Raycast(ray, out RaycastHit hit, 20f, planeLayerMask))
            {
                currentPlacementPose.position = hit.point;

                // Align upward with detected surface normal, facing camera horizontally
                Vector3 camForward = arCamera.transform.forward;
                Vector3 planeNormal = hit.normal;
                Vector3 projectedForward = Vector3.ProjectOnPlane(camForward, planeNormal).normalized;

                if (projectedForward != Vector3.zero)
                {
                    currentPlacementPose.rotation = Quaternion.LookRotation(projectedForward, planeNormal);
                }
                else
                {
                    currentPlacementPose.rotation = Quaternion.FromToRotation(Vector3.up, planeNormal);
                }

                if (!isPoseValid)
                {
                    isPoseValid = true;
                    OnPlacementValidityChanged?.Invoke(true);
                }
            }
            else
            {
                // Virtual floor projection fallback if no hit
                float groundY = 0f;
                Plane floorPlane = new Plane(Vector3.up, new Vector3(0, groundY, 0));
                if (floorPlane.Raycast(ray, out float enter))
                {
                    currentPlacementPose.position = ray.GetPoint(enter);
                    currentPlacementPose.rotation = Quaternion.Euler(0, arCamera.transform.eulerAngles.y, 0);
                    isPoseValid = true;
                }
                else
                {
                    isPoseValid = false;
                }
            }
        }

        private void UpdateReticleVisual()
        {
            if (activeReticle == null) return;

            if (isPoseValid)
            {
                activeReticle.SetActive(true);
                activeReticle.transform.position = Vector3.Lerp(activeReticle.transform.position, currentPlacementPose.position, Time.deltaTime * 20f);
                activeReticle.transform.rotation = Quaternion.Slerp(activeReticle.transform.rotation, currentPlacementPose.rotation, Time.deltaTime * 20f);
            }
            else
            {
                activeReticle.SetActive(false);
            }
        }

        #endregion

        #region Touch Interaction & Placement

        private void HandleTouchGestures()
        {
            // 1. Single Touch Tap or Drag
            if (Input.touchCount == 1)
            {
                Touch touch = Input.GetTouch(0);

                // Tap to select or place
                if (touch.phase == TouchPhase.Began)
                {
                    Ray touchRay = arCamera.ScreenPointToRay(touch.position);
                    if (Physics.Raycast(touchRay, out RaycastHit hit))
                    {
                        GameObject hitObj = hit.collider.gameObject;
                        if (spawnedFurniture.Contains(hitObj) || spawnedFurniture.Exists(f => hitObj.transform.IsChildOf(f.transform)))
                        {
                            SelectFurniture(FindRootFurniture(hitObj));
                            return;
                        }
                    }

                    // If tapped empty space and reticle is active, place item
                    if (isPoseValid && selectedPlacedObject == null)
                    {
                        PlaceSelectedFurniture();
                    }
                }
                // One-finger drag repositioning
                else if (touch.phase == TouchPhase.Moved && selectedPlacedObject != null)
                {
                    Ray dragRay = arCamera.ScreenPointToRay(touch.position);
                    Plane dragPlane = new Plane(Vector3.up, selectedPlacedObject.transform.position);
                    if (dragPlane.Raycast(dragRay, out float enter))
                    {
                        selectedPlacedObject.transform.position = dragRay.GetPoint(enter);
                        ValidateClearanceForObject(selectedPlacedObject);
                    }
                }
            }
            // 2. Two-finger Gestures: Twist to Rotate & Pinch to Scale
            else if (Input.touchCount == 2)
            {
                if (selectedPlacedObject == null) return;

                Touch touch0 = Input.GetTouch(0);
                Touch touch1 = Input.GetTouch(1);

                if (touch0.phase == TouchPhase.Began || touch1.phase == TouchPhase.Began)
                {
                    initialPinchDistance = Vector2.Distance(touch0.position, touch1.position);
                    initialScale = selectedPlacedObject.transform.localScale;
                    initialAngle = Vector2.SignedAngle(Vector2.right, touch1.position - touch0.position);
                }
                else if (touch0.phase == TouchPhase.Moved || touch1.phase == TouchPhase.Moved)
                {
                    // A. Twist Rotation
                    float currentAngle = Vector2.SignedAngle(Vector2.right, touch1.position - touch0.position);
                    float deltaAngle = currentAngle - initialAngle;
                    selectedPlacedObject.transform.Rotate(Vector3.up, -deltaAngle * rotationSensitivity, Space.World);
                    initialAngle = currentAngle;

                    // B. Pinch Scaling (if not locked to 1:1 true scale)
                    if (!snapToTrueScale)
                    {
                        float currentDist = Vector2.Distance(touch0.position, touch1.position);
                        if (initialPinchDistance > 0.01f)
                        {
                            float scaleFactor = currentDist / initialPinchDistance;
                            Vector3 newScale = initialScale * scaleFactor;
                            float clampedScale = Mathf.Clamp(newScale.x, minPinchScale, maxPinchScale);
                            selectedPlacedObject.transform.localScale = Vector3.one * clampedScale;
                        }
                    }
                }
            }
            // Desktop Mouse Testing Fallback
            else if (Input.GetMouseButtonDown(0) && Application.isEditor)
            {
                if (isPoseValid)
                {
                    PlaceSelectedFurniture();
                }
            }
        }

        /// <summary>
        /// Instantiates the selected furniture from the catalog at the current AR reticle pose.
        /// </summary>
        public GameObject PlaceSelectedFurniture()
        {
            if (selectedCatalogIndex < 0 || selectedCatalogIndex >= furnitureCatalog.Count) return null;

            FurnitureItem item = furnitureCatalog[selectedCatalogIndex];
            GameObject instance;

            if (item.prefab != null)
            {
                instance = Instantiate(item.prefab, currentPlacementPose.position, currentPlacementPose.rotation);
            }
            else
            {
                // Procedural primitive fallback
                instance = CreateProceduralFurniture(item);
                instance.transform.position = currentPlacementPose.position;
                instance.transform.rotation = currentPlacementPose.rotation;
            }

            instance.name = $"{item.displayName}_{spawnedFurniture.Count + 1}";
            spawnedFurniture.Add(instance);
            SelectFurniture(instance);

            OnFurniturePlaced?.Invoke(instance, item);
            ValidateClearanceForObject(instance);

            return instance;
        }

        private void SelectFurniture(GameObject obj)
        {
            selectedPlacedObject = obj;
            OnFurnitureSelected?.Invoke(obj);
        }

        public void DeselectFurniture()
        {
            selectedPlacedObject = null;
            OnFurnitureSelected?.Invoke(null);
        }

        public void DeleteSelectedFurniture()
        {
            if (selectedPlacedObject != null)
            {
                spawnedFurniture.Remove(selectedPlacedObject);
                Destroy(selectedPlacedObject);
                selectedPlacedObject = null;
            }
        }

        public void SetSelectedCatalogIndex(int index)
        {
            if (index >= 0 && index < furnitureCatalog.Count)
            {
                selectedCatalogIndex = index;
            }
        }

        #endregion

        #region SafeSight Spatial Hazard Validation

        /// <summary>
        /// Validates whether the placed furniture has sufficient safe passage clearances
        /// or obstructs room walkways and doorways.
        /// </summary>
        private bool ValidateClearanceForObject(GameObject obj)
        {
            // Check clearance with other placed furniture
            for (int i = 0; i < spawnedFurniture.Count; i++)
            {
                GameObject other = spawnedFurniture[i];
                if (other == null || other == obj) continue;

                float dist = Vector3.Distance(obj.transform.position, other.transform.position);
                if (dist < walkwayClearanceRequired)
                {
                    HighlightClearanceRisk(obj, true);
                    return false;
                }
            }

            HighlightClearanceRisk(obj, false);
            return true;
        }

        private void HighlightClearanceRisk(GameObject obj, bool isAtRisk)
        {
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>();
            Material mat = isAtRisk ? dangerHighlightMaterial : safeHighlightMaterial;

            if (mat == null) return;

            foreach (var r in renderers)
            {
                r.material = mat;
            }
        }

        private GameObject FindRootFurniture(GameObject child)
        {
            Transform curr = child.transform;
            while (curr != null)
            {
                if (spawnedFurniture.Contains(curr.gameObject)) return curr.gameObject;
                curr = curr.parent;
            }
            return child;
        }

        #endregion

        #region Procedural Catalog Fallback

        private void InitializeDefaultCatalog()
        {
            if (furnitureCatalog.Count > 0) return;

            furnitureCatalog.Add(new FurnitureItem { id = "desk_01", displayName = "Executive Desk", category = "Desk", dimensionsMeters = new Vector3(1.4f, 0.75f, 0.8f), safetyClearanceRadius = 0.5f });
            furnitureCatalog.Add(new FurnitureItem { id = "chair_01", displayName = "Ergonomic Chair", category = "Chair", dimensionsMeters = new Vector3(0.6f, 0.95f, 0.6f), safetyClearanceRadius = 0.4f });
            furnitureCatalog.Add(new FurnitureItem { id = "drawer_01", displayName = "Storage Drawer", category = "Drawer", dimensionsMeters = new Vector3(0.5f, 0.60f, 0.5f), safetyClearanceRadius = 0.6f });
            furnitureCatalog.Add(new FurnitureItem { id = "sofa_01", displayName = "Nordic Sofa", category = "Sofa", dimensionsMeters = new Vector3(1.8f, 0.80f, 0.9f), safetyClearanceRadius = 0.6f });
            furnitureCatalog.Add(new FurnitureItem { id = "lamp_01", displayName = "Floor Lamp", category = "Lamp", dimensionsMeters = new Vector3(0.35f, 1.50f, 0.35f), safetyClearanceRadius = 0.3f });
        }

        private GameObject CreateProceduralFurniture(FurnitureItem item)
        {
            GameObject root = new GameObject(item.displayName);

            if (item.category == "Desk")
            {
                GameObject top = GameObject.CreatePrimitive(PrimitiveType.Cube);
                top.transform.SetParent(root.transform, false);
                top.transform.localPosition = new Vector3(0, item.dimensionsMeters.y, 0);
                top.transform.localScale = new Vector3(item.dimensionsMeters.x, 0.05f, item.dimensionsMeters.z);
            }
            else if (item.category == "Chair")
            {
                GameObject seat = GameObject.CreatePrimitive(PrimitiveType.Cube);
                seat.transform.SetParent(root.transform, false);
                seat.transform.localPosition = new Vector3(0, 0.45f, 0);
                seat.transform.localScale = new Vector3(0.5f, 0.06f, 0.5f);

                GameObject back = GameObject.CreatePrimitive(PrimitiveType.Cube);
                back.transform.SetParent(root.transform, false);
                back.transform.localPosition = new Vector3(0, 0.75f, -0.22f);
                back.transform.localScale = new Vector3(0.48f, 0.55f, 0.05f);
            }
            else
            {
                GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
                body.transform.SetParent(root.transform, false);
                body.transform.localPosition = new Vector3(0, item.dimensionsMeters.y * 0.5f, 0);
                body.transform.localScale = item.dimensionsMeters;
            }

            // Add BoxCollider for touch selection
            BoxCollider col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0, item.dimensionsMeters.y * 0.5f, 0);
            col.size = item.dimensionsMeters;

            return root;
        }

        #endregion
    }
}
