using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using SmartSpaceAR.Furniture;

namespace SmartSpaceAR.AR
{
    /// <summary>
    /// Placement Manager handling surface raycasting, dynamic reticle projection,
    /// and furniture prefab instantiation for both Mobile AR and Desktop Simulation modes.
    /// Operates completely locally without external web services.
    /// </summary>
    public class PlacementManager : MonoBehaviour
    {
        [Header("Reticle & Surface Settings")]
        [Tooltip("Prefab or visual game object representing the placement ring.")]
        [SerializeField] private GameObject reticlePrefab;

        [Tooltip("LayerMask for detecting simulation room floors.")]
        [SerializeField] private LayerMask surfaceLayerMask = ~0;

        [Tooltip("Reticle active ring color.")]
        [SerializeField] private Color reticleColor = new Color(0.0f, 0.9f, 1.0f, 0.8f);

        [Header("Raycast Range")]
        [SerializeField] private float maxRayDistance = 30.0f;

        private Camera activeCam;
        private GameObject activeReticle;
        private Pose currentPlacementPose;
        private bool isPoseValid = false;

        public static PlacementManager Instance { get; private set; }
        public Pose CurrentPlacementPose => currentPlacementPose;
        public bool IsPoseValid => isPoseValid;

        public event Action<Pose> OnPlacementPoseUpdated;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            InitializeReticle();
        }

        private void Start()
        {
            activeCam = ARManager.Instance != null ? ARManager.Instance.ActiveCamera : (Camera.main ?? FindFirstObjectByType<Camera>());
        }

        private void Update()
        {
            if (activeCam == null)
            {
                activeCam = ARManager.Instance != null ? ARManager.Instance.ActiveCamera : (Camera.main ?? FindFirstObjectByType<Camera>());
                if (activeCam == null) return;
            }

            UpdatePlacementPose();
            UpdateReticleVisual();
            HandleTouchOrClickPlacement();
        }

        private void InitializeReticle()
        {
            if (reticlePrefab != null)
            {
                activeReticle = Instantiate(reticlePrefab, transform);
            }
            else
            {
                // Procedural Reticle Ring
                activeReticle = new GameObject("[Procedural_Placement_Reticle]");
                activeReticle.transform.SetParent(transform, false);

                LineRenderer lr = activeReticle.AddComponent<LineRenderer>();
                lr.useWorldSpace = false;
                lr.loop = true;
                lr.startWidth = 0.02f;
                lr.endWidth = 0.02f;
                lr.positionCount = 36;

                Material mat = new Material(Shader.Find("Sprites/Default") ?? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Color"));
                mat.color = reticleColor;
                lr.material = mat;

                float r = 0.35f;
                for (int i = 0; i < 36; i++)
                {
                    float angle = (i / 36.0f) * Mathf.PI * 2f;
                    lr.SetPosition(i, new Vector3(Mathf.Cos(angle) * r, 0.005f, Mathf.Sin(angle) * r));
                }
            }

            if (activeReticle != null)
            {
                activeReticle.SetActive(false);
            }
        }

        private void UpdatePlacementPose()
        {
            // Center of screen raycast (Mobile AR style) or mouse raycast in desktop
            Vector3 screenPos;
            if (Application.isMobilePlatform && Input.touchCount > 0)
            {
                screenPos = Input.GetTouch(0).position;
            }
            else if (!Application.isMobilePlatform)
            {
                screenPos = Input.mousePosition;
            }
            else
            {
                screenPos = new Vector3(Screen.width * 0.5f, Screen.height * 0.5f, 0);
            }

            Ray ray = activeCam.ScreenPointToRay(screenPos);

            if (Physics.Raycast(ray, out RaycastHit hit, maxRayDistance, surfaceLayerMask))
            {
                // Verify surface is roughly horizontal (table, floor, ground plane)
                if (hit.normal.y > 0.65f)
                {
                    isPoseValid = true;
                    Vector3 forward = Vector3.ProjectOnPlane(activeCam.transform.forward, hit.normal).normalized;
                    if (forward.sqrMagnitude < 0.01f) forward = activeCam.transform.up;

                    currentPlacementPose = new Pose(hit.point, Quaternion.LookRotation(forward, hit.normal));
                    OnPlacementPoseUpdated?.Invoke(currentPlacementPose);
                    return;
                }
            }

            isPoseValid = false;
        }

        private void UpdateReticleVisual()
        {
            if (activeReticle == null) return;

            if (isPoseValid)
            {
                activeReticle.SetActive(true);
                activeReticle.transform.position = currentPlacementPose.position;
                activeReticle.transform.rotation = currentPlacementPose.rotation;
            }
            else
            {
                activeReticle.SetActive(false);
            }
        }

        private void HandleTouchOrClickPlacement()
        {
            // Only place on touch/click if pointer is NOT over UI
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }

            bool triggerPlacement = false;

            // Mobile single tap
            if (Application.isMobilePlatform && Input.touchCount == 1)
            {
                Touch t = Input.GetTouch(0);
                if (t.phase == TouchPhase.Began)
                {
                    triggerPlacement = true;
                }
            }
            // Desktop Left Click (when no interactable object is grabbed)
            else if (!Application.isMobilePlatform && Input.GetMouseButtonDown(0))
            {
                // Only place if not clicking an existing interactable
                Ray ray = activeCam.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out RaycastHit hit, maxRayDistance))
                {
                    if (hit.collider.GetComponentInParent<SmartSpaceAR.Simulation.AntiGravityInteractable>() != null)
                    {
                        return; // Let interactable handle selection/drag
                    }
                }
                triggerPlacement = true;
            }

            if (triggerPlacement && isPoseValid)
            {
                if (FurnitureManager.Instance != null && FurnitureManager.Instance.CurrentSelectedItem != null)
                {
                    FurnitureManager.Instance.SpawnFurniture(currentPlacementPose.position, currentPlacementPose.rotation);
                }
            }
        }

        /// <summary>
        /// Explicit API for placing an item at arbitrary world coordinates.
        /// </summary>
        public GameObject PlaceObjectAtPose(Pose targetPose)
        {
            if (FurnitureManager.Instance != null)
            {
                return FurnitureManager.Instance.SpawnFurniture(targetPose.position, targetPose.rotation);
            }
            return null;
        }
    }
}
