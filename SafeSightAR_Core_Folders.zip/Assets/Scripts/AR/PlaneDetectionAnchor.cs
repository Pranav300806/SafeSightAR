using System.Collections.Generic;
using UnityEngine;

namespace SafeSightAR.AR
{
    /// <summary>
    /// Handles AR plane detection, surface anchoring, and spatial raycast hit tests 
    /// for placing 3D hazard warning cards and holographic highlight markers.
    /// </summary>
    public class PlaneDetectionAnchor : MonoBehaviour
    {
        [Header("Anchor Preferences")]
        [SerializeField] private GameObject hazardAnchorPrefab;
        [SerializeField] private LayerMask surfaceLayerMask;

        private List<GameObject> activeAnchors = new List<GameObject>();

        /// <summary>
        /// Instantiates or updates a world-anchored hazard visualizer at specified 3D world coordinates.
        /// </summary>
        public GameObject CreateOrUpdateAnchor(string id, Vector3 position, Quaternion rotation)
        {
            GameObject existing = activeAnchors.Find(a => a.name == id);
            if (existing != null)
            {
                existing.transform.position = Vector3.Lerp(existing.transform.position, position, Time.deltaTime * 10f);
                existing.transform.rotation = Quaternion.Slerp(existing.transform.rotation, rotation, Time.deltaTime * 10f);
                return existing;
            }

            if (hazardAnchorPrefab == null)
            {
                existing = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                existing.transform.localScale = Vector3.one * 0.1f;
            }
            else
            {
                existing = Instantiate(hazardAnchorPrefab, position, rotation);
            }

            existing.name = id;
            activeAnchors.Add(existing);
            return existing;
        }

        public void ClearAnchors()
        {
            foreach (var anchor in activeAnchors)
            {
                if (anchor != null) Destroy(anchor);
            }
            activeAnchors.Clear();
        }
    }
}
