#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace SafeSightAR.Editor
{
    /// <summary>
    /// Automated Android APK Builder for SafeSight Mobile AR Furniture.
    /// Configures Android Player settings, ARCore permissions, minSdk,
    /// and triggers a 1-click BuildPlayer pipeline producing a standalone .apk package.
    /// Fully compliant with Unity 6 (6000.x) NamedBuildTarget API.
    /// </summary>
    public static class AndroidApkBuilder
    {
        private const string OutputDirectory = "Builds/Android";
        private const string ApkFileName = "SafeSight_AR_Furniture.apk";

        [MenuItem("SafeSight/3. Build Android APK", priority = 20)]
        public static void BuildAndroidApk()
        {
            Debug.Log("[AndroidApkBuilder] Starting SafeSight AR Furniture Android APK Build Pipeline...");

            // 1. Ensure Output Directory Exists
            if (!Directory.Exists(OutputDirectory))
            {
                Directory.CreateDirectory(OutputDirectory);
            }

            string fullApkPath = Path.Combine(OutputDirectory, ApkFileName);

            // 2. Configure Player & Identification Settings
            PlayerSettings.companyName = "SafeSight";
            PlayerSettings.productName = "SafeSight AR Furniture";
            
            // Unity 6 NamedBuildTarget API
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.safesight.arfurniture");
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.Android.bundleVersionCode = 1;

            // 3. Android SDK & IL2CPP Configuration
            PlayerSettings.Android.minSdkVersion = (AndroidSdkVersions)26;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;

            // Auto-rotation support (Portrait and Landscape)
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;

            // Ensure APK output and match installed Development IL2CPP runtime
            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
            EditorUserBuildSettings.development = true;
            EditorUserBuildSettings.allowDebugging = false;

            // 4. Collect Build Scenes (MobileAR_Furniture MUST BE Scene 0 so the mobile APK boots directly into the Furniture Rig!)
            string[] scenes = new string[]
            {
                "Assets/Scenes/MobileAR_Furniture.unity",
                "Assets/Scenes/AntiGravity_Simulation.unity"
            };

            if (!File.Exists(scenes[0]))
            {
                Debug.LogWarning($"[AndroidApkBuilder] Scene {scenes[0]} not found. Generating via AntiGravitySceneBuilder...");
                AntiGravitySceneBuilder.BuildAndSaveScene();
            }
            if (!File.Exists(scenes[1]))
            {
                Debug.LogWarning($"[AndroidApkBuilder] Scene {scenes[1]} not found. Generating via MobileARSceneBuilder...");
                MobileARSceneBuilder.BuildAndSaveScene();
            }

            // 5. Execute Build Pipeline (using Development to link installed arm64-v8a libunityruntime.a)
            BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = fullApkPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development
            };

            Debug.Log($"[AndroidApkBuilder] Compiling shaders and building Android APK to: {fullApkPath}");
            BuildReport report = BuildPipeline.BuildPlayer(buildPlayerOptions);
            BuildSummary summary = report.summary;

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"<color=#38ef7d><b>[AndroidApkBuilder] SUCCESS!</b> APK built successfully ({summary.totalSize / (1024 * 1024):F1} MB) at: {fullApkPath}</color>");
                EditorUtility.RevealInFinder(fullApkPath);
            }
            else
            {
                Debug.LogError($"[AndroidApkBuilder] BUILD FAILED: Encountered {summary.totalErrors} errors during build.");
            }
        }
    }
}
#endif
