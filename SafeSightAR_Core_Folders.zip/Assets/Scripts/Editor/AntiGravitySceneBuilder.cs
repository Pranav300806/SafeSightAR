#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using SafeSightAR.Simulation;
using SafeSightAR.RiskEngine;

namespace SafeSightAR.Editor
{
    /// <summary>
    /// Automated Scene Builder for the Anti-Gravity Spatial Simulation Rig.
    /// Programmatically generates and configures AntiGravity_Simulation.unity with all
    /// physics rigs, Zero-G interactables, table boundaries, and risk evaluators.
    /// </summary>
    public static class AntiGravitySceneBuilder
    {
        private const string ScenePath = "Assets/Scenes/AntiGravity_Simulation.unity";

        [MenuItem("SafeSight/1. Open SafeSight AI Hazard Engine Scene (Zero-G)", priority = 0)]
        public static void OpenHazardEngineScene()
        {
            if (EditorApplication.isPlaying)
            {
                EditorApplication.isPlaying = false;
                EditorApplication.playModeStateChanged += OnPlayModeChangedToOpen;
                return;
            }

            OpenSceneInternal();
        }

        private static void OnPlayModeChangedToOpen(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.EnteredEditMode)
            {
                EditorApplication.playModeStateChanged -= OnPlayModeChangedToOpen;
                EditorApplication.delayCall += OpenSceneInternal;
            }
        }

        private static void OpenSceneInternal()
        {
            if (System.IO.File.Exists(ScenePath))
            {
                EditorSceneManager.OpenScene(ScenePath);
                Debug.Log($"<color=#38ef7d><b>[AntiGravitySceneBuilder] Opened SafeSight AI Hazard Engine Scene:</b> {ScenePath}</color>");
            }
            else
            {
                BuildAndSaveScene();
            }
        }

        [MenuItem("SafeSight/Rebuild Anti-Gravity Hazard Scene", priority = 15)]
        public static void BuildAndSaveScene()
        {
            Debug.Log("[AntiGravitySceneBuilder] Constructing AntiGravity_Simulation scene...");

            // 1. Create Empty Scene
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // 2. Camera Setup
            GameObject camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            Camera cam = camObj.AddComponent<Camera>();
            camObj.AddComponent<AudioListener>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.12f, 0.13f, 0.16f);
            cam.fieldOfView = 60f;
            cam.nearClipPlane = 0.05f;
            camObj.transform.position = new Vector3(0.0f, 1.25f, -1.05f);
            camObj.transform.rotation = Quaternion.Euler(26.0f, 0.0f, 0.0f);

            // 3. Directional Light
            GameObject lightObj = new GameObject("Directional Light");
            Light light = lightObj.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1f, 0.96f, 0.90f);
            light.intensity = 1.15f;
            lightObj.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            // 4. Floor Reference Plane
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "Floor_Plane";
            floor.transform.position = Vector3.zero;
            floor.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);

            // 5. Table Rig
            GameObject tableRigObj = new GameObject("Table_Rig");
            tableRigObj.transform.position = new Vector3(0.0f, 0.725f, 0.25f);
            AntiGravityTableRig tableRig = tableRigObj.AddComponent<AntiGravityTableRig>();

            // Visual Table Top
            GameObject tableVisual = GameObject.CreatePrimitive(PrimitiveType.Cube);
            tableVisual.name = "TableTop_Visual";
            tableVisual.transform.SetParent(tableRigObj.transform, false);
            tableVisual.transform.localPosition = Vector3.zero;
            tableVisual.transform.localScale = new Vector3(1.60f, 0.05f, 0.90f);
            UnityEngine.Object.DestroyImmediate(tableVisual.GetComponent<Collider>());

            // Table Legs
            CreateLeg(tableRigObj, new Vector3(-0.75f, -0.35f, -0.40f));
            CreateLeg(tableRigObj, new Vector3( 0.75f, -0.35f, -0.40f));
            CreateLeg(tableRigObj, new Vector3(-0.75f, -0.35f,  0.40f));
            CreateLeg(tableRigObj, new Vector3( 0.75f, -0.35f,  0.40f));

            // 6. Walkway Bounds Collider
            GameObject walkwayObj = new GameObject("Walkway_Bounds");
            walkwayObj.transform.position = new Vector3(0.0f, 0.05f, 1.05f);
            BoxCollider walkwayCol = walkwayObj.AddComponent<BoxCollider>();
            walkwayCol.isTrigger = true;
            walkwayCol.size = new Vector3(2.50f, 0.10f, 1.20f);

            // 7. Hazard Simulation Managers
            GameObject managersObj = new GameObject("[SIMULATION_MANAGERS]");
            RiskEvaluator riskEvaluator = managersObj.AddComponent<RiskEvaluator>();
            SafeSightSimulationHub simHub = managersObj.AddComponent<SafeSightSimulationHub>();
            SpatialVisualizerGizmo gizmo = managersObj.AddComponent<SpatialVisualizerGizmo>();

            // Link references via SerializedObject
            SerializedObject hubSO = new SerializedObject(simHub);
            hubSO.FindProperty("tableRig").objectReferenceValue = tableRig;
            hubSO.FindProperty("walkwayCollider").objectReferenceValue = walkwayCol;
            hubSO.FindProperty("riskEvaluator").objectReferenceValue = riskEvaluator;
            hubSO.ApplyModifiedProperties();

            // 8. Interactive Zero-G Hazard Entities
            GameObject entitiesRoot = new GameObject("[HAZARD_ENTITIES]");

            // A. Laptop
            GameObject laptop = GameObject.CreatePrimitive(PrimitiveType.Cube);
            laptop.name = "Entity_Laptop";
            laptop.transform.SetParent(entitiesRoot.transform);
            laptop.transform.position = new Vector3(0.0f, 0.77f, 0.20f);
            laptop.transform.localScale = new Vector3(0.35f, 0.02f, 0.25f);
            var laptopInteractable = laptop.AddComponent<AntiGravityInteractable>();
            laptopInteractable.EntityClass = "laptop";

            // B. Bottle
            GameObject bottle = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            bottle.name = "Entity_Bottle";
            bottle.transform.SetParent(entitiesRoot.transform);
            bottle.transform.position = new Vector3(-0.45f, 0.86f, 0.25f);
            bottle.transform.localScale = new Vector3(0.08f, 0.18f, 0.08f);
            var bottleInteractable = bottle.AddComponent<AntiGravityInteractable>();
            bottleInteractable.EntityClass = "bottle";

            // C. Knife
            GameObject knife = GameObject.CreatePrimitive(PrimitiveType.Cube);
            knife.name = "Entity_Knife";
            knife.transform.SetParent(entitiesRoot.transform);
            knife.transform.position = new Vector3(0.25f, 0.76f, 0.25f);
            knife.transform.localScale = new Vector3(0.04f, 0.015f, 0.20f);
            var knifeInteractable = knife.AddComponent<AntiGravityInteractable>();
            knifeInteractable.EntityClass = "knife";

            // D. Drawer
            GameObject drawer = GameObject.CreatePrimitive(PrimitiveType.Cube);
            drawer.name = "Entity_Drawer";
            drawer.transform.SetParent(entitiesRoot.transform);
            drawer.transform.position = new Vector3(-0.55f, 0.35f, 0.0f);
            drawer.transform.localScale = new Vector3(0.40f, 0.25f, 0.40f);
            var drawerInteractable = drawer.AddComponent<AntiGravityInteractable>();
            drawerInteractable.EntityClass = "drawer";

            // E. Cable
            GameObject cable = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            cable.name = "Entity_Cable";
            cable.transform.SetParent(entitiesRoot.transform);
            cable.transform.position = new Vector3(-0.80f, 0.02f, -0.40f);
            cable.transform.rotation = Quaternion.Euler(0, 0, 90f);
            cable.transform.localScale = new Vector3(0.025f, 0.50f, 0.025f);
            var cableInteractable = cable.AddComponent<AntiGravityInteractable>();
            cableInteractable.EntityClass = "cable";

            // 9. Save and Open Scene
            string scenePath = "Assets/Scenes/AntiGravity_Simulation.unity";
            EditorSceneManager.SaveScene(scene, scenePath);
            EditorSceneManager.OpenScene(scenePath);
            Debug.Log($"[AntiGravitySceneBuilder] Successfully generated and opened {scenePath}!");
        }

        private static void CreateLeg(GameObject parent, Vector3 localPos)
        {
            GameObject leg = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            leg.name = "Table_Leg";
            leg.transform.SetParent(parent.transform, false);
            leg.transform.localPosition = localPos;
            leg.transform.localScale = new Vector3(0.05f, 0.35f, 0.05f);
            UnityEngine.Object.DestroyImmediate(leg.GetComponent<Collider>());
        }
    }
}
#endif
