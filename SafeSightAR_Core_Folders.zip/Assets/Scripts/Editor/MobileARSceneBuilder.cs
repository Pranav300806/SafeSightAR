#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using SafeSightAR.AR;

namespace SafeSightAR.Editor
{
    /// <summary>
    /// Automated Scene Builder for SafeSight Mobile AR Furniture.
    /// Builds and configures Assets/Scenes/MobileAR_Furniture.unity with camera,
    /// lighting, floor reference plane, and the MobileARFurnitureController rig.
    /// </summary>
    public static class MobileARSceneBuilder
    {
        private const string ScenePath = "Assets/Scenes/MobileAR_Furniture.unity";

        [MenuItem("SafeSight/Rebuild Mobile AR Furniture Scene", priority = 25)]
        public static void BuildAndSaveScene()
        {
            Debug.Log("[MobileARSceneBuilder] Building Mobile AR Furniture Scene...");

            // 1. Ensure directory exists
            string dir = Path.GetDirectoryName(ScenePath);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            // 2. Create New Empty Scene
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // 3. Setup AR / Main Camera
            GameObject camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            Camera cam = camObj.AddComponent<Camera>();
            camObj.AddComponent<AudioListener>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.11f, 0.12f, 0.15f); // Sleek modern studio backdrop
            cam.fieldOfView = 60f;
            cam.nearClipPlane = 0.05f;
            cam.farClipPlane = 100f;
            camObj.transform.position = new Vector3(0.0f, 1.60f, -2.40f);
            camObj.transform.rotation = Quaternion.Euler(30.0f, 0.0f, 0.0f);

            // 4. Directional Light (Warm Key Sun)
            GameObject lightObj = new GameObject("Directional Light");
            Light light = lightObj.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1.0f, 0.98f, 0.94f);
            light.intensity = 1.25f;
            light.shadows = LightShadows.Soft;
            lightObj.transform.rotation = Quaternion.Euler(50f, -35f, 0f);

            // Fill Light (Subtle Ambient Fill)
            GameObject fillLightObj = new GameObject("Fill Light");
            Light fillLight = fillLightObj.AddComponent<Light>();
            fillLight.type = LightType.Directional;
            fillLight.color = new Color(0.7f, 0.85f, 1.0f);
            fillLight.intensity = 0.45f;
            fillLight.shadows = LightShadows.None;
            fillLightObj.transform.rotation = Quaternion.Euler(30f, 145f, 0f);

            // 5. Studio Surface Floor Plane
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
            floor.name = "AR_Floor_Plane";
            floor.transform.position = Vector3.zero;
            floor.transform.localScale = new Vector3(2.5f, 1.0f, 2.5f); // 25m x 25m surface

            Material floorMat = new Material(Shader.Find("Standard"));
            floorMat.name = "Mat_StudioFloor";
            floorMat.color = new Color(0.16f, 0.17f, 0.20f);
            floorMat.SetFloat("_Glossiness", 0.35f);
            floorMat.SetFloat("_Metallic", 0.05f);
            floor.GetComponent<Renderer>().material = floorMat;

            // 6. Mobile AR Furniture System Root
            GameObject arSystemObj = new GameObject("[MOBILE_AR_FURNITURE_SYSTEM]");
            var controller = arSystemObj.AddComponent<MobileARFurnitureController>();

            // 7. Save Scene to Assets/Scenes/MobileAR_Furniture.unity
            bool saved = EditorSceneManager.SaveScene(scene, ScenePath);
            if (saved)
            {
                Debug.Log($"<color=#38ef7d><b>[MobileARSceneBuilder] SUCCESS:</b> Scene created and saved to {ScenePath}</color>");

                // Register in EditorBuildSettings
                EditorBuildSettingsScene[] currentScenes = EditorBuildSettings.scenes;
                bool alreadyInBuild = false;
                foreach (var s in currentScenes)
                {
                    if (s.path == ScenePath)
                    {
                        alreadyInBuild = true;
                        break;
                    }
                }

                if (!alreadyInBuild)
                {
                    EditorBuildSettingsScene[] newScenes = new EditorBuildSettingsScene[currentScenes.Length + 1];
                    newScenes[0] = new EditorBuildSettingsScene(ScenePath, true);
                    for (int i = 0; i < currentScenes.Length; i++)
                    {
                        newScenes[i + 1] = currentScenes[i];
                    }
                    EditorBuildSettings.scenes = newScenes;
                    Debug.Log($"[MobileARSceneBuilder] Added {ScenePath} as default Scene #0 in Build Settings.");
                }

                // Keep scene loaded
                EditorSceneManager.OpenScene(ScenePath);
            }
            else
            {
                Debug.LogError($"[MobileARSceneBuilder] Failed to save scene to {ScenePath}");
            }
        }

        [MenuItem("SafeSight/2. Open Mobile AR Furniture Demo Scene", priority = 10)]
        public static void OpenScene()
        {
            if (EditorApplication.isPlaying)
            {
                EditorApplication.isPlaying = false;
                EditorApplication.playModeStateChanged += OnPlayModeChangedToOpenMobile;
                return;
            }

            OpenMobileSceneInternal();
        }

        private static void OnPlayModeChangedToOpenMobile(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.EnteredEditMode)
            {
                EditorApplication.playModeStateChanged -= OnPlayModeChangedToOpenMobile;
                EditorApplication.delayCall += OpenMobileSceneInternal;
            }
        }

        private static void OpenMobileSceneInternal()
        {
            if (File.Exists(ScenePath))
            {
                EditorSceneManager.OpenScene(ScenePath);
                Debug.Log($"[MobileARSceneBuilder] Opened {ScenePath}");
            }
            else
            {
                BuildAndSaveScene();
            }
        }
    }
}
#endif
