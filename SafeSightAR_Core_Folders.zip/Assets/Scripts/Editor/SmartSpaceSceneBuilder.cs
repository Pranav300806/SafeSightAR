#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using SmartSpaceAR.AR;
using SmartSpaceAR.Furniture;
using SmartSpaceAR.Simulation;

namespace SmartSpaceAR.Editor
{
    /// <summary>
    /// Automated Scene Builder for SmartSpace AR.
    /// Programmatically constructs:
    /// 1. MainScene.unity (Integrated AR + Desktop Simulation Rig)
    /// 2. Furniture_Test.unity (Independent UI selection and manipulation sandbox)
    /// 3. Simulation_Test.unity (Desktop 3D Zero-G physics and camera navigation rig)
    /// </summary>
    public static class SmartSpaceSceneBuilder
    {
        private const string ScenesDir = "Assets/Scenes";
        private const string MainScenePath = "Assets/Scenes/MainScene.unity";
        private const string FurnitureTestScenePath = "Assets/Scenes/Furniture_Test.unity";
        private const string SimulationTestScenePath = "Assets/Scenes/Simulation_Test.unity";

        [InitializeOnLoadMethod]
        private static void AutoBuildOnLoad()
        {
            EditorApplication.delayCall += () =>
            {
                if (!File.Exists(MainScenePath) || !File.Exists(FurnitureTestScenePath) || !File.Exists(SimulationTestScenePath))
                {
                    BuildAllScenes();
                    EditorSceneManager.OpenScene(MainScenePath);
                }
            };
        }

        [MenuItem("SmartSpace AR/Build All 3 Scenes", priority = 0)]
        public static void BuildAllScenes()
        {
            EnsureScenesDirectory();
            BuildMainScene();
            BuildFurnitureTestScene();
            BuildSimulationTestScene();
            Debug.Log("<color=#00e5ff><b>[SmartSpace AR] Successfully built all 3 scenes in Assets/Scenes!</b></color>");
        }

        [MenuItem("SmartSpace AR/1. Build & Open MainScene (Integrated)", priority = 10)]
        public static void BuildAndOpenMainScene()
        {
            EnsureScenesDirectory();
            BuildMainScene();
            EditorSceneManager.OpenScene(MainScenePath);
        }

        [MenuItem("SmartSpace AR/2. Build & Open Furniture_Test (UI Sandbox)", priority = 11)]
        public static void BuildAndOpenFurnitureTestScene()
        {
            EnsureScenesDirectory();
            BuildFurnitureTestScene();
            EditorSceneManager.OpenScene(FurnitureTestScenePath);
        }

        [MenuItem("SmartSpace AR/3. Build & Open Simulation_Test (Zero-G Physics)", priority = 12)]
        public static void BuildAndOpenSimulationTestScene()
        {
            EnsureScenesDirectory();
            BuildSimulationTestScene();
            EditorSceneManager.OpenScene(SimulationTestScenePath);
        }

        private static void EnsureScenesDirectory()
        {
            if (!Directory.Exists(ScenesDir))
            {
                Directory.CreateDirectory(ScenesDir);
            }
        }

        #region Scene 1: MainScene.unity

        public static void BuildMainScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // 1. Camera
            GameObject camObj = CreateMainCamera(new Vector3(0, 1.8f, -2.8f), Quaternion.Euler(22f, 0, 0));

            // 2. Directional Light
            CreateDirectionalLight();

            // 3. EventSystem
            CreateEventSystem();

            // 4. Managers
            GameObject systemObj = new GameObject("[SMARTSPACE_SYSTEM]");
            ARManager arMgr = systemObj.AddComponent<ARManager>();
            FurnitureManager furnMgr = systemObj.AddComponent<FurnitureManager>();
            PlacementManager placeMgr = systemObj.AddComponent<PlacementManager>();
            InteractionManager interactMgr = systemObj.AddComponent<InteractionManager>();
            ObjectControls objControls = systemObj.AddComponent<ObjectControls>();
            FurnitureUI furnUI = systemObj.AddComponent<FurnitureUI>();

            // 5. Room Rig
            GameObject roomObj = new GameObject("[SIMULATION_ROOM_RIG]");
            EditorRoomRig roomRig = roomObj.AddComponent<EditorRoomRig>();

            // Save Scene
            EditorSceneManager.SaveScene(scene, MainScenePath);
            Debug.Log($"[SmartSpace AR] MainScene generated and saved at: {MainScenePath}");
        }

        #endregion

        #region Scene 2: Furniture_Test.unity

        public static void BuildFurnitureTestScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // 1. Camera
            CreateMainCamera(new Vector3(0, 1.6f, -2.2f), Quaternion.Euler(20f, 0, 0));

            // 2. Lighting
            CreateDirectionalLight();

            // 3. EventSystem
            CreateEventSystem();

            // 4. Showcase Pedestal
            GameObject pedestal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pedestal.name = "Showcase_Pedestal";
            pedestal.transform.position = new Vector3(0, -0.05f, 0.5f);
            pedestal.transform.localScale = new Vector3(3.0f, 0.05f, 3.0f);
            pedestal.tag = "Floor";

            // 5. Managers
            GameObject systemObj = new GameObject("[FURNITURE_TEST_SYSTEM]");
            FurnitureManager furnMgr = systemObj.AddComponent<FurnitureManager>();
            ObjectControls objControls = systemObj.AddComponent<ObjectControls>();
            FurnitureUI furnUI = systemObj.AddComponent<FurnitureUI>();

            EditorSceneManager.SaveScene(scene, FurnitureTestScenePath);
            Debug.Log($"[SmartSpace AR] Furniture_Test scene generated and saved at: {FurnitureTestScenePath}");
        }

        #endregion

        #region Scene 3: Simulation_Test.unity

        public static void BuildSimulationTestScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // 1. Camera
            CreateMainCamera(new Vector3(0, 1.8f, -2.8f), Quaternion.Euler(22f, 0, 0));

            // 2. Lighting
            CreateDirectionalLight();

            // 3. EventSystem
            CreateEventSystem();

            // 4. Room Rig
            GameObject roomObj = new GameObject("[SIMULATION_ROOM_RIG]");
            EditorRoomRig roomRig = roomObj.AddComponent<EditorRoomRig>();

            // 5. Managers
            GameObject systemObj = new GameObject("[SIMULATION_SYSTEM]");
            FurnitureManager furnMgr = systemObj.AddComponent<FurnitureManager>();
            ObjectControls objControls = systemObj.AddComponent<ObjectControls>();
            FurnitureUI furnUI = systemObj.AddComponent<FurnitureUI>();

            EditorSceneManager.SaveScene(scene, SimulationTestScenePath);
            Debug.Log($"[SmartSpace AR] Simulation_Test scene generated and saved at: {SimulationTestScenePath}");
        }

        #endregion

        #region Helpers

        private static GameObject CreateMainCamera(Vector3 pos, Quaternion rot)
        {
            GameObject camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            Camera cam = camObj.AddComponent<Camera>();
            camObj.AddComponent<AudioListener>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.12f, 0.14f, 0.18f);
            cam.fieldOfView = 60f;
            cam.nearClipPlane = 0.05f;
            camObj.transform.position = pos;
            camObj.transform.rotation = rot;
            return camObj;
        }

        private static GameObject CreateDirectionalLight()
        {
            GameObject lightObj = new GameObject("Directional Light");
            Light light = lightObj.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1f, 0.96f, 0.90f);
            light.intensity = 1.2f;
            lightObj.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            return lightObj;
        }

        private static GameObject CreateEventSystem()
        {
            GameObject eventSystemObj = new GameObject("EventSystem");
            eventSystemObj.AddComponent<EventSystem>();
            eventSystemObj.AddComponent<StandaloneInputModule>();
            return eventSystemObj;
        }

        #endregion
    }
}
#endif
