using System;
using System.Collections.Generic;
using UnityEngine;

namespace SmartSpaceAR.Furniture
{
    public enum FurnitureCategory
    {
        Seating,
        Tables,
        Bedroom,
        Storage,
        Lighting,
        Decor
    }

    /// <summary>
    /// ScriptableObject defining metadata, 3D prefab reference, physical scale,
    /// and spatial clearance metrics for an interior furniture item in SmartSpace AR.
    /// </summary>
    [CreateAssetMenu(fileName = "NewFurnitureItem", menuName = "SmartSpace AR/Furniture Item", order = 100)]
    public class FurnitureItem : ScriptableObject
    {
        [Header("Identity & Categorization")]
        [Tooltip("Display name shown in UI catalog.")]
        public string itemName = "Modern Sofa";

        [Tooltip("Unique catalog identifier code (e.g., SOFA_01, CHAIR_03).")]
        public string itemId = "ITEM_001";

        [Tooltip("Room classification category.")]
        public FurnitureCategory category = FurnitureCategory.Seating;

        [TextArea(2, 4)]
        [Tooltip("Brief product overview description for preview panels.")]
        public string description = "Ergonomic modern furniture with natural fabric upholstery.";

        [Tooltip("Retail / catalog price for interior budget evaluation.")]
        public float price = 299.00f;

        [Header("Visual & Spatial Assets")]
        [Tooltip("2D thumbnail icon rendered in bottom catalog carousel.")]
        public Sprite icon;

        [Tooltip("3D model prefab instantiated into the AR / simulated room.")]
        public GameObject prefab;

        [Tooltip("Baseline world scale applied upon initial surface placement.")]
        public Vector3 defaultScale = Vector3.one;

        [Tooltip("Physical bounding dimensions (Width X, Height Y, Depth Z) in real-world meters.")]
        public Vector3 dimensionsMeters = new Vector3(1.8f, 0.85f, 0.95f);

        [Header("Clearance & Ergonomics")]
        [Tooltip("Minimum recommended buffer radius around the item to maintain safe walkway clearance.")]
        [Range(0.1f, 1.5f)]
        public float safetyClearanceRadius = 0.45f;

        /// <summary>
        /// Validates that required properties are set.
        /// </summary>
        public bool IsValid()
        {
            return !string.IsNullOrEmpty(itemName) && (prefab != null || dimensionsMeters.sqrMagnitude > 0.01f);
        }
    }

    /// <summary>
    /// ScriptableObject holding a collection of FurnitureItem definitions,
    /// enabling modular catalog swapping (e.g., Living Room collection, Office collection).
    /// </summary>
    [CreateAssetMenu(fileName = "FurnitureCatalog", menuName = "SmartSpace AR/Furniture Catalog", order = 101)]
    public class FurnitureCatalog : ScriptableObject
    {
        public string catalogTitle = "Modern Living Room Collection";
        public List<FurnitureItem> items = new List<FurnitureItem>();
    }
}
