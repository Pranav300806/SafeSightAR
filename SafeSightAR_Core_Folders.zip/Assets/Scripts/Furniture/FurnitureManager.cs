using System;
using System.Collections.Generic;
using UnityEngine;
using SmartSpaceAR.Simulation;

namespace SmartSpaceAR.Furniture
{
    /// <summary>
    /// Core Central Manager for SmartSpace AR furniture catalog, active selection tracking,
    /// dynamic instantiation, and procedural fallback geometry creation for hardware-free testing.
    /// Operates completely locally in-memory with zero localhost or external networking.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class FurnitureManager : MonoBehaviour
    {
        [Header("Catalog Setup")]
        [Tooltip("Direct list of FurnitureItem ScriptableObjects.")]
        [SerializeField] private List<FurnitureItem> catalogItems = new List<FurnitureItem>();

        [Tooltip("Optional container catalog asset.")]
        [SerializeField] private FurnitureCatalog catalogAsset;

        [Tooltip("Currently highlighted catalog item index.")]
        [SerializeField] private int selectedItemIndex = 0;

        [Header("Runtime Placement State")]
        [Tooltip("Parent transform to keep scene hierarchy organized.")]
        [SerializeField] private Transform furnitureRoot;

        [Tooltip("Currently selected / focused placed furniture instance in the room.")]
        [SerializeField] private GameObject activeSelectedObject;

        [Header("Procedural Fallback Settings")]
        [Tooltip("If true, automatically creates stylized procedural primitives if catalog is empty or prefabs are missing.")]
        [SerializeField] private bool autoGenerateProceduralFallbacks = true;

        [SerializeField] private Material defaultFurnitureMaterial;

        // Placed furniture instance registry
        private readonly List<GameObject> placedInstances = new List<GameObject>();

        // Singleton
        public static FurnitureManager Instance { get; private set; }

        // Public Events
        public event Action<FurnitureItem> OnCatalogItemSelected;
        public event Action<GameObject> OnFurniturePlaced;
        public event Action<GameObject> OnSelectionChanged;
        public event Action<GameObject> OnFurnitureDeleted;

        #region Public Accessors

        public IReadOnlyList<FurnitureItem> CatalogItems => catalogItems;
        public int SelectedItemIndex => selectedItemIndex;
        public FurnitureItem CurrentSelectedItem => (catalogItems != null && catalogItems.Count > 0 && selectedItemIndex >= 0 && selectedItemIndex < catalogItems.Count)
            ? catalogItems[selectedItemIndex] : null;

        public GameObject ActiveSelectedObject => activeSelectedObject;
        public IReadOnlyList<GameObject> PlacedInstances => placedInstances;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
                return;
            }

            if (furnitureRoot == null)
            {
                GameObject rootObj = new GameObject("[Placed_Furniture_Container]");
                furnitureRoot = rootObj.transform;
            }

            InitializeCatalog();
        }

        private void Start()
        {
            if (catalogItems.Count > 0)
            {
                SelectCatalogItem(0);
            }
        }

        #endregion

        #region Catalog Initialization & Procedural Fallbacks

        private void InitializeCatalog()
        {
            if (catalogAsset != null && catalogAsset.items.Count > 0)
            {
                catalogItems = new List<FurnitureItem>(catalogAsset.items);
            }

            // If empty or missing prefabs, populate procedural fallback models
            if (autoGenerateProceduralFallbacks && (catalogItems == null || catalogItems.Count == 0))
            {
                PopulateProceduralCatalog();
            }
        }

        /// <summary>
        /// Procedurally generates 8 distinct interior furniture items (Sofa, Chair, Table, Bed, Cabinet, Bookshelf, Lamp, Plant)
        /// with bottom-center pivots, composite primitive geometries, and colliders.
        /// </summary>
        public void PopulateProceduralCatalog()
        {
            catalogItems = new List<FurnitureItem>();

            catalogItems.Add(CreateProceduralItem("Sofa", "SOFA_01", FurnitureCategory.Seating, "Modern 3-seater living room couch with deep foam cushions.", 499f, new Vector3(2.0f, 0.85f, 0.95f), BuildSofaPrefab()));
            catalogItems.Add(CreateProceduralItem("Chair", "CHAIR_01", FurnitureCategory.Seating, "Ergonomic Scandinavian accent lounge chair.", 149f, new Vector3(0.75f, 0.90f, 0.80f), BuildChairPrefab()));
            catalogItems.Add(CreateProceduralItem("Table", "TABLE_01", FurnitureCategory.Tables, "Solid oak Scandinavian dining / study table.", 329f, new Vector3(1.60f, 0.75f, 0.90f), BuildTablePrefab()));
            catalogItems.Add(CreateProceduralItem("Bed", "BED_01", FurnitureCategory.Bedroom, "Queen-size platform bed with padded headboard.", 699f, new Vector3(1.70f, 0.95f, 2.10f), BuildBedPrefab()));
            catalogItems.Add(CreateProceduralItem("Cabinet", "CAB_01", FurnitureCategory.Storage, "Mid-century modern 2-door storage sideboard cabinet.", 279f, new Vector3(1.20f, 0.80f, 0.45f), BuildCabinetPrefab()));
            catalogItems.Add(CreateProceduralItem("Bookshelf", "SHELF_01", FurnitureCategory.Storage, "5-tier vertical open architectural bookshelf.", 199f, new Vector3(0.90f, 1.85f, 0.35f), BuildBookshelfPrefab()));
            catalogItems.Add(CreateProceduralItem("Floor Lamp", "LAMP_01", FurnitureCategory.Lighting, "Minimalist arched warm LED reading floor lamp.", 89f, new Vector3(0.45f, 1.65f, 0.45f), BuildFloorLampPrefab()));
            catalogItems.Add(CreateProceduralItem("Indoor Plant", "PLANT_01", FurnitureCategory.Decor, "Potted Monstera Deliciosa in ceramic floor planter.", 59f, new Vector3(0.55f, 1.10f, 0.55f), BuildIndoorPlantPrefab()));

            Debug.Log($"[SmartSpace AR] Procedural furniture catalog generated: {catalogItems.Count} items ready.");
        }

        private FurnitureItem CreateProceduralItem(string name, string id, FurnitureCategory cat, string desc, float price, Vector3 dimensions, GameObject prefab)
        {
            FurnitureItem item = ScriptableObject.CreateInstance<FurnitureItem>();
            item.itemName = name;
            item.itemId = id;
            item.category = cat;
            item.description = desc;
            item.price = price;
            item.dimensionsMeters = dimensions;
            item.defaultScale = Vector3.one;
            item.prefab = prefab;
            item.safetyClearanceRadius = Mathf.Max(dimensions.x, dimensions.z) * 0.4f;
            return item;
        }

        #endregion

        #region Procedural Model Constructors (Bottom-Center Pivots)

        private Material GetFallbackMaterial(Color color, float smoothness = 0.5f)
        {
            Material mat = new Material(Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Mobile/Diffuse"));
            mat.color = color;
            mat.name = $"ProceduralMat_{ColorUtility.ToHtmlStringRGB(color)}";
            return mat;
        }

        private GameObject BuildSofaPrefab()
        {
            GameObject root = new GameObject("Prefab_Sofa");
            root.transform.position = Vector3.zero;

            Material fabric = GetFallbackMaterial(new Color(0.24f, 0.35f, 0.45f)); // Slate Blue
            Material wood = GetFallbackMaterial(new Color(0.45f, 0.30f, 0.18f));   // Oak Legs

            // Base Seat (Y: 0.15 to 0.45)
            CreateBoxPart(root, "Base_Cushion", new Vector3(0, 0.30f, 0), new Vector3(2.0f, 0.30f, 0.90f), fabric);
            // Backrest (Y: 0.45 to 0.85)
            CreateBoxPart(root, "Backrest", new Vector3(0, 0.65f, -0.35f), new Vector3(2.0f, 0.40f, 0.20f), fabric);
            // Armrest Left & Right
            CreateBoxPart(root, "Armrest_L", new Vector3(-0.92f, 0.50f, 0), new Vector3(0.16f, 0.35f, 0.90f), fabric);
            CreateBoxPart(root, "Armrest_R", new Vector3(0.92f, 0.50f, 0), new Vector3(0.16f, 0.35f, 0.90f), fabric);
            // 4 Legs
            CreateBoxPart(root, "Leg_FL", new Vector3(-0.90f, 0.075f, 0.35f), new Vector3(0.08f, 0.15f, 0.08f), wood);
            CreateBoxPart(root, "Leg_FR", new Vector3(0.90f, 0.075f, 0.35f), new Vector3(0.08f, 0.15f, 0.08f), wood);
            CreateBoxPart(root, "Leg_BL", new Vector3(-0.90f, 0.075f, -0.35f), new Vector3(0.08f, 0.15f, 0.08f), wood);
            CreateBoxPart(root, "Leg_BR", new Vector3(0.90f, 0.075f, -0.35f), new Vector3(0.08f, 0.15f, 0.08f), wood);

            AddCompositeCollider(root, new Vector3(2.0f, 0.85f, 0.95f), new Vector3(0, 0.425f, 0));
            AttachInteractionComponents(root, "sofa");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildChairPrefab()
        {
            GameObject root = new GameObject("Prefab_Chair");
            Material fabric = GetFallbackMaterial(new Color(0.85f, 0.72f, 0.50f)); // Warm Sand
            Material metal = GetFallbackMaterial(new Color(0.15f, 0.15f, 0.15f));  // Matte Black

            CreateBoxPart(root, "Seat", new Vector3(0, 0.45f, 0), new Vector3(0.65f, 0.10f, 0.65f), fabric);
            CreateBoxPart(root, "Backrest", new Vector3(0, 0.75f, -0.27f), new Vector3(0.65f, 0.50f, 0.08f), fabric);
            // Legs
            CreateBoxPart(root, "Leg_FL", new Vector3(-0.26f, 0.20f, 0.26f), new Vector3(0.05f, 0.40f, 0.05f), metal);
            CreateBoxPart(root, "Leg_FR", new Vector3(0.26f, 0.20f, 0.26f), new Vector3(0.05f, 0.40f, 0.05f), metal);
            CreateBoxPart(root, "Leg_BL", new Vector3(-0.26f, 0.20f, -0.26f), new Vector3(0.05f, 0.40f, 0.05f), metal);
            CreateBoxPart(root, "Leg_BR", new Vector3(0.26f, 0.20f, -0.26f), new Vector3(0.05f, 0.40f, 0.05f), metal);

            AddCompositeCollider(root, new Vector3(0.70f, 0.90f, 0.70f), new Vector3(0, 0.45f, 0));
            AttachInteractionComponents(root, "chair");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildTablePrefab()
        {
            GameObject root = new GameObject("Prefab_Table");
            Material wood = GetFallbackMaterial(new Color(0.55f, 0.38f, 0.22f)); // Warm Walnut

            CreateBoxPart(root, "Tabletop", new Vector3(0, 0.725f, 0), new Vector3(1.60f, 0.05f, 0.90f), wood);
            CreateBoxPart(root, "Leg_FL", new Vector3(-0.72f, 0.35f, 0.38f), new Vector3(0.08f, 0.70f, 0.08f), wood);
            CreateBoxPart(root, "Leg_FR", new Vector3(0.72f, 0.35f, 0.38f), new Vector3(0.08f, 0.70f, 0.08f), wood);
            CreateBoxPart(root, "Leg_BL", new Vector3(-0.72f, 0.35f, -0.38f), new Vector3(0.08f, 0.70f, 0.08f), wood);
            CreateBoxPart(root, "Leg_BR", new Vector3(0.72f, 0.35f, -0.38f), new Vector3(0.08f, 0.70f, 0.08f), wood);

            AddCompositeCollider(root, new Vector3(1.60f, 0.75f, 0.90f), new Vector3(0, 0.375f, 0));
            AttachInteractionComponents(root, "table");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildBedPrefab()
        {
            GameObject root = new GameObject("Prefab_Bed");
            Material mattress = GetFallbackMaterial(new Color(0.92f, 0.92f, 0.94f));
            Material frame = GetFallbackMaterial(new Color(0.20f, 0.20f, 0.22f));

            CreateBoxPart(root, "BaseFrame", new Vector3(0, 0.20f, 0), new Vector3(1.70f, 0.25f, 2.10f), frame);
            CreateBoxPart(root, "Mattress", new Vector3(0, 0.45f, 0.05f), new Vector3(1.60f, 0.30f, 1.95f), mattress);
            CreateBoxPart(root, "Headboard", new Vector3(0, 0.65f, -0.98f), new Vector3(1.70f, 0.60f, 0.14f), frame);

            AddCompositeCollider(root, new Vector3(1.70f, 0.95f, 2.10f), new Vector3(0, 0.475f, 0));
            AttachInteractionComponents(root, "bed");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildCabinetPrefab()
        {
            GameObject root = new GameObject("Prefab_Cabinet");
            Material wood = GetFallbackMaterial(new Color(0.40f, 0.26f, 0.16f));
            Material handles = GetFallbackMaterial(new Color(0.85f, 0.75f, 0.35f));

            CreateBoxPart(root, "MainBody", new Vector3(0, 0.45f, 0), new Vector3(1.20f, 0.70f, 0.45f), wood);
            CreateBoxPart(root, "Leg_FL", new Vector3(-0.52f, 0.05f, 0.18f), new Vector3(0.06f, 0.10f, 0.06f), wood);
            CreateBoxPart(root, "Leg_FR", new Vector3(0.52f, 0.05f, 0.18f), new Vector3(0.06f, 0.10f, 0.06f), wood);
            CreateBoxPart(root, "Leg_BL", new Vector3(-0.52f, 0.05f, -0.18f), new Vector3(0.06f, 0.10f, 0.06f), wood);
            CreateBoxPart(root, "Leg_BR", new Vector3(0.52f, 0.05f, -0.18f), new Vector3(0.06f, 0.10f, 0.06f), wood);
            CreateBoxPart(root, "Handle_L", new Vector3(-0.10f, 0.50f, 0.24f), new Vector3(0.04f, 0.12f, 0.03f), handles);
            CreateBoxPart(root, "Handle_R", new Vector3(0.10f, 0.50f, 0.24f), new Vector3(0.04f, 0.12f, 0.03f), handles);

            AddCompositeCollider(root, new Vector3(1.20f, 0.80f, 0.45f), new Vector3(0, 0.40f, 0));
            AttachInteractionComponents(root, "cabinet");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildBookshelfPrefab()
        {
            GameObject root = new GameObject("Prefab_Bookshelf");
            Material wood = GetFallbackMaterial(new Color(0.88f, 0.85f, 0.80f)); // Light Birch

            CreateBoxPart(root, "Side_L", new Vector3(-0.43f, 0.925f, 0), new Vector3(0.04f, 1.85f, 0.35f), wood);
            CreateBoxPart(root, "Side_R", new Vector3(0.43f, 0.925f, 0), new Vector3(0.04f, 1.85f, 0.35f), wood);
            CreateBoxPart(root, "Back", new Vector3(0, 0.925f, -0.16f), new Vector3(0.86f, 1.85f, 0.03f), wood);

            for (int i = 0; i < 5; i++)
            {
                float y = 0.05f + (i * 0.42f);
                CreateBoxPart(root, $"Shelf_{i}", new Vector3(0, y, 0), new Vector3(0.86f, 0.04f, 0.34f), wood);
            }

            AddCompositeCollider(root, new Vector3(0.90f, 1.85f, 0.35f), new Vector3(0, 0.925f, 0));
            AttachInteractionComponents(root, "bookshelf");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildFloorLampPrefab()
        {
            GameObject root = new GameObject("Prefab_FloorLamp");
            Material metal = GetFallbackMaterial(new Color(0.2f, 0.2f, 0.2f));
            Material shade = GetFallbackMaterial(new Color(0.95f, 0.92f, 0.85f));

            CreateCylinderPart(root, "Base", new Vector3(0, 0.02f, 0), new Vector3(0.35f, 0.02f, 0.35f), metal);
            CreateCylinderPart(root, "Pole", new Vector3(0, 0.80f, 0), new Vector3(0.03f, 0.78f, 0.03f), metal);
            CreateCylinderPart(root, "Shade", new Vector3(0, 1.50f, 0), new Vector3(0.40f, 0.15f, 0.40f), shade);

            AddCompositeCollider(root, new Vector3(0.45f, 1.65f, 0.45f), new Vector3(0, 0.825f, 0));
            AttachInteractionComponents(root, "lamp");
            root.SetActive(false);
            return root;
        }

        private GameObject BuildIndoorPlantPrefab()
        {
            GameObject root = new GameObject("Prefab_IndoorPlant");
            Material pot = GetFallbackMaterial(new Color(0.85f, 0.85f, 0.85f));
            Material plant = GetFallbackMaterial(new Color(0.15f, 0.55f, 0.22f));

            CreateCylinderPart(root, "Pot", new Vector3(0, 0.20f, 0), new Vector3(0.32f, 0.20f, 0.32f), pot);
            CreateSpherePart(root, "Foliage_1", new Vector3(0, 0.65f, 0), new Vector3(0.55f, 0.45f, 0.55f), plant);
            CreateSpherePart(root, "Foliage_2", new Vector3(0.12f, 0.88f, -0.05f), new Vector3(0.40f, 0.35f, 0.40f), plant);

            AddCompositeCollider(root, new Vector3(0.55f, 1.10f, 0.55f), new Vector3(0, 0.55f, 0));
            AttachInteractionComponents(root, "plant");
            root.SetActive(false);
            return root;
        }

        private GameObject CreateBoxPart(GameObject parent, string name, Vector3 localPos, Vector3 localSize, Material mat)
        {
            GameObject part = GameObject.CreatePrimitive(PrimitiveType.Cube);
            part.name = name;
            part.transform.SetParent(parent.transform, false);
            part.transform.localPosition = localPos;
            part.transform.localScale = localSize;
            if (part.TryGetComponent<Collider>(out var col)) DestroyImmediate(col);
            if (part.TryGetComponent<Renderer>(out var ren)) ren.material = mat;
            return part;
        }

        private GameObject CreateCylinderPart(GameObject parent, string name, Vector3 localPos, Vector3 localSize, Material mat)
        {
            GameObject part = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            part.name = name;
            part.transform.SetParent(parent.transform, false);
            part.transform.localPosition = localPos;
            part.transform.localScale = localSize;
            if (part.TryGetComponent<Collider>(out var col)) DestroyImmediate(col);
            if (part.TryGetComponent<Renderer>(out var ren)) ren.material = mat;
            return part;
        }

        private GameObject CreateSpherePart(GameObject parent, string name, Vector3 localPos, Vector3 localSize, Material mat)
        {
            GameObject part = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            part.name = name;
            part.transform.SetParent(parent.transform, false);
            part.transform.localPosition = localPos;
            part.transform.localScale = localSize;
            if (part.TryGetComponent<Collider>(out var col)) DestroyImmediate(col);
            if (part.TryGetComponent<Renderer>(out var ren)) ren.material = mat;
            return part;
        }

        private void AddCompositeCollider(GameObject root, Vector3 totalSize, Vector3 center)
        {
            BoxCollider box = root.AddComponent<BoxCollider>();
            box.size = totalSize;
            box.center = center;
        }

        private void AttachInteractionComponents(GameObject root, string entityClass)
        {
            if (!root.TryGetComponent<Rigidbody>(out var rb))
            {
                rb = root.AddComponent<Rigidbody>();
            }
            rb.useGravity = false;
            rb.isKinematic = false;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

            if (!root.TryGetComponent<AntiGravityInteractable>(out var ag))
            {
                ag = root.AddComponent<AntiGravityInteractable>();
                ag.EntityClass = entityClass;
            }
        }

        #endregion

        #region Placement, Selection & Manipulation Actions

        public void SelectCatalogItem(int index)
        {
            if (catalogItems == null || catalogItems.Count == 0) return;
            selectedItemIndex = Mathf.Clamp(index, 0, catalogItems.Count - 1);
            OnCatalogItemSelected?.Invoke(catalogItems[selectedItemIndex]);
        }

        public GameObject SpawnFurniture(Vector3 worldPosition, Quaternion worldRotation)
        {
            FurnitureItem item = CurrentSelectedItem;
            if (item == null || item.prefab == null)
            {
                Debug.LogWarning("[SmartSpace AR] Cannot spawn: No item or prefab selected.");
                return null;
            }

            GameObject instance = Instantiate(item.prefab, worldPosition, worldRotation, furnitureRoot);
            instance.name = $"{item.itemName}_{placedInstances.Count + 1}";
            instance.transform.localScale = item.defaultScale;
            instance.SetActive(true);

            // Ensure AntiGravityInteractable is configured
            if (!instance.TryGetComponent<AntiGravityInteractable>(out var interactable))
            {
                interactable = instance.AddComponent<AntiGravityInteractable>();
            }
            interactable.EntityClass = item.itemName.ToLower();
            interactable.ConfigureZeroGDynamics();

            placedInstances.Add(instance);
            SelectPlacedObject(instance);

            OnFurniturePlaced?.Invoke(instance);
            return instance;
        }

        public void SelectPlacedObject(GameObject obj)
        {
            if (activeSelectedObject == obj) return;

            activeSelectedObject = obj;
            OnSelectionChanged?.Invoke(activeSelectedObject);
        }

        public void DeselectActiveObject()
        {
            activeSelectedObject = null;
            OnSelectionChanged?.Invoke(null);
        }

        public void DeleteSelected()
        {
            if (activeSelectedObject == null) return;

            GameObject target = activeSelectedObject;
            placedInstances.Remove(target);
            activeSelectedObject = null;

            OnFurnitureDeleted?.Invoke(target);
            OnSelectionChanged?.Invoke(null);

            Destroy(target);
        }

        public void RotateSelected(float angleDeg)
        {
            if (activeSelectedObject == null) return;
            activeSelectedObject.transform.Rotate(Vector3.up, angleDeg, Space.World);
        }

        public void ScaleSelected(float deltaMultiplier)
        {
            if (activeSelectedObject == null) return;
            Vector3 current = activeSelectedObject.transform.localScale;
            float newFactor = Mathf.Clamp(current.x * (1.0f + deltaMultiplier), 0.3f, 3.0f);
            activeSelectedObject.transform.localScale = Vector3.one * newFactor;
        }

        public void ClearAllPlaced()
        {
            DeselectActiveObject();
            for (int i = placedInstances.Count - 1; i >= 0; i--)
            {
                if (placedInstances[i] != null)
                {
                    Destroy(placedInstances[i]);
                }
            }
            placedInstances.Clear();
        }

        #endregion
    }
}
