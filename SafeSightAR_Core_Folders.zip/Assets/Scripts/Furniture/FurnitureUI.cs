using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SmartSpaceAR.AR;

namespace SmartSpaceAR.Furniture
{
    /// <summary>
    /// UI Controller for SmartSpace AR.
    /// Manages:
    /// 1. Top Bar (Title & AR/Simulation Mode Toggle)
    /// 2. Bottom Catalog Carousel (Horizontal scroll view with catalog buttons)
    /// 3. Floating Action Bar ([Rotate 45°], [Scale +/-], [Delete], [Deselect])
    /// Includes both uGUI bindings and an interactive OnGUI test HUD for instant zero-setup Play Mode.
    /// </summary>
    public class FurnitureUI : MonoBehaviour
    {
        [Header("uGUI Canvas References (Optional - Auto-detected)")]
        [SerializeField] private Canvas mainCanvas;
        [SerializeField] private GameObject topBarPanel;
        [SerializeField] private GameObject catalogPanel;
        [SerializeField] private GameObject actionBarPanel;
        [SerializeField] private Transform catalogScrollContent;
        [SerializeField] private GameObject catalogButtonPrefab;

        [Header("Action Bar Buttons")]
        [SerializeField] private Button rotateButton;
        [SerializeField] private Button scaleUpButton;
        [SerializeField] private Button scaleDownButton;
        [SerializeField] private Button deleteButton;
        [SerializeField] private Button deselectButton;
        [SerializeField] private Button modeToggleButton;
        [SerializeField] private Text modeText;

        [Header("Runtime Visual Settings")]
        [Tooltip("Enables built-in OnGUI fallback HUD so the UI works immediately without manual canvas setup.")]
        [SerializeField] private bool enableOnGUIFallback = true;

        private FurnitureManager manager;
        private ObjectControls controls;
        private bool isSimulationMode = true;
        private Vector2 catalogScrollPosition = Vector2.zero;

        private void Start()
        {
            manager = FurnitureManager.Instance;
            controls = FindFirstObjectByType<ObjectControls>();

            if (controls == null)
            {
                controls = gameObject.AddComponent<ObjectControls>();
            }

            if (manager != null)
            {
                manager.OnCatalogItemSelected += HandleCatalogItemSelected;
                manager.OnSelectionChanged += HandleSelectionChanged;
            }

            WireButtonCallbacks();
            UpdateActionBarVisibility(false);
            RefreshCatalogButtons();
        }

        private void OnDestroy()
        {
            if (manager != null)
            {
                manager.OnCatalogItemSelected -= HandleCatalogItemSelected;
                manager.OnSelectionChanged -= HandleSelectionChanged;
            }
        }

        private void WireButtonCallbacks()
        {
            if (rotateButton != null) rotateButton.onClick.AddListener(() => controls.RotateClockwise());
            if (scaleUpButton != null) scaleUpButton.onClick.AddListener(() => controls.ScaleUp());
            if (scaleDownButton != null) scaleDownButton.onClick.AddListener(() => controls.ScaleDown());
            if (deleteButton != null) deleteButton.onClick.AddListener(() => controls.DeleteSelected());
            if (deselectButton != null) deselectButton.onClick.AddListener(() => controls.Deselect());
            if (modeToggleButton != null) modeToggleButton.onClick.AddListener(ToggleMode);
        }

        public void ToggleMode()
        {
            isSimulationMode = !isSimulationMode;
            if (modeText != null)
            {
                modeText.text = isSimulationMode ? "MODE: SIMULATION" : "MODE: MOBILE AR";
            }

            if (ARManager.Instance != null)
            {
                ARManager.Instance.SetMode(isSimulationMode ? ExecutionMode.DesktopSimulation : ExecutionMode.MobileAR);
            }
        }

        private void HandleCatalogItemSelected(FurnitureItem item)
        {
            // Update highlight state in UI if needed
        }

        private void HandleSelectionChanged(GameObject selected)
        {
            UpdateActionBarVisibility(selected != null);
        }

        private void UpdateActionBarVisibility(bool visible)
        {
            if (actionBarPanel != null)
            {
                actionBarPanel.SetActive(visible);
            }
        }

        public void RefreshCatalogButtons()
        {
            if (catalogScrollContent == null || catalogButtonPrefab == null || manager == null) return;

            // Clear old buttons
            foreach (Transform child in catalogScrollContent)
            {
                Destroy(child.gameObject);
            }

            // Spawn button for each catalog item
            var items = manager.CatalogItems;
            for (int i = 0; i < items.Count; i++)
            {
                int index = i;
                FurnitureItem item = items[i];
                GameObject btnObj = Instantiate(catalogButtonPrefab, catalogScrollContent);
                btnObj.name = $"Btn_{item.itemName}";

                Button btn = btnObj.GetComponent<Button>();
                if (btn != null)
                {
                    btn.onClick.AddListener(() => manager.SelectCatalogItem(index));
                }

                Text label = btnObj.GetComponentInChildren<Text>();
                if (label != null)
                {
                    label.text = item.itemName;
                }

                Image img = btnObj.GetComponent<Image>();
                if (img != null && item.icon != null)
                {
                    img.sprite = item.icon;
                }
            }
        }

        #region Instant Interactive OnGUI Fallback HUD

        private void OnGUI()
        {
            if (!enableOnGUIFallback) return;

            manager = manager != null ? manager : FurnitureManager.Instance;
            if (manager == null) return;

            float screenW = Screen.width;
            float screenH = Screen.height;

            // --- 1. TOP BAR ---
            GUI.Box(new Rect(0, 0, screenW, 55), GUIContent.none);
            GUI.Label(new Rect(20, 15, 240, 30), "<b><size=18><color=#00e5ff>SMARTSPACE AR</color></size></b>");

            string modeLabel = isSimulationMode ? "MODE: SIMULATION (Desktop 3D)" : "MODE: MOBILE AR (Hardware)";
            Color modeColor = isSimulationMode ? new Color(0.2f, 1.0f, 0.6f) : new Color(1.0f, 0.7f, 0.2f);
            
            GUI.color = modeColor;
            if (GUI.Button(new Rect(screenW - 260, 10, 240, 35), $"<b>{modeLabel}</b>"))
            {
                ToggleMode();
            }
            GUI.color = Color.white;

            // --- 2. FLOATING ACTION BAR (When object is selected) ---
            if (manager.ActiveSelectedObject != null)
            {
                float panelW = 440;
                float panelH = 75;
                float panelX = (screenW - panelW) * 0.5f;
                float panelY = screenH - 180;

                GUI.Box(new Rect(panelX, panelY, panelW, panelH), GUIContent.none);
                GUI.Label(new Rect(panelX + 10, panelY + 5, 250, 20), $"<color=#00e5ff>Selected: {manager.ActiveSelectedObject.name}</color>");

                float btnW = 75;
                float btnY = panelY + 28;
                float startX = panelX + 15;

                if (GUI.Button(new Rect(startX, btnY, btnW, 35), "Rotate ⟲"))
                {
                    controls.RotateCounterClockwise();
                }
                if (GUI.Button(new Rect(startX + 82, btnY, btnW, 35), "Rotate ⟳"))
                {
                    controls.RotateClockwise();
                }
                if (GUI.Button(new Rect(startX + 164, btnY, 65, 35), "Scale +"))
                {
                    controls.ScaleUp();
                }
                if (GUI.Button(new Rect(startX + 234, btnY, 65, 35), "Scale -"))
                {
                    controls.ScaleDown();
                }
                GUI.color = new Color(1.0f, 0.35f, 0.35f);
                if (GUI.Button(new Rect(startX + 304, btnY, 60, 35), "Delete"))
                {
                    controls.DeleteSelected();
                }
                GUI.color = Color.white;
                if (GUI.Button(new Rect(startX + 369, btnY, 55, 35), "Done"))
                {
                    controls.Deselect();
                }
            }

            // --- 3. BOTTOM CATALOG PANEL ---
            float catH = 95;
            float catY = screenH - catH;
            GUI.Box(new Rect(0, catY, screenW, catH), GUIContent.none);

            var items = manager.CatalogItems;
            if (items != null && items.Count > 0)
            {
                float itemWidth = 115;
                float totalWidth = items.Count * (itemWidth + 10) + 20;

                catalogScrollPosition = GUI.BeginScrollView(
                    new Rect(0, catY + 5, screenW, 85),
                    catalogScrollPosition,
                    new Rect(0, 0, totalWidth, 75)
                );

                for (int i = 0; i < items.Count; i++)
                {
                    int idx = i;
                    FurnitureItem item = items[i];
                    bool isSelected = (idx == manager.SelectedItemIndex);

                    if (isSelected) GUI.color = new Color(0.2f, 0.9f, 1.0f);
                    else GUI.color = Color.white;

                    Rect btnRect = new Rect(10 + (i * (itemWidth + 10)), 5, itemWidth, 65);
                    string text = $"<b>{item.itemName}</b>\n<size=10>${item.price:F0} | {item.category}</size>";

                    if (GUI.Button(btnRect, text))
                    {
                        manager.SelectCatalogItem(idx);
                    }
                }

                GUI.color = Color.white;
                GUI.EndScrollView();
            }

            // Quick instructions overlay in top-left
            GUI.Label(new Rect(20, 65, 380, 50), "<size=11><color=#cccccc>Left-Click floor: Place Item | Left-Click object: Pick/Levitate\nScroll-Wheel: Depth in Zero-G | Right-Click + WASD: Room Cam</color></size>");
        }

        #endregion
    }
}
