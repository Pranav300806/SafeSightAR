using System;
using UnityEngine;

namespace SmartSpaceAR.Furniture
{
    /// <summary>
    /// Component managing interactive transform operations (Rotate, Scale, Delete)
    /// and visual bounding selection rings for the currently active furniture object.
    /// </summary>
    public class ObjectControls : MonoBehaviour
    {
        [Header("Transform Step Settings")]
        [Tooltip("Degrees to rotate per single rotation click.")]
        [SerializeField] private float rotationStepDegrees = 45.0f;

        [Tooltip("Scale delta multiplier applied per scale button press (e.g., 0.10 = +10%).")]
        [SerializeField] private float scaleDelta = 0.10f;

        [Header("Selection Visualizer")]
        [Tooltip("Color of the selection footprint ring / wireframe.")]
        [SerializeField] private Color selectionColor = new Color(0.0f, 0.85f, 1.0f, 0.8f);

        [Tooltip("LineRenderer or dynamic indicator showing selected object bounds.")]
        [SerializeField] private LineRenderer selectionRing;

        private GameObject currentSelected;

        private void Start()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.OnSelectionChanged += HandleSelectionChanged;
            }

            CreateSelectionRing();
            UpdateVisualRing(null);
        }

        private void OnDestroy()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.OnSelectionChanged -= HandleSelectionChanged;
            }
        }

        private void Update()
        {
            if (currentSelected != null && selectionRing != null && selectionRing.enabled)
            {
                UpdateRingTransform(currentSelected);
            }
        }

        private void HandleSelectionChanged(GameObject selected)
        {
            currentSelected = selected;
            UpdateVisualRing(selected);
        }

        private void CreateSelectionRing()
        {
            if (selectionRing != null) return;

            GameObject ringObj = new GameObject("[Selection_Ring_Indicator]");
            ringObj.transform.SetParent(transform, false);

            selectionRing = ringObj.AddComponent<LineRenderer>();
            selectionRing.useWorldSpace = true;
            selectionRing.loop = true;
            selectionRing.startWidth = 0.025f;
            selectionRing.endWidth = 0.025f;

            Material ringMat = new Material(Shader.Find("Sprites/Default") ?? Shader.Find("Universal Render Pipeline/Unlit") ?? Shader.Find("Unlit/Color"));
            ringMat.color = selectionColor;
            selectionRing.material = ringMat;
            selectionRing.positionCount = 36;
            selectionRing.enabled = false;
        }

        private void UpdateVisualRing(GameObject selected)
        {
            if (selectionRing == null) return;

            if (selected == null)
            {
                selectionRing.enabled = false;
                return;
            }

            selectionRing.enabled = true;
            UpdateRingTransform(selected);
        }

        private void UpdateRingTransform(GameObject selected)
        {
            Bounds bounds = CalculateBounds(selected);
            float radius = Mathf.Max(bounds.extents.x, bounds.extents.z) * 1.25f;
            Vector3 center = new Vector3(bounds.center.x, bounds.min.y + 0.015f, bounds.center.z);

            int segments = selectionRing.positionCount;
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                Vector3 pos = center + new Vector3(Mathf.Cos(angle) * radius, 0, Mathf.Sin(angle) * radius);
                selectionRing.SetPosition(i, pos);
            }
        }

        private Bounds CalculateBounds(GameObject target)
        {
            Renderer[] renderers = target.GetComponentsInChildren<Renderer>();
            if (renderers.Length > 0)
            {
                Bounds b = renderers[0].bounds;
                for (int i = 1; i < renderers.Length; i++)
                {
                    b.Encapsulate(renderers[i].bounds);
                }
                return b;
            }
            return new Bounds(target.transform.position, Vector3.one * 0.5f);
        }

        #region Public Actions Hooked to UI Buttons

        public void RotateClockwise()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.RotateSelected(rotationStepDegrees);
            }
        }

        public void RotateCounterClockwise()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.RotateSelected(-rotationStepDegrees);
            }
        }

        public void ScaleUp()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.ScaleSelected(scaleDelta);
            }
        }

        public void ScaleDown()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.ScaleSelected(-scaleDelta);
            }
        }

        public void DeleteSelected()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.DeleteSelected();
            }
        }

        public void Deselect()
        {
            if (FurnitureManager.Instance != null)
            {
                FurnitureManager.Instance.DeselectActiveObject();
            }
        }

        #endregion
    }
}
