using System;
using UnityEngine;

namespace SafeSightAR.RiskEngine
{
    public enum HazardType
    {
        SpillHazard,
        FallCutHazard,
        TripHazardDrawer,
        TripHazardCable
    }

    public enum HazardSeverity
    {
        Low,
        Medium,
        Critical
    }

    /// <summary>
    /// Configuration data model for a contextual risk rule.
    /// Specifies target object labels, dynamic distance thresholds, persistence duration, 
    /// severity level, and user guidance text.
    /// </summary>
    [Serializable]
    public class HazardRule
    {
        public string ruleId;
        public string ruleName;
        public HazardType type;
        public string primaryTargetLabel;   // e.g., "bottle", "knife", "drawer", "cable"
        public string secondaryTargetLabel; // e.g., "laptop", "table_edge", "walkway"
        
        [Tooltip("Distance threshold in meters for triggering risk.")]
        public float distanceThresholdMeters; 

        [Tooltip("Persistence duration in seconds required before triggering (debouncing).")]
        public float minPersistenceSeconds = 0.5f;

        public HazardSeverity defaultSeverity;
        public string warningMessage;
        public string actionRecommendation;

        public HazardRule(
            string ruleId, 
            string ruleName, 
            HazardType type, 
            string primaryLabel, 
            string secondaryLabel, 
            float distanceThresholdMeters, 
            float minPersistenceSeconds, 
            HazardSeverity defaultSeverity, 
            string warningMessage, 
            string actionRecommendation)
        {
            this.ruleId = ruleId;
            this.ruleName = ruleName;
            this.type = type;
            this.primaryTargetLabel = primaryLabel;
            this.secondaryTargetLabel = secondaryLabel;
            this.distanceThresholdMeters = distanceThresholdMeters;
            this.minPersistenceSeconds = minPersistenceSeconds;
            this.defaultSeverity = defaultSeverity;
            this.warningMessage = warningMessage;
            this.actionRecommendation = actionRecommendation;
        }
    }

    /// <summary>
    /// Evaluated runtime alert snapshot.
    /// </summary>
    public class HazardAlert
    {
        public string alertId;
        public HazardRule rule;
        public HazardSeverity severity;
        public string primaryLabel;
        public string secondaryLabel;
        public Vector3 primaryWorldPos;
        public Vector3 secondaryWorldPos;
        public float currentDistanceMeters;
        public float persistenceTime;
        public DateTime timestamp;
        public bool isDebouncedActive;

        public HazardAlert(
            HazardRule rule, 
            HazardSeverity severity, 
            Vector3 primaryPos, 
            Vector3 secondaryPos, 
            float distanceMeters, 
            float persistenceTime)
        {
            this.alertId = $"{rule.ruleId}_{Guid.NewGuid().ToString().Substring(0, 5)}";
            this.rule = rule;
            this.severity = severity;
            this.primaryLabel = rule.primaryTargetLabel;
            this.secondaryLabel = rule.secondaryTargetLabel;
            this.primaryWorldPos = primaryPos;
            this.secondaryWorldPos = secondaryPos;
            this.currentDistanceMeters = distanceMeters;
            this.persistenceTime = persistenceTime;
            this.timestamp = DateTime.Now;
            this.isDebouncedActive = persistenceTime >= rule.minPersistenceSeconds;
        }
    }
}
