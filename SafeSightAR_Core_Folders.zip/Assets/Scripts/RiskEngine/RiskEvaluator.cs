using System;
using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.Vision;

namespace SafeSightAR.RiskEngine
{
    /// <summary>
    /// Contextual Risk Evaluator Engine.
    /// Evaluates spatial relationships against rules, calculates severity, 
    /// and debounces hazard state persistence (min 0.5s) to eliminate flickering alerts.
    /// </summary>
    public class RiskEvaluator : MonoBehaviour
    {
        [Header("Rule Configurations")]
        [SerializeField] private float spillDistanceThreshold = 0.15f; // 15 cm
        [SerializeField] private float knifeEdgeThreshold = 0.05f;     // 5 cm
        [SerializeField] private float debounceMinDuration = 0.5f;     // 0.5 seconds

        public static RiskEvaluator Instance { get; private set; }

        public event Action<List<HazardAlert>> OnHazardAlertsUpdated;

        private List<HazardRule> rules = new List<HazardRule>();
        private Dictionary<string, float> ruleDebounceTimers = new Dictionary<string, float>();
        private List<HazardAlert> activeAlerts = new List<HazardAlert>();

        public List<HazardAlert> ActiveAlerts => activeAlerts;

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            InitializeRules();
        }

        private void InitializeRules()
        {
            rules.Add(new HazardRule(
                "RULE_SPILL_01",
                "Liquid Spill Hazard",
                HazardType.SpillHazard,
                "bottle",
                "laptop",
                spillDistanceThreshold,
                debounceMinDuration,
                HazardSeverity.Critical,
                "Spill Risk Detected!",
                "Move bottle at least 15cm away from laptop or electronics."
            ));

            rules.Add(new HazardRule(
                "RULE_EDGE_01",
                "Sharp Edge Fall Hazard",
                HazardType.FallCutHazard,
                "knife",
                "table_edge",
                knifeEdgeThreshold,
                debounceMinDuration,
                HazardSeverity.Critical,
                "Knife Near Table Edge!",
                "Push knife toward table center to prevent accidental falling or cut injury."
            ));

            rules.Add(new HazardRule(
                "RULE_TRIP_DRAWER",
                "Open Drawer Obstruction",
                HazardType.TripHazardDrawer,
                "drawer",
                "walkway",
                0.20f,
                debounceMinDuration,
                HazardSeverity.Medium,
                "Open Drawer Trip Hazard!",
                "Close open drawer obstructing walkway."
            ));

            rules.Add(new HazardRule(
                "RULE_TRIP_CABLE",
                "Exposed Trailing Cable",
                HazardType.TripHazardCable,
                "cable",
                "walkway",
                0.15f,
                debounceMinDuration,
                HazardSeverity.Medium,
                "Cable Trip Hazard!",
                "Secure or route trailing cable away from walking path."
            ));
        }

        private void Update()
        {
            // Update active debounce timers
            float dt = Time.deltaTime;
            List<string> keys = new List<string>(ruleDebounceTimers.Keys);
            foreach (var key in keys)
            {
                ruleDebounceTimers[key] += dt;
            }
        }

        /// <summary>
        /// Evaluates current tracked spatial objects against all active hazard rules.
        /// </summary>
        public List<HazardAlert> EvaluateSpatialFrame(
            List<TrackedSpatialObject> trackedObjects, 
            Bounds tableBounds, 
            Bounds walkwayBounds)
        {
            List<HazardAlert> frameAlerts = new List<HazardAlert>();
            HashSet<string> currentFrameActiveRuleKeys = new HashSet<string>();

            // 1. Evaluate Spill Hazard (Bottle + Laptop)
            List<TrackedSpatialObject> bottles = trackedObjects.FindAll(o => o.label == "bottle");
            List<TrackedSpatialObject> laptops = trackedObjects.FindAll(o => o.label == "laptop");

            HazardRule spillRule = rules.Find(r => r.type == HazardType.SpillHazard);
            foreach (var bottle in bottles)
            {
                foreach (var laptop in laptops)
                {
                    float dist = SpatialRelationshipAnalyzer.ComputeEuclideanDistance(bottle.worldPosition, laptop.worldPosition);
                    if (dist <= spillRule.distanceThresholdMeters)
                    {
                        string ruleKey = $"SPILL_{bottle.id}_{laptop.id}";
                        currentFrameActiveRuleKeys.Add(ruleKey);

                        if (!ruleDebounceTimers.ContainsKey(ruleKey)) ruleDebounceTimers[ruleKey] = 0.0f;
                        float persistence = ruleDebounceTimers[ruleKey];

                        HazardSeverity severity = dist < 0.08f ? HazardSeverity.Critical : HazardSeverity.Medium;
                        HazardAlert alert = new HazardAlert(spillRule, severity, bottle.worldPosition, laptop.worldPosition, dist, persistence);
                        frameAlerts.Add(alert);
                    }
                }
            }

            // 2. Evaluate Knife Near Table Edge
            List<TrackedSpatialObject> knives = trackedObjects.FindAll(o => o.label == "knife");
            HazardRule edgeRule = rules.Find(r => r.type == HazardType.FallCutHazard);
            foreach (var knife in knives)
            {
                float edgeOffset = SpatialRelationshipAnalyzer.ComputeTableEdgeProximity(knife.worldPosition, tableBounds);
                if (edgeOffset <= edgeRule.distanceThresholdMeters)
                {
                    string ruleKey = $"EDGE_{knife.id}";
                    currentFrameActiveRuleKeys.Add(ruleKey);

                    if (!ruleDebounceTimers.ContainsKey(ruleKey)) ruleDebounceTimers[ruleKey] = 0.0f;
                    float persistence = ruleDebounceTimers[ruleKey];

                    Vector3 nearestEdgePoint = knife.worldPosition + Vector3.forward * edgeOffset;
                    HazardSeverity severity = edgeOffset < 0.02f ? HazardSeverity.Critical : HazardSeverity.Medium;
                    HazardAlert alert = new HazardAlert(edgeRule, severity, knife.worldPosition, nearestEdgePoint, edgeOffset, persistence);
                    frameAlerts.Add(alert);
                }
            }

            // 3. Evaluate Open Drawer Walkway Trip Hazard
            List<TrackedSpatialObject> drawers = trackedObjects.FindAll(o => o.label == "drawer");
            HazardRule drawerRule = rules.Find(r => r.type == HazardType.TripHazardDrawer);
            foreach (var drawer in drawers)
            {
                float overlap;
                if (SpatialRelationshipAnalyzer.CheckWalkwayIntersection(drawer.worldBounds, walkwayBounds, out overlap))
                {
                    string ruleKey = $"TRIP_DRAWER_{drawer.id}";
                    currentFrameActiveRuleKeys.Add(ruleKey);

                    if (!ruleDebounceTimers.ContainsKey(ruleKey)) ruleDebounceTimers[ruleKey] = 0.0f;
                    float persistence = ruleDebounceTimers[ruleKey];

                    HazardAlert alert = new HazardAlert(drawerRule, HazardSeverity.Medium, drawer.worldPosition, walkwayBounds.center, overlap, persistence);
                    frameAlerts.Add(alert);
                }
            }

            // 4. Evaluate Cable Walking Path Crossing
            List<TrackedSpatialObject> cables = trackedObjects.FindAll(o => o.label == "cable");
            HazardRule cableRule = rules.Find(r => r.type == HazardType.TripHazardCable);
            foreach (var cable in cables)
            {
                float overlap;
                if (SpatialRelationshipAnalyzer.CheckWalkwayIntersection(cable.worldBounds, walkwayBounds, out overlap))
                {
                    string ruleKey = $"TRIP_CABLE_{cable.id}";
                    currentFrameActiveRuleKeys.Add(ruleKey);

                    if (!ruleDebounceTimers.ContainsKey(ruleKey)) ruleDebounceTimers[ruleKey] = 0.0f;
                    float persistence = ruleDebounceTimers[ruleKey];

                    HazardAlert alert = new HazardAlert(cableRule, HazardSeverity.Medium, cable.worldPosition, walkwayBounds.center, overlap, persistence);
                    frameAlerts.Add(alert);
                }
            }

            // Remove expired rule timers
            List<string> activeKeys = new List<string>(ruleDebounceTimers.Keys);
            foreach (var k in activeKeys)
            {
                if (!currentFrameActiveRuleKeys.Contains(k))
                {
                    ruleDebounceTimers.Remove(k);
                }
            }

            // Filter debounced active alerts (persistence >= minPersistenceSeconds)
            activeAlerts = frameAlerts.FindAll(a => a.isDebouncedActive);
            OnHazardAlertsUpdated?.Invoke(activeAlerts);

            return frameAlerts;
        }
    }
}
