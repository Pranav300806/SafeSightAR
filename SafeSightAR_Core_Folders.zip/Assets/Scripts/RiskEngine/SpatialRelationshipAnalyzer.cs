using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.Vision;

namespace SafeSightAR.RiskEngine
{
    public struct TrackedSpatialObject
    {
        public string id;
        public string label;
        public Vector3 worldPosition;
        public Bounds worldBounds;
        public Rect screenRect;
        public float confidence;
        public bool is3DAnchored;

        public TrackedSpatialObject(string id, string label, Vector3 worldPosition, Bounds worldBounds, Rect screenRect, float confidence, bool is3DAnchored)
        {
            this.id = id;
            this.label = label;
            this.worldPosition = worldPosition;
            this.worldBounds = worldBounds;
            this.screenRect = screenRect;
            this.confidence = confidence;
            this.is3DAnchored = is3DAnchored;
        }
    }

    /// <summary>
    /// Spatial Relationship Analyzer Engine.
    /// Converts 2D detections into estimated 3D spatial points using depth maps, raycasting,
    /// or collider heuristics. Evaluates spatial metrics: Euclidean distance, 
    /// edge proximity, and ray-bounding box walkway intersections.
    /// </summary>
    public class SpatialRelationshipAnalyzer : MonoBehaviour
    {
        [Header("Sensor & Camera Setup")]
        [SerializeField] private Camera mainCamera;
        [SerializeField] private LayerMask planeLayerMask;
        [SerializeField] private LayerMask objectLayerMask;

        public static SpatialRelationshipAnalyzer Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            if (mainCamera == null) mainCamera = Camera.main;
        }

        /// <summary>
        /// Projects 2D detection boxes into estimated 3D spatial points in world space.
        /// </summary>
        public List<TrackedSpatialObject> Process2DDetectionsTo3D(List<DetectionResult> detections)
        {
            List<TrackedSpatialObject> trackedObjects = new List<TrackedSpatialObject>();
            if (detections == null || mainCamera == null) return trackedObjects;

            int index = 0;
            foreach (var det in detections)
            {
                Vector2 screenCenter = new Vector2(
                    det.rect.x + det.rect.width * 0.5f,
                    det.rect.y + det.rect.height * 0.5f
                );

                Vector3 estimatedWorldPos;
                Bounds estimatedBounds;
                bool anchored = Estimate3DPosition(screenCenter, det.label, out estimatedWorldPos, out estimatedBounds);

                string objId = $"{det.label}_{index++}";
                trackedObjects.Add(new TrackedSpatialObject(
                    objId,
                    det.label,
                    estimatedWorldPos,
                    estimatedBounds,
                    det.rect,
                    det.confidence,
                    anchored
                ));
            }

            return trackedObjects;
        }

        /// <summary>
        /// Raycasts from screen pixel coordinates into world space using physics colliders or camera plane projection.
        /// </summary>
        public bool Estimate3DPosition(Vector2 screenPixelPos, string label, out Vector3 worldPos, out Bounds bounds)
        {
            // Convert GUI Y-coordinate (top-left origin) to Unity Screen point (bottom-left origin)
            Vector2 unityScreenPos = new Vector2(screenPixelPos.x, Screen.height - screenPixelPos.y);
            Ray ray = mainCamera.ScreenPointToRay(unityScreenPos);

            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, 20.0f, objectLayerMask | planeLayerMask))
            {
                worldPos = hit.point;
                bounds = hit.collider != null ? hit.collider.bounds : new Bounds(worldPos, Vector3.one * 0.2f);
                return true;
            }

            // Fallback: Plane Raycast at table/floor level (Y = 0.8m for table, Y = 0m for floor)
            float defaultY = (label == "drawer" || label == "cable" || label == "wet_surface") ? 0.0f : 0.75f;
            Plane fallbackPlane = new Plane(Vector3.up, new Vector3(0, defaultY, 0));
            float enter;
            if (fallbackPlane.Raycast(ray, out enter))
            {
                worldPos = ray.GetPoint(enter);
                bounds = new Bounds(worldPos, Vector3.one * 0.15f);
                return true;
            }

            worldPos = ray.GetPoint(1.5f);
            bounds = new Bounds(worldPos, Vector3.one * 0.15f);
            return false;
        }

        /// <summary>
        /// Computes 3D Euclidean distance between two spatial objects ($\Delta d$).
        /// </summary>
        public static float ComputeEuclideanDistance(Vector3 posA, Vector3 posB)
        {
            return Vector3.Distance(posA, posB);
        }

        /// <summary>
        /// Computes closest distance between an object point and a 3D table perimeter / plane edge.
        /// </summary>
        public static float ComputeTableEdgeProximity(Vector3 objectPos, Bounds tableBounds)
        {
            Vector3 min = tableBounds.min;
            Vector3 max = tableBounds.max;

            // Distance to table perimeter along horizontal X/Z axes
            float distMinX = Mathf.Abs(objectPos.x - min.x);
            float distMaxX = Mathf.Abs(objectPos.x - max.x);
            float distMinZ = Mathf.Abs(objectPos.z - min.z);
            float distMaxZ = Mathf.Abs(objectPos.z - max.z);

            return Mathf.Min(distMinX, distMaxX, distMinZ, distMaxZ);
        }

        /// <summary>
        /// Evaluates whether an open drawer or cable intersects a designated walking vector bounds.
        /// </summary>
        public static bool CheckWalkwayIntersection(Bounds hazardBounds, Bounds walkwayBounds, out float overlapVolume)
        {
            overlapVolume = 0.0f;
            if (!hazardBounds.Intersects(walkwayBounds)) return false;

            Vector3 minIntersection = Vector3.Max(hazardBounds.min, walkwayBounds.min);
            Vector3 maxIntersection = Vector3.Min(hazardBounds.max, walkwayBounds.max);
            Vector3 size = maxIntersection - minIntersection;

            if (size.x > 0 && size.y > 0 && size.z > 0)
            {
                overlapVolume = size.x * size.y * size.z;
                return true;
            }

            return false;
        }
    }
}
