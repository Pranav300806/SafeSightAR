using System;
using UnityEngine;

namespace SmartSpaceAR.Simulation
{
    /// <summary>
    /// Implements Zero-G ("Anti-Gravity") dynamics, damped spring levitation,
    /// and mouse raycast dragging/scrolling for simulated AR furniture and hazard entities.
    /// Operates completely locally in-editor without AR hardware, external web servers, or network bridges.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    [SelectionBase]
    public class AntiGravityInteractable : MonoBehaviour
    {
        [Header("Zero-G & Damping Physics")]
        [Tooltip("Linear velocity resistance applied when floating in zero-gravity.")]
        [SerializeField, Range(0.1f, 15f)] private float linearDamping = 4.0f;

        [Tooltip("Rotational velocity resistance preventing uncontrolled spins.")]
        [SerializeField, Range(0.1f, 15f)] private float angularDamping = 3.5f;

        [Tooltip("Hooke's spring constant (k) pulling the object toward the hovered mouse ray target.")]
        [SerializeField, Range(1f, 150f)] private float springStiffness = 65.0f;

        [Tooltip("Critical damping coefficient (c) preventing harmonic overshooting and oscillations.")]
        [SerializeField, Range(0.1f, 30f)] private float springDamping = 14.0f;

        [Tooltip("Maximum linear force acceleration that can be exerted by the spring levitator.")]
        [SerializeField] private float maxLevitationForce = 80.0f;

        [Tooltip("Torque restoring stiffness keeping the object naturally upright while floating.")]
        [SerializeField, Range(0f, 50f)] private float uprightStiffness = 15.0f;

        [Header("Raycast Levitation & Depth Manipulation")]
        [Tooltip("Minimum allowed distance along the camera ray (meters).")]
        [SerializeField] private float minDepth = 0.4f;

        [Tooltip("Maximum allowed distance along the camera ray (meters).")]
        [SerializeField] private float maxDepth = 6.0f;

        [Tooltip("Mouse scroll sensitivity for pushing/pulling the object along the view ray.")]
        [SerializeField] private float scrollSensitivity = 0.8f;

        [Header("Entity Metadata")]
        [Tooltip("Semantic object label (e.g., sofa, chair, table, bottle, laptop, knife).")]
        [SerializeField] private string entityClass = "furniture";

        [Tooltip("Simulated perception confidence score [0.0 - 1.0].")]
        [SerializeField, Range(0.1f, 1.0f)] private float detectionConfidence = 0.98f;

        [Tooltip("Unique runtime identifier for tracking spatial frame identity.")]
        [SerializeField] private string entityId;

        [Header("Visual Feedback")]
        [SerializeField] private Renderer primaryRenderer;
        [SerializeField] private Color hoverGlowColor = new Color(0.2f, 0.8f, 1.0f, 0.35f);

        // Runtime Physics & Interaction State
        private Rigidbody rb;
        private Camera activeCamera;
        private bool isGrabbed = false;
        private float currentTargetDepth = 1.5f;
        private Vector3 targetAnchorPosition;
        private Quaternion targetAnchorRotation;
        private Quaternion originalRotation;

        // Public Events
        public event Action<AntiGravityInteractable> OnInteractionGrabbed;
        public event Action<AntiGravityInteractable> OnInteractionReleased;

        #region Public Accessors

        public string EntityClass
        {
            get => entityClass;
            set => entityClass = value;
        }

        public float DetectionConfidence
        {
            get => detectionConfidence;
            set => detectionConfidence = Mathf.Clamp01(value);
        }

        public string EntityId => entityId;
        public bool IsGrabbed => isGrabbed;
        public Rigidbody AttachedRigidbody => rb;
        public Vector3 TargetAnchorPosition => targetAnchorPosition;

        public Bounds WorldBounds
        {
            get
            {
                Collider[] colliders = GetComponentsInChildren<Collider>();
                if (colliders.Length > 0)
                {
                    Bounds combinedBounds = colliders[0].bounds;
                    for (int i = 1; i < colliders.Length; i++)
                    {
                        if (colliders[i].enabled)
                            combinedBounds.Encapsulate(colliders[i].bounds);
                    }
                    return combinedBounds;
                }

                Renderer[] renderers = GetComponentsInChildren<Renderer>();
                if (renderers.Length > 0)
                {
                    Bounds combinedBounds = renderers[0].bounds;
                    for (int i = 1; i < renderers.Length; i++)
                    {
                        if (renderers[i].enabled)
                            combinedBounds.Encapsulate(renderers[i].bounds);
                    }
                    return combinedBounds;
                }

                return new Bounds(transform.position, Vector3.one * 0.2f);
            }
        }

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
            ConfigureZeroGDynamics();

            if (string.IsNullOrEmpty(entityId))
            {
                entityId = $"{entityClass}_{Guid.NewGuid().ToString().Substring(0, 6)}";
            }

            if (primaryRenderer == null)
            {
                primaryRenderer = GetComponentInChildren<Renderer>();
            }

            originalRotation = transform.rotation;
        }

        private void OnValidate()
        {
            if (rb == null) rb = GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.useGravity = false;
            }
        }

        private void Start()
        {
            FindActiveCamera();
        }

        private void Update()
        {
            FindActiveCamera();
            HandleInputInteraction();
        }

        private void FixedUpdate()
        {
            ApplyZeroGStabilization();

            if (isGrabbed)
            {
                ApplySpringLevitationForces();
                ApplyUprightRestorationTorque();
            }
        }

        #endregion

        #region Physics Configuration

        /// <summary>
        /// Configures the Rigidbody in Zero-G levitation mode with linear/angular damping.
        /// </summary>
        public void ConfigureZeroGDynamics()
        {
            if (rb == null) rb = GetComponent<Rigidbody>();

            rb.useGravity = false;
            rb.linearDamping = linearDamping;
            rb.angularDamping = angularDamping;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        }

        private void ApplyZeroGStabilization()
        {
            rb.linearDamping = linearDamping;
            rb.angularDamping = angularDamping;
        }

        /// <summary>
        /// Evaluates damped harmonic spring equation: F = -k * x - c * v
        /// Pulls the rigid body smoothly toward the mouse ray target anchor.
        /// </summary>
        private void ApplySpringLevitationForces()
        {
            Vector3 currentPos = rb.position;
            Vector3 displacement = targetAnchorPosition - currentPos;

            Vector3 springForce = (displacement * springStiffness) - (rb.linearVelocity * springDamping);

            if (springForce.magnitude > maxLevitationForce)
            {
                springForce = springForce.normalized * maxLevitationForce;
            }

            rb.AddForce(springForce, ForceMode.Acceleration);
        }

        private void ApplyUprightRestorationTorque()
        {
            if (uprightStiffness <= 0.01f) return;

            Quaternion deltaRot = targetAnchorRotation * Quaternion.Inverse(rb.rotation);
            deltaRot.ToAngleAxis(out float angleDeg, out Vector3 axis);

            if (angleDeg > 180f) angleDeg -= 360f;

            if (Mathf.Abs(angleDeg) > 0.01f && !float.IsNaN(axis.x))
            {
                Vector3 angularSpringTorque = (axis.normalized * (angleDeg * Mathf.Deg2Rad * uprightStiffness))
                                              - (rb.angularVelocity * (springDamping * 0.5f));
                rb.AddTorque(angularSpringTorque, ForceMode.Acceleration);
            }
        }

        #endregion

        #region Interaction & Depth Manipulation

        private void FindActiveCamera()
        {
            if (activeCamera == null || !activeCamera.gameObject.activeInHierarchy)
            {
                activeCamera = Camera.main ?? FindFirstObjectByType<Camera>();
            }
        }

        private void HandleInputInteraction()
        {
            if (activeCamera == null) return;

            // Grab Initiation via Mouse Down
            if (Input.GetMouseButtonDown(0))
            {
                Ray mouseRay = activeCamera.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(mouseRay, out RaycastHit hit, 50f))
                {
                    if (hit.collider.transform == transform || hit.collider.transform.IsChildOf(transform))
                    {
                        StartLevitation(hit.point, hit.distance);
                    }
                }
            }

            // Continuous Drag & Depth Adjustments
            if (isGrabbed && Input.GetMouseButton(0))
            {
                // Mouse Scroll Wheel adjusts depth along camera forward ray
                float scroll = Input.mouseScrollDelta.y;
                if (Mathf.Abs(scroll) > 0.001f)
                {
                    currentTargetDepth += scroll * scrollSensitivity * 0.25f;
                    currentTargetDepth = Mathf.Clamp(currentTargetDepth, minDepth, maxDepth);
                }

                // Project target anchor along camera view ray
                Ray mouseRay = activeCamera.ScreenPointToRay(Input.mousePosition);
                targetAnchorPosition = mouseRay.origin + (mouseRay.direction * currentTargetDepth);
            }

            // Release on Mouse Up
            if (isGrabbed && Input.GetMouseButtonUp(0))
            {
                EndLevitation();
            }
        }

        public void StartLevitation(Vector3 worldHitPoint, float initialDepth)
        {
            isGrabbed = true;
            currentTargetDepth = Mathf.Clamp(initialDepth, minDepth, maxDepth);
            targetAnchorPosition = worldHitPoint;
            targetAnchorRotation = transform.rotation;

            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            // Notify FurnitureManager selection
            if (SmartSpaceAR.Furniture.FurnitureManager.Instance != null)
            {
                SmartSpaceAR.Furniture.FurnitureManager.Instance.SelectPlacedObject(gameObject);
            }

            OnInteractionGrabbed?.Invoke(this);
        }

        public void EndLevitation()
        {
            isGrabbed = false;
            OnInteractionReleased?.Invoke(this);
        }

        public void TeleportToPosition(Vector3 newWorldPosition, Quaternion newWorldRotation)
        {
            if (rb != null)
            {
                rb.position = newWorldPosition;
                rb.rotation = newWorldRotation;
                rb.linearVelocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
            else
            {
                transform.position = newWorldPosition;
                transform.rotation = newWorldRotation;
            }

            targetAnchorPosition = newWorldPosition;
            targetAnchorRotation = newWorldRotation;
        }

        #endregion

        #region Debug & Gizmos

        private void OnDrawGizmos()
        {
            Bounds b = WorldBounds;
            Gizmos.color = isGrabbed ? new Color(0.2f, 0.9f, 1f, 0.7f) : new Color(0.1f, 0.8f, 0.4f, 0.35f);
            Gizmos.DrawWireCube(b.center, b.size);

            if (isGrabbed)
            {
                Gizmos.color = Color.cyan;
                Gizmos.DrawLine(transform.position, targetAnchorPosition);
                Gizmos.DrawWireSphere(targetAnchorPosition, 0.04f);
            }
        }

        #endregion
    }
}

namespace SafeSightAR.Simulation
{
    // Type forwarding alias ensuring backwards compatibility with SafeSight AR simulation scripts
    public class AntiGravityInteractable : SmartSpaceAR.Simulation.AntiGravityInteractable
    {
    }
}
