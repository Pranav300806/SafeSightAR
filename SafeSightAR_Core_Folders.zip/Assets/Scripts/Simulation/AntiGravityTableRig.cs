using System;
using UnityEngine;

namespace SafeSightAR.Simulation
{
    /// <summary>
    /// Manages reference spatial surfaces (desks, tables, counter surfaces, and floor perimeters)
    /// for zero-localhost AR simulation. Calculates edge distances, surface normals, and horizontal
    /// bounding footprints for real-time edge-fall risk evaluation (e.g., knife edge detection).
    /// </summary>
    [ExecuteAlways]
    [SelectionBase]
    public class AntiGravityTableRig : MonoBehaviour
    {
        [Header("Surface Dimensions & Geometry")]
        [Tooltip("Surface dimensions (Width along local X, Thickness along local Y, Depth along local Z) in meters.")]
        [SerializeField] private Vector3 surfaceDimensions = new Vector3(1.60f, 0.05f, 0.90f);

        [Tooltip("Local offset from this Transform's origin to the tabletop center.")]
        [SerializeField] private Vector3 centerOffset = Vector3.zero;

        [Tooltip("Optional BoxCollider representing the tabletop. If unassigned, automatically generated or queried.")]
        [SerializeField] private BoxCollider tableCollider;

        [Header("Safety Thresholds")]
        [Tooltip("Critical edge warning distance envelope in meters (e.g. 0.05m = 5cm for sharp objects).")]
        [SerializeField] private float criticalEdgeEnvelope = 0.05f;

        [Tooltip("Maximum vertical hover distance above the tabletop to be considered hovering over it.")]
        [SerializeField] private float maxHoverAltitude = 1.2f;

        [Header("Visualization & Gizmos")]
        [SerializeField] private bool showPerimeterGizmos = true;
        [SerializeField] private Color perimeterColor = new Color(0.1f, 0.9f, 0.8f, 0.8f);
        [SerializeField] private Color dangerZoneColor = new Color(1.0f, 0.2f, 0.2f, 0.4f);

        #region Public Properties

        /// <summary>Unit normal vector perpendicular to the tabletop surface in world space.</summary>
        public Vector3 SurfaceNormal => transform.up;

        /// <summary>World position of the tabletop geometric center.</summary>
        public Vector3 SurfaceCenterWorld => transform.TransformPoint(centerOffset);

        /// <summary>Top surface Y level in world coordinates.</summary>
        public float SurfaceTopY => SurfaceCenterWorld.y + (surfaceDimensions.y * 0.5f * transform.lossyScale.y);

        /// <summary>Total bounding box of the table in world space.</summary>
        public Bounds SurfaceBounds
        {
            get
            {
                if (tableCollider != null) return tableCollider.bounds;
                return new Bounds(SurfaceCenterWorld, Vector3.Scale(surfaceDimensions, transform.lossyScale));
            }
        }

        /// <summary>Local half-extents along horizontal X and Z axes.</summary>
        public Vector2 HalfDimensionsXZ => new Vector2(
            surfaceDimensions.x * 0.5f * Mathf.Abs(transform.lossyScale.x),
            surfaceDimensions.z * 0.5f * Mathf.Abs(transform.lossyScale.z)
        );

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            EnsureCollider();
        }

        private void OnValidate()
        {
            EnsureCollider();
        }

        private void EnsureCollider()
        {
            if (tableCollider == null)
            {
                tableCollider = GetComponent<BoxCollider>();
                if (tableCollider == null)
                {
                    tableCollider = gameObject.AddComponent<BoxCollider>();
                }
            }

            if (tableCollider != null)
            {
                tableCollider.center = centerOffset;
                tableCollider.size = surfaceDimensions;
            }
        }

        #endregion

        #region Perimeter & Surface Geometry Queries

        /// <summary>
        /// Calculates the minimum 2D horizontal Euclidean distance from a 3D world point to the nearest table perimeter edge.
        /// Inside perimeter: returns positive distance (meters to closest edge).
        /// Outside perimeter: returns 0 or negative offset distance indicating it has drifted off the table.
        /// </summary>
        /// <param name="worldPoint">Query point in world space (e.g., knife or bottle position).</param>
        /// <returns>Distance in meters to the nearest table perimeter boundary.</returns>
        public float GetDistanceToPerimeter(Vector3 worldPoint)
        {
            Vector3 nearestPoint = GetNearestPerimeterPoint(worldPoint);
            Vector3 localPt = transform.InverseTransformPoint(worldPoint) - centerOffset;
            Vector2 halfExt = HalfDimensionsXZ;

            bool isInside = (Mathf.Abs(localPt.x) <= halfExt.x) && (Mathf.Abs(localPt.z) <= halfExt.y);

            float horizontalDistance = Vector3.Distance(
                new Vector3(worldPoint.x, SurfaceTopY, worldPoint.z),
                new Vector3(nearestPoint.x, SurfaceTopY, nearestPoint.z)
            );

            return isInside ? horizontalDistance : -horizontalDistance;
        }

        /// <summary>
        /// Computes the exact 3D point on the table edge perimeter closest to the given world point.
        /// </summary>
        /// <param name="worldPoint">Arbitrary position in world space.</param>
        /// <returns>Nearest perimeter edge point on the table surface plane.</returns>
        public Vector3 GetNearestPerimeterPoint(Vector3 worldPoint)
        {
            Vector3 localPt = transform.InverseTransformPoint(worldPoint) - centerOffset;
            Vector2 halfExt = HalfDimensionsXZ;

            float clampedX = Mathf.Clamp(localPt.x, -halfExt.x, halfExt.x);
            float clampedZ = Mathf.Clamp(localPt.z, -halfExt.y, halfExt.y);

            // If strictly inside, project to the closest of the 4 perimeter edges
            if (Mathf.Abs(localPt.x) < halfExt.x && Mathf.Abs(localPt.z) < halfExt.y)
            {
                float distLeft = Mathf.Abs(localPt.x - (-halfExt.x));
                float distRight = Mathf.Abs(halfExt.x - localPt.x);
                float distBack = Mathf.Abs(localPt.z - (-halfExt.y));
                float distFront = Mathf.Abs(halfExt.y - localPt.z);

                float minDist = Mathf.Min(distLeft, distRight, distBack, distFront);

                if (Mathf.Approximately(minDist, distLeft)) clampedX = -halfExt.x;
                else if (Mathf.Approximately(minDist, distRight)) clampedX = halfExt.x;
                else if (Mathf.Approximately(minDist, distBack)) clampedZ = -halfExt.y;
                else clampedZ = halfExt.y;
            }

            Vector3 nearestLocal = new Vector3(clampedX, surfaceDimensions.y * 0.5f, clampedZ) + centerOffset;
            return transform.TransformPoint(nearestLocal);
        }

        /// <summary>
        /// Evaluates whether an object is hovering directly above the table's planar surface
        /// or has drifted beyond the perimeter.
        /// </summary>
        /// <param name="entityBounds">World-space bounds of the interactable entity.</param>
        /// <returns>True if the object's bottom is within the hover column directly over the table.</returns>
        public bool IsAboveSurface(Bounds entityBounds)
        {
            float objectBottomY = entityBounds.min.y;
            float topY = SurfaceTopY;

            // Check vertical altitude envelope (from surface level up to max hover altitude)
            if (objectBottomY < topY - 0.15f || objectBottomY > topY + maxHoverAltitude)
            {
                return false;
            }

            // Check horizontal bounds intersection with tabletop footprint
            Vector3 localCenter = transform.InverseTransformPoint(entityBounds.center) - centerOffset;
            Vector2 halfExt = HalfDimensionsXZ;

            float margin = 0.05f; // Slight margin for partial overhang
            bool isWithinFootprint = (localCenter.x >= -halfExt.x - margin && localCenter.x <= halfExt.x + margin) &&
                                     (localCenter.z >= -halfExt.y - margin && localCenter.z <= halfExt.y + margin);

            return isWithinFootprint;
        }

        /// <summary>
        /// Evaluates whether an object is overhanging the table edge and computes the overhang ratio and direction vector.
        /// Overhang ratio is 0.0 when fully supported inside the perimeter, and > 0.0 when hanging past the boundary.
        /// </summary>
        /// <param name="entityBounds">World-space bounds of the interactable entity.</param>
        /// <param name="overhangRatio">Fraction of horizontal footprint extending beyond the edge (0.0 to 1.0+).</param>
        /// <param name="overhangDirection">Normalized world-space vector pointing outward toward the overhung edge.</param>
        /// <returns>True if any portion of the entity's bounding footprint extends beyond the tabletop perimeter.</returns>
        public bool DetectOverhang(Bounds entityBounds, out float overhangRatio, out Vector3 overhangDirection)
        {
            overhangRatio = 0.0f;
            overhangDirection = Vector3.zero;

            // Check vertical proximity: must be on or near the table surface level
            float bottomY = entityBounds.min.y;
            if (bottomY < SurfaceTopY - 0.2f || bottomY > SurfaceTopY + maxHoverAltitude)
            {
                return false;
            }

            Vector3 localCenter = transform.InverseTransformPoint(entityBounds.center) - centerOffset;
            Vector3 localExtents = transform.InverseTransformVector(entityBounds.extents);
            float halfWidthX = Mathf.Abs(localExtents.x);
            float halfWidthZ = Mathf.Abs(localExtents.z);

            Vector2 halfExt = HalfDimensionsXZ;

            float minX = localCenter.x - halfWidthX;
            float maxX = localCenter.x + halfWidthX;
            float minZ = localCenter.z - halfWidthZ;
            float maxZ = localCenter.z + halfWidthZ;

            float overhangLeft = Mathf.Max(0f, -halfExt.x - minX);
            float overhangRight = Mathf.Max(0f, maxX - halfExt.x);
            float overhangBack = Mathf.Max(0f, -halfExt.y - minZ);
            float overhangFront = Mathf.Max(0f, maxZ - halfExt.y);

            float maxOverhangDist = Mathf.Max(Mathf.Max(overhangLeft, overhangRight), Mathf.Max(overhangBack, overhangFront));

            if (maxOverhangDist > 0.001f)
            {
                Vector3 localDir = Vector3.zero;
                float refDimension = 0.1f;

                if (Mathf.Approximately(maxOverhangDist, overhangLeft))
                {
                    localDir = -Vector3.right;
                    refDimension = Mathf.Max(0.01f, halfWidthX * 2f);
                }
                else if (Mathf.Approximately(maxOverhangDist, overhangRight))
                {
                    localDir = Vector3.right;
                    refDimension = Mathf.Max(0.01f, halfWidthX * 2f);
                }
                else if (Mathf.Approximately(maxOverhangDist, overhangBack))
                {
                    localDir = -Vector3.forward;
                    refDimension = Mathf.Max(0.01f, halfWidthZ * 2f);
                }
                else
                {
                    localDir = Vector3.forward;
                    refDimension = Mathf.Max(0.01f, halfWidthZ * 2f);
                }

                overhangRatio = Mathf.Clamp01(maxOverhangDist / refDimension);
                overhangDirection = transform.TransformDirection(localDir).normalized;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Checks whether a point is within the critical edge hazard threshold (e.g. 5cm from table edge).
        /// </summary>
        public bool IsNearEdge(Vector3 worldPoint, float thresholdMeters, out float edgeDistance)
        {
            edgeDistance = Mathf.Abs(GetDistanceToPerimeter(worldPoint));
            return edgeDistance <= thresholdMeters;
        }

        /// <summary>
        /// Returns the 4 corner coordinates of the table perimeter in clockwise world space order.
        /// </summary>
        public Vector3[] GetPerimeterCorners()
        {
            Vector2 half = HalfDimensionsXZ;
            float topLocalY = surfaceDimensions.y * 0.5f;

            Vector3[] localCorners = new Vector3[]
            {
                new Vector3(-half.x, topLocalY,  half.y) + centerOffset, // Top-Left
                new Vector3( half.x, topLocalY,  half.y) + centerOffset, // Top-Right
                new Vector3( half.x, topLocalY, -half.y) + centerOffset, // Bottom-Right
                new Vector3(-half.x, topLocalY, -half.y) + centerOffset  // Bottom-Left
            };

            Vector3[] worldCorners = new Vector3[4];
            for (int i = 0; i < 4; i++)
            {
                worldCorners[i] = transform.TransformPoint(localCorners[i]);
            }
            return worldCorners;
        }

        #endregion

        #region Debug Gizmos

        private void OnDrawGizmos()
        {
            if (!showPerimeterGizmos) return;

            Vector3[] corners = GetPerimeterCorners();

            // 1. Draw Surface Perimeter Rectangle
            Gizmos.color = perimeterColor;
            for (int i = 0; i < 4; i++)
            {
                Gizmos.DrawLine(corners[i], corners[(i + 1) % 4]);
            }

            // 2. Draw Table Center & Surface Normal
            Vector3 center = SurfaceCenterWorld;
            center.y = SurfaceTopY;
            Gizmos.color = Color.green;
            Gizmos.DrawRay(center, SurfaceNormal * 0.25f);

            // 3. Draw Critical Edge Hazard Danger Strip
            if (criticalEdgeEnvelope > 0.001f)
            {
                Gizmos.color = dangerZoneColor;
                Vector2 half = HalfDimensionsXZ;
                float topLocalY = surfaceDimensions.y * 0.5f;

                // Inner safety inset
                float innerX = Mathf.Max(0.01f, half.x - criticalEdgeEnvelope);
                float innerZ = Mathf.Max(0.01f, half.y - criticalEdgeEnvelope);

                Vector3[] innerCorners = new Vector3[]
                {
                    transform.TransformPoint(new Vector3(-innerX, topLocalY,  innerZ) + centerOffset),
                    transform.TransformPoint(new Vector3( innerX, topLocalY,  innerZ) + centerOffset),
                    transform.TransformPoint(new Vector3( innerX, topLocalY, -innerZ) + centerOffset),
                    transform.TransformPoint(new Vector3(-innerX, topLocalY, -innerZ) + centerOffset)
                };

                for (int i = 0; i < 4; i++)
                {
                    Gizmos.DrawLine(innerCorners[i], innerCorners[(i + 1) % 4]);
                    Gizmos.DrawLine(corners[i], innerCorners[i]);
                }
            }
        }

        #endregion
    }
}
