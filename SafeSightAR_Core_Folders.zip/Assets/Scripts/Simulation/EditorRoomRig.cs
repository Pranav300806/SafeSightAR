using UnityEngine;
using UnityEngine.EventSystems;
using SmartSpaceAR.Furniture;

namespace SmartSpaceAR.Simulation
{
    /// <summary>
    /// Simulated Room Rig for desktop Unity Editor testing.
    /// Provides:
    /// 1. Procedural 3D room environment (floor plane with grid lines, walls, ambient lighting).
    /// 2. First-person desktop camera navigation (WASD + Right-click look + QE elevation).
    /// 3. Direct surface click-to-place integration for furniture previewing without physical AR devices.
    /// </summary>
    [ExecuteAlways]
    public class EditorRoomRig : MonoBehaviour
    {
        [Header("Room Dimensions (Meters)")]
        [SerializeField] private Vector3 roomDimensions = new Vector3(6.0f, 2.8f, 6.0f);
        [SerializeField] private bool generateVisualRoom = true;
        [SerializeField] private Material floorMaterial;
        [SerializeField] private Material wallMaterial;

        [Header("Desktop Camera Navigation")]
        [SerializeField] private Camera simulationCamera;
        [SerializeField] private float moveSpeed = 4.0f;
        [SerializeField] private float sprintMultiplier = 2.0f;
        [SerializeField] private float mouseSensitivity = 2.5f;
        [SerializeField] private float elevationSpeed = 3.0f;

        [Header("Placement Interaction")]
        [Tooltip("Layer mask assigned to floor collider for raycasting.")]
        [SerializeField] private LayerMask floorLayerMask = ~0;

        private GameObject generatedRoomContainer;
        private Transform cameraTransform;
        private float yaw = 0f;
        private float pitch = 25f;

        private void Start()
        {
            if (simulationCamera == null)
            {
                simulationCamera = Camera.main ?? FindFirstObjectByType<Camera>();
            }

            if (simulationCamera != null)
            {
                cameraTransform = simulationCamera.transform;
                Vector3 euler = cameraTransform.eulerAngles;
                yaw = euler.y;
                pitch = euler.x;
            }

            if (Application.isPlaying && generateVisualRoom)
            {
                BuildProceduralRoom();
            }
        }

        private void Update()
        {
            if (!Application.isPlaying) return;

            HandleCameraNavigation();
            HandleFloorClickPlacement();
        }

        #region Desktop Camera Controls (WASD + Right-Click Look)

        private void HandleCameraNavigation()
        {
            if (cameraTransform == null) return;

            // 1. Right-Click Mouse Look
            if (Input.GetMouseButton(1))
            {
                Cursor.lockState = CursorLockMode.Confined;
                float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
                float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

                yaw += mouseX;
                pitch -= mouseY;
                pitch = Mathf.Clamp(pitch, -85f, 85f);

                cameraTransform.rotation = Quaternion.Euler(pitch, yaw, 0f);
            }
            else
            {
                Cursor.lockState = CursorLockMode.None;
            }

            // 2. WASD Movement
            float speed = moveSpeed * (Input.GetKey(KeyCode.LeftShift) ? sprintMultiplier : 1.0f) * Time.deltaTime;

            Vector3 moveDirection = Vector3.zero;
            if (Input.GetKey(KeyCode.W)) moveDirection += cameraTransform.forward;
            if (Input.GetKey(KeyCode.S)) moveDirection -= cameraTransform.forward;
            if (Input.GetKey(KeyCode.D)) moveDirection += cameraTransform.right;
            if (Input.GetKey(KeyCode.A)) moveDirection -= cameraTransform.right;

            // Maintain horizontal motion for WASD
            moveDirection.y = 0;
            if (moveDirection.sqrMagnitude > 0.001f)
            {
                moveDirection.Normalize();
                cameraTransform.position += moveDirection * speed;
            }

            // 3. QE Vertical Elevation
            if (Input.GetKey(KeyCode.E))
            {
                cameraTransform.position += Vector3.up * (elevationSpeed * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.Q))
            {
                cameraTransform.position -= Vector3.up * (elevationSpeed * Time.deltaTime);
            }

            // 4. Spacebar reset camera view
            if (Input.GetKeyDown(KeyCode.Space))
            {
                ResetCameraToDefaultView();
            }
        }

        public void ResetCameraToDefaultView()
        {
            if (cameraTransform == null) return;
            cameraTransform.position = new Vector3(0, 1.8f, -2.8f);
            cameraTransform.rotation = Quaternion.Euler(22f, 0f, 0f);
            pitch = 22f;
            yaw = 0f;
        }

        #endregion

        #region Surface Placement

        private void HandleFloorClickPlacement()
        {
            if (simulationCamera == null) return;

            // Only trigger on Left-Click Down
            if (!Input.GetMouseButtonDown(0)) return;

            // Check if cursor is over uGUI element
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
            {
                return;
            }

            Ray ray = simulationCamera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit, 50f, floorLayerMask))
            {
                // Verify hit object is the floor plane and not an existing furniture piece
                if (hit.collider.CompareTag("Floor") || hit.collider.name.Contains("Floor") || hit.normal.y > 0.8f)
                {
                    // Check if clicking directly on an interactable
                    if (hit.collider.GetComponentInParent<AntiGravityInteractable>() != null)
                    {
                        return; // Let interactable handle its own selection & hover drag
                    }

                    // Otherwise, spawn selected furniture onto the clicked floor point
                    if (FurnitureManager.Instance != null)
                    {
                        FurnitureManager.Instance.SpawnFurniture(hit.point, Quaternion.identity);
                    }
                }
            }
        }

        #endregion

        #region Procedural Room Construction

        public void BuildProceduralRoom()
        {
            if (generatedRoomContainer != null) Destroy(generatedRoomContainer);

            generatedRoomContainer = new GameObject("[Procedural_Simulation_Room]");
            generatedRoomContainer.transform.SetParent(transform, false);

            Material floorMat = floorMaterial ?? CreateFloorGridMaterial();
            Material wallMat = wallMaterial ?? CreateWallMaterial();

            // 1. Floor Plane (6m x 6m)
            GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "Room_Floor_Plane";
            floor.tag = "Floor";
            floor.transform.SetParent(generatedRoomContainer.transform, false);
            floor.transform.localPosition = new Vector3(0, -0.05f, 0);
            floor.transform.localScale = new Vector3(roomDimensions.x, 0.1f, roomDimensions.z);
            floor.GetComponent<Renderer>().material = floorMat;

            // 2. North Wall
            CreateWall(generatedRoomContainer, "Wall_North", new Vector3(0, roomDimensions.y * 0.5f, roomDimensions.z * 0.5f), new Vector3(roomDimensions.x, roomDimensions.y, 0.1f), wallMat);
            // 3. South Wall
            CreateWall(generatedRoomContainer, "Wall_South", new Vector3(0, roomDimensions.y * 0.5f, -roomDimensions.z * 0.5f), new Vector3(roomDimensions.x, roomDimensions.y, 0.1f), wallMat);
            // 4. West Wall
            CreateWall(generatedRoomContainer, "Wall_West", new Vector3(-roomDimensions.x * 0.5f, roomDimensions.y * 0.5f, 0), new Vector3(0.1f, roomDimensions.y, roomDimensions.z), wallMat);
            // 5. East Wall
            CreateWall(generatedRoomContainer, "Wall_East", new Vector3(roomDimensions.x * 0.5f, roomDimensions.y * 0.5f, 0), new Vector3(0.1f, roomDimensions.y, roomDimensions.z), wallMat);

            // Add Soft Simulation Lighting
            GameObject lightObj = new GameObject("Room_Sunlight");
            lightObj.transform.SetParent(generatedRoomContainer.transform, false);
            lightObj.transform.rotation = Quaternion.Euler(50f, -30f, 0);
            Light light = lightObj.AddComponent<Light>();
            light.type = LightType.Directional;
            light.color = new Color(1.0f, 0.96f, 0.90f);
            light.intensity = 1.15f;
            light.shadows = LightShadows.Soft;

            Debug.Log("[SmartSpace AR] Simulation room rig initialized with floor & boundary walls.");
        }

        private void CreateWall(GameObject parent, string name, Vector3 pos, Vector3 size, Material mat)
        {
            GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            wall.name = name;
            wall.transform.SetParent(parent.transform, false);
            wall.transform.localPosition = pos;
            wall.transform.localScale = size;
            wall.GetComponent<Renderer>().material = mat;
        }

        private Material CreateFloorGridMaterial()
        {
            Material mat = new Material(Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Diffuse"));
            mat.color = new Color(0.28f, 0.30f, 0.34f); // Modern slate grey floor
            mat.SetFloat("_Glossiness", 0.35f);
            return mat;
        }

        private Material CreateWallMaterial()
        {
            Material mat = new Material(Shader.Find("Standard") ?? Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Diffuse"));
            mat.color = new Color(0.92f, 0.93f, 0.95f); // Off-white modern wall
            mat.SetFloat("_Glossiness", 0.1f);
            return mat;
        }

        #endregion

        #region Debug Gizmos

        private void OnDrawGizmos()
        {
            Gizmos.color = new Color(0.2f, 0.8f, 1.0f, 0.4f);
            Gizmos.DrawWireCube(new Vector3(0, roomDimensions.y * 0.5f, 0), roomDimensions);

            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(new Vector3(0, 0, 0), new Vector3(roomDimensions.x, 0.02f, roomDimensions.z));
        }

        #endregion
    }
}
