using UnityEngine;
using SafeSightAR.RiskEngine;
using SafeSightAR.Vision;

namespace SafeSightAR.Simulation
{
    /// <summary>
    /// Interactive Hazard Simulation Rig Controller.
    /// Provides desktop interactive manipulation (drag objects, toggle open/close drawer),
    /// and preset hazard scenario triggers to verify system risk detection end-to-end.
    /// </summary>
    public class HazardSimulatorController : MonoBehaviour
    {
        [Header("Interactive 3D Objects")]
        [SerializeField] private GameObject deskObject;
        [SerializeField] private GameObject laptopObject;
        [SerializeField] private GameObject bottleObject;
        [SerializeField] private GameObject knifeObject;
        [SerializeField] private GameObject drawerObject;
        [SerializeField] private GameObject cableObject;

        [Header("Room Colliders & Walkway Bounds")]
        [SerializeField] private BoxCollider tableCollider;
        [SerializeField] private BoxCollider walkwayCollider;

        [Header("Initial Safe Positions")]
        private Vector3 bottleSafePos = new Vector3(-0.4f, 0.76f, 0.2f);
        private Vector3 bottleHazardPos = new Vector3(0.05f, 0.76f, 0.05f); // 8cm from laptop
        
        private Vector3 knifeSafePos = new Vector3(0.2f, 0.76f, 0.3f);
        private Vector3 knifeHazardPos = new Vector3(0.58f, 0.76f, 0.0f); // 2cm from table edge

        private Vector3 drawerClosedPos = new Vector3(-0.5f, 0.3f, 0.0f);
        private Vector3 drawerOpenPos = new Vector3(-0.5f, 0.3f, 0.5f); // Extends into walkway

        private Vector3 cableSafePos = new Vector3(-0.8f, 0.02f, -0.5f);
        private Vector3 cableHazardPos = new Vector3(0.0f, 0.02f, 0.3f); // Across walkway

        private bool isDrawerOpen = false;

        private void Start()
        {
            ResetToSafeState();
        }

        private void Update()
        {
            // Keyboard Shortcuts for quick Desktop Verification
            if (Input.GetKeyDown(KeyCode.Alpha1)) TriggerSpillScenario();
            if (Input.GetKeyDown(KeyCode.Alpha2)) TriggerKnifeEdgeScenario();
            if (Input.GetKeyDown(KeyCode.Alpha3)) ToggleDrawerState();
            if (Input.GetKeyDown(KeyCode.Alpha4)) TriggerCableScenario();
            if (Input.GetKeyDown(KeyCode.R)) ResetToSafeState();

            // Run continuous spatial frame evaluation
            if (SpatialRelationshipAnalyzer.Instance != null && RiskEvaluator.Instance != null)
            {
                var detections = YOLOInferenceEngine.Instance != null 
                    ? YOLOInferenceEngine.Instance.LastDetections 
                    : null;

                var spatialObjects = SpatialRelationshipAnalyzer.Instance.Process2DDetectionsTo3D(detections);
                
                Bounds tableB = tableCollider != null ? tableCollider.bounds : new Bounds(new Vector3(0, 0.75f, 0), new Vector3(1.2f, 0.1f, 0.8f));
                Bounds walkB = walkwayCollider != null ? walkwayCollider.bounds : new Bounds(new Vector3(0, 0, 0.4f), new Vector3(1.5f, 0.2f, 0.6f));

                RiskEvaluator.Instance.EvaluateSpatialFrame(spatialObjects, tableB, walkB);
            }
        }

        public void TriggerSpillScenario()
        {
            if (bottleObject != null) bottleObject.transform.localPosition = bottleHazardPos;
            Debug.Log("[SafeSight Sim] Preset Loaded: Liquid Spill Hazard (<15cm to laptop)");
        }

        public void TriggerKnifeEdgeScenario()
        {
            if (knifeObject != null) knifeObject.transform.localPosition = knifeHazardPos;
            Debug.Log("[SafeSight Sim] Preset Loaded: Sharp Edge Fall Hazard (<5cm to edge)");
        }

        public void ToggleDrawerState()
        {
            isDrawerOpen = !isDrawerOpen;
            if (drawerObject != null)
            {
                drawerObject.transform.localPosition = isDrawerOpen ? drawerOpenPos : drawerClosedPos;
            }
            Debug.Log($"[SafeSight Sim] Drawer State Toggled: {(isDrawerOpen ? "OPEN (Walkway Obstruction)" : "CLOSED")}");
        }

        public void TriggerCableScenario()
        {
            if (cableObject != null) cableObject.transform.localPosition = cableHazardPos;
            Debug.Log("[SafeSight Sim] Preset Loaded: Cable Walkway Trip Hazard");
        }

        public void ResetToSafeState()
        {
            if (bottleObject != null) bottleObject.transform.localPosition = bottleSafePos;
            if (knifeObject != null) knifeObject.transform.localPosition = knifeSafePos;
            if (drawerObject != null) { drawerObject.transform.localPosition = drawerClosedPos; isDrawerOpen = false; }
            if (cableObject != null) cableObject.transform.localPosition = cableSafePos;
            Debug.Log("[SafeSight Sim] Simulation Environment Reset to Safe Baseline State.");
        }
    }
}
