using System;
using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.RiskEngine;

namespace SafeSightAR.Simulation
{
    /// <summary>
    /// Structured representation of a simulated 3D spatial entity queryable in-memory by RiskEvaluator.
    /// Fully client-side without network sockets or serialization overhead.
    /// </summary>
    [Serializable]
    public struct DetectedEntity
    {
        public string id;
        public string entityClass;
        public float confidence;
        public Vector3 worldPosition;
        public Bounds worldBounds;
        public Quaternion rotation;
        public bool isGrabbed;

        public DetectedEntity(
            string id, 
            string entityClass, 
            float confidence, 
            Vector3 worldPosition, 
            Bounds worldBounds, 
            Quaternion rotation, 
            bool isGrabbed)
        {
            this.id = id;
            this.entityClass = entityClass;
            this.confidence = confidence;
            this.worldPosition = worldPosition;
            this.worldBounds = worldBounds;
            this.rotation = rotation;
            this.isGrabbed = isGrabbed;
        }

        /// <summary>
        /// Direct zero-copy mapping to TrackedSpatialObject consumed by RiskEvaluator.
        /// </summary>
        public TrackedSpatialObject ToTrackedSpatialObject()
        {
            return new TrackedSpatialObject(
                id,
                entityClass,
                worldPosition,
                worldBounds,
                new Rect(0, 0, 100, 100),
                confidence,
                true
            );
        }
    }

    /// <summary>
    /// Central orchestrator connecting Anti-Gravity interactables to the SafeSight RiskEvaluator.
    /// Discovers entities, builds DetectedEntity structures, passes them directly into memory,
    /// and renders real-time proximity rays and interactive scenario hotkeys.
    /// </summary>
    [DefaultExecutionOrder(-50)]
    public class SafeSightSimulationHub : MonoBehaviour
    {
        [Header("Scene References")]
        [Tooltip("Reference to the table/desk surface rig.")]
        [SerializeField] private AntiGravityTableRig tableRig;

        [Tooltip("Optional reference to walkway floor bounds collider.")]
        [SerializeField] private BoxCollider walkwayCollider;

        [Tooltip("Reference to the RiskEvaluator. If null, automatically discovers singleton.")]
        [SerializeField] private RiskEvaluator riskEvaluator;

        [Header("Evaluation Settings")]
        [Tooltip("If true, automatically rescans scene hierarchy for new AntiGravityInteractable entities.")]
        [SerializeField] private bool autoDiscoverEntities = true;

        [Tooltip("Scan interval in seconds for finding dynamically spawned entities.")]
        [SerializeField] private float discoveryInterval = 1.0f;

        [Header("Debug Visualization & GUI")]
        [SerializeField] private bool showRaysInScene = true;
        [SerializeField] private bool showOnScreenHUD = true;
        [SerializeField] private float safeDistanceThreshold = 0.30f;    // 30 cm (Green)
        [SerializeField] private float warningDistanceThreshold = 0.15f; // 15 cm (Yellow -> Red)

        // Runtime Lists
        private List<AntiGravityInteractable> interactables = new List<AntiGravityInteractable>();
        private List<DetectedEntity> currentEntities = new List<DetectedEntity>();
        private List<HazardAlert> currentAlerts = new List<HazardAlert>();
        private float lastDiscoveryTime = 0f;

        // Singleton
        public static SafeSightSimulationHub Instance { get; private set; }

        // Public Events
        public event Action<List<DetectedEntity>> OnEntitiesUpdated;
        public event Action<List<HazardAlert>> OnAlertsEvaluated;

        #region Public Accessors

        public List<DetectedEntity> CurrentEntities => currentEntities;
        public List<HazardAlert> CurrentAlerts => currentAlerts;
        public AntiGravityTableRig TableRig => tableRig;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (Instance == null) Instance = this;
            else Destroy(gameObject);

            if (tableRig == null)
            {
                tableRig = FindFirstObjectByType<AntiGravityTableRig>();
            }

            if (riskEvaluator == null)
            {
                riskEvaluator = RiskEvaluator.Instance ?? FindFirstObjectByType<RiskEvaluator>();
            }

            DiscoverInteractables();
        }

        private void Start()
        {
            if (riskEvaluator == null)
            {
                riskEvaluator = RiskEvaluator.Instance ?? FindFirstObjectByType<RiskEvaluator>();
            }
        }

        private void Update()
        {
            // Periodic entity discovery
            if (autoDiscoverEntities && Time.time - lastDiscoveryTime > discoveryInterval)
            {
                DiscoverInteractables();
                lastDiscoveryTime = Time.time;
            }

            // Execute client-side evaluation pipeline
            ExecuteSimulationPipeline();

            // Handle Quick Desktop Keyboard Shortcuts for rapid verification
            HandleScenarioHotkeys();
        }

        #endregion

        #region Simulation & Direct Evaluation Pipeline

        /// <summary>
        /// Discovers all active AntiGravityInteractable components in the current scene.
        /// </summary>
        public void DiscoverInteractables()
        {
            interactables.Clear();
            AntiGravityInteractable[] found = FindObjectsByType<AntiGravityInteractable>(FindObjectsSortMode.None);
            interactables.AddRange(found);
        }

        /// <summary>
        /// Synchronously updates entity states and passes them directly to RiskEvaluator in memory.
        /// Zero network latency, zero HTTP sockets, zero localhost bridges.
        /// </summary>
        private void ExecuteSimulationPipeline()
        {
            currentEntities.Clear();
            List<TrackedSpatialObject> trackedList = new List<TrackedSpatialObject>();

            for (int i = 0; i < interactables.Count; i++)
            {
                AntiGravityInteractable obj = interactables[i];
                if (obj == null || !obj.gameObject.activeInHierarchy) continue;

                DetectedEntity entity = new DetectedEntity(
                    obj.EntityId,
                    obj.EntityClass,
                    obj.DetectionConfidence,
                    obj.transform.position,
                    obj.WorldBounds,
                    obj.transform.rotation,
                    obj.IsGrabbed
                );

                currentEntities.Add(entity);
                trackedList.Add(entity.ToTrackedSpatialObject());
            }

            OnEntitiesUpdated?.Invoke(currentEntities);

            // Feed directly into RiskEvaluator
            if (riskEvaluator == null)
            {
                riskEvaluator = RiskEvaluator.Instance ?? FindFirstObjectByType<RiskEvaluator>();
            }

            if (riskEvaluator != null)
            {
                Bounds tableBounds = tableRig != null 
                    ? tableRig.SurfaceBounds 
                    : new Bounds(Vector3.up * 0.75f, new Vector3(1.6f, 0.1f, 0.9f));

                Bounds walkwayBounds = walkwayCollider != null 
                    ? walkwayCollider.bounds 
                    : new Bounds(new Vector3(0, 0.05f, 1.0f), new Vector3(2.5f, 0.1f, 1.2f));

                currentAlerts = riskEvaluator.EvaluateSpatialFrame(trackedList, tableBounds, walkwayBounds);
                OnAlertsEvaluated?.Invoke(currentAlerts);
            }
        }

        #endregion

        #region Scenario Hotkeys for Desktop Testing

        private void HandleScenarioHotkeys()
        {
            if (Input.GetKeyDown(KeyCode.Alpha1)) TriggerPresetSpillHazard();
            if (Input.GetKeyDown(KeyCode.Alpha2)) TriggerPresetKnifeEdgeHazard();
            if (Input.GetKeyDown(KeyCode.Alpha3)) TriggerPresetOpenDrawer();
            if (Input.GetKeyDown(KeyCode.Alpha4)) TriggerPresetCableHazard();
            if (Input.GetKeyDown(KeyCode.R)) ResetAllToNeutral();
        }

        public void TriggerPresetSpillHazard()
        {
            AntiGravityInteractable bottle = FindInteractableByClass("bottle");
            AntiGravityInteractable laptop = FindInteractableByClass("laptop");

            if (bottle != null && laptop != null)
            {
                // Position bottle 8 cm away from laptop
                Vector3 hazardPos = laptop.transform.position + new Vector3(0.08f, 0.05f, 0.03f);
                bottle.TeleportToPosition(hazardPos, Quaternion.identity);
            }
        }

        public void TriggerPresetKnifeEdgeHazard()
        {
            AntiGravityInteractable knife = FindInteractableByClass("knife");
            if (knife != null && tableRig != null)
            {
                // Place knife 2 cm from table front edge
                Vector3 nearestEdge = tableRig.GetNearestPerimeterPoint(tableRig.SurfaceCenterWorld + Vector3.forward * 0.4f);
                Vector3 knifePos = nearestEdge - (tableRig.transform.forward * 0.02f) + Vector3.up * 0.03f;
                knife.TeleportToPosition(knifePos, Quaternion.Euler(0, 90f, 0));
            }
        }

        public void TriggerPresetOpenDrawer()
        {
            AntiGravityInteractable drawer = FindInteractableByClass("drawer");
            if (drawer != null)
            {
                // Slide drawer outward into walkway
                Vector3 openPos = drawer.transform.position + drawer.transform.forward * 0.45f;
                drawer.TeleportToPosition(openPos, drawer.transform.rotation);
            }
        }

        public void TriggerPresetCableHazard()
        {
            AntiGravityInteractable cable = FindInteractableByClass("cable");
            if (cable != null)
            {
                Vector3 hazardPos = new Vector3(0f, 0.02f, 0.7f);
                cable.TeleportToPosition(hazardPos, Quaternion.identity);
            }
        }

        public void ResetAllToNeutral()
        {
            AntiGravityInteractable bottle = FindInteractableByClass("bottle");
            AntiGravityInteractable laptop = FindInteractableByClass("laptop");
            AntiGravityInteractable knife = FindInteractableByClass("knife");
            AntiGravityInteractable drawer = FindInteractableByClass("drawer");
            AntiGravityInteractable cable = FindInteractableByClass("cable");

            float tableTop = tableRig != null ? tableRig.SurfaceTopY : 0.75f;

            if (laptop != null) laptop.TeleportToPosition(new Vector3(0f, tableTop + 0.05f, 0f), Quaternion.identity);
            if (bottle != null) bottle.TeleportToPosition(new Vector3(-0.45f, tableTop + 0.12f, 0.15f), Quaternion.identity);
            if (knife != null) knife.TeleportToPosition(new Vector3(0.25f, tableTop + 0.03f, 0.20f), Quaternion.identity);
            if (drawer != null) drawer.TeleportToPosition(new Vector3(-0.50f, 0.35f, 0.0f), Quaternion.identity);
            if (cable != null) cable.TeleportToPosition(new Vector3(-0.80f, 0.02f, -0.40f), Quaternion.identity);
        }

        private AntiGravityInteractable FindInteractableByClass(string label)
        {
            return interactables.Find(i => i != null && string.Equals(i.EntityClass, label, StringComparison.OrdinalIgnoreCase));
        }

        #endregion

        #region Visual Debug Gizmos & Rays

        private void OnDrawGizmos()
        {
            if (!showRaysInScene) return;

            // 1. Draw Distance Ray: Bottle <-> Laptop
            AntiGravityInteractable bottle = FindInteractableByClass("bottle");
            AntiGravityInteractable laptop = FindInteractableByClass("laptop");

            if (bottle != null && laptop != null)
            {
                Vector3 p1 = bottle.transform.position;
                Vector3 p2 = laptop.transform.position;
                float dist = Vector3.Distance(p1, p2);

                Color rayColor = EvaluateDistanceColor(dist);
                Gizmos.color = rayColor;
                Gizmos.DrawLine(p1, p2);

                Gizmos.DrawSphere(p1, 0.02f);
                Gizmos.DrawSphere(p2, 0.02f);
            }

            // 2. Draw Distance Ray: Knife <-> Nearest Table Edge
            AntiGravityInteractable knife = FindInteractableByClass("knife");
            if (knife != null && tableRig != null)
            {
                Vector3 knifePos = knife.transform.position;
                Vector3 edgePos = tableRig.GetNearestPerimeterPoint(knifePos);
                float edgeDist = Vector3.Distance(knifePos, edgePos);

                Color edgeRayColor = edgeDist <= 0.05f ? Color.red : (edgeDist <= 0.12f ? Color.yellow : Color.green);
                Gizmos.color = edgeRayColor;
                Gizmos.DrawLine(knifePos, edgePos);
                Gizmos.DrawWireSphere(edgePos, 0.025f);
            }
        }

        private Color EvaluateDistanceColor(float distanceMeters)
        {
            if (distanceMeters <= warningDistanceThreshold)
            {
                // Pulsing red effect for critical hazards
                float pulse = 0.7f + 0.3f * Mathf.Sin(Time.time * 8f);
                return new Color(1f, 0.1f, 0.1f, pulse);
            }
            else if (distanceMeters <= safeDistanceThreshold)
            {
                float t = (distanceMeters - warningDistanceThreshold) / (safeDistanceThreshold - warningDistanceThreshold);
                return Color.Lerp(Color.red, Color.yellow, t);
            }
            return new Color(0.1f, 0.9f, 0.3f, 0.8f);
        }

        #endregion

        #region OnGUI Diagnostics HUD

        private void OnGUI()
        {
            if (!showOnScreenHUD) return;

            GUI.color = Color.white;
            GUILayout.BeginArea(new Rect(15, 15, 380, 420), GUI.skin.box);

            // Title & Engine Status
            GUILayout.Label("<b><size=14>SafeSight AR - Anti-Gravity Rig</size></b>");
            GUILayout.Label("<color=#38ef7d>● Mode: Client-Only In-Memory Simulation (Zero-Localhost)</color>");
            
            // Switch to Mobile AR Furniture Scene Button
            GUI.color = new Color(0.2f, 0.9f, 1.0f);
            if (GUILayout.Button("<b>🛋️ Switch to Mobile AR Furniture Scene</b>", GUILayout.Height(32)))
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene("MobileAR_Furniture");
            }
            GUI.color = Color.white;
            GUILayout.Space(6);

            // Active Entities Readout
            GUILayout.Label($"<b>Entities Tracked ({currentEntities.Count}):</b>");
            for (int i = 0; i < currentEntities.Count; i++)
            {
                var ent = currentEntities[i];
                string grabStatus = ent.isGrabbed ? "<color=#00e5ff>[LEVITATING]</color>" : "[FLOATING]";
                GUILayout.Label($" • {ent.entityClass} ({ent.confidence:P0}) {grabStatus} @ {ent.worldPosition.ToString("F2")}");
            }

            GUILayout.Space(8);

            // Live Risk Alerts Readout
            GUILayout.Label($"<b>Active Risk Evaluator Alerts ({currentAlerts.Count}):</b>");
            if (currentAlerts.Count == 0)
            {
                GUILayout.Label(" <color=#00ff88>✓ All objects in safe clearance envelope.</color>");
            }
            else
            {
                for (int i = 0; i < currentAlerts.Count; i++)
                {
                    var a = currentAlerts[i];
                    string sevColor = a.severity == HazardSeverity.Critical ? "#ff3333" : "#ffaa00";
                    GUILayout.Label($" <color={sevColor}>▲ [{a.severity}] {a.rule.ruleName}: {a.currentDistanceMeters:F2}m (t={a.persistenceTime:F1}s)</color>");
                }
            }

            GUILayout.Space(10);
            GUILayout.Label("<b>Desktop Quick Verification Controls:</b>");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("[1] Spill Risk")) TriggerPresetSpillHazard();
            if (GUILayout.Button("[2] Knife Edge")) TriggerPresetKnifeEdgeHazard();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("[3] Open Drawer")) TriggerPresetOpenDrawer();
            if (GUILayout.Button("[4] Cable Trip")) TriggerPresetCableHazard();
            GUILayout.EndHorizontal();

            if (GUILayout.Button("<b>[R] Reset to Safe State</b>")) ResetAllToNeutral();

            GUILayout.Space(4);
            GUILayout.Label("<size=10><color=#aaaaaa>Controls: Left-Click Drag = Hover | Mouse Wheel = Depth Distance</color></size>");

            GUILayout.EndArea();
        }

        #endregion
    }
}
