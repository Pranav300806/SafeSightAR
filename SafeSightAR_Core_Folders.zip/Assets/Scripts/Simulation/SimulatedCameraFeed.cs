using System.Collections;
using UnityEngine;
using SafeSightAR.Vision;

namespace SafeSightAR.Simulation
{
    /// <summary>
    /// Synthetic Camera Feeder for Editor & Desktop Simulation.
    /// Captures frames from a virtual camera perspective in the 3D room sandbox 
    /// and pipes them directly into the ML inference engine.
    /// </summary>
    public class SimulatedCameraFeed : MonoBehaviour
    {
        [Header("Camera & Feed Settings")]
        [SerializeField] private Camera virtualCamera;
        [SerializeField] private int captureWidth = 640;
        [SerializeField] private int captureHeight = 640;
        [SerializeField] private float targetFPS = 30.0f;
        [SerializeField] private bool autoStream = true;

        [Header("Inference Target")]
        [SerializeField] private YOLOInferenceEngine inferenceEngine;

        private RenderTexture renderTexture;
        private Texture2D frameBuffer;
        private Coroutine streamCoroutine;

        private void Awake()
        {
            if (virtualCamera == null) virtualCamera = GetComponent<Camera>();
            if (virtualCamera == null) virtualCamera = Camera.main;

            renderTexture = new RenderTexture(captureWidth, captureHeight, 24, RenderTextureFormat.ARGB32);
            frameBuffer = new Texture2D(captureWidth, captureHeight, TextureFormat.RGBA32, false);

            virtualCamera.targetTexture = renderTexture;
        }

        private void Start()
        {
            if (inferenceEngine == null)
            {
                inferenceEngine = YOLOInferenceEngine.Instance;
            }

            if (autoStream)
            {
                StartStreaming();
            }
        }

        public void StartStreaming()
        {
            if (streamCoroutine != null) StopCoroutine(streamCoroutine);
            streamCoroutine = StartCoroutine(CaptureLoop());
        }

        public void StopStreaming()
        {
            if (streamCoroutine != null)
            {
                StopCoroutine(streamCoroutine);
                streamCoroutine = null;
            }
        }

        private IEnumerator CaptureLoop()
        {
            float interval = 1.0f / targetFPS;

            while (true)
            {
                yield return new WaitForSeconds(interval);

                if (virtualCamera != null && inferenceEngine != null)
                {
                    // Render virtual camera view into RenderTexture
                    virtualCamera.Render();

                    RenderTexture activeRT = RenderTexture.active;
                    RenderTexture.active = renderTexture;

                    frameBuffer.ReadPixels(new Rect(0, 0, captureWidth, captureHeight), 0, 0);
                    frameBuffer.Apply();

                    RenderTexture.active = activeRT;

                    // Send captured frame texture to ML engine
                    inferenceEngine.ProcessFrame(frameBuffer);
                }
            }
        }

        private void OnDestroy()
        {
            if (renderTexture != null) renderTexture.Release();
            if (frameBuffer != null) Destroy(frameBuffer);
        }
    }
}
