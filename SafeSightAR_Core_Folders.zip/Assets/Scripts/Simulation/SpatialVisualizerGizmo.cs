using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.RiskEngine;

namespace SafeSightAR.Simulation
{
    /// <summary>
    /// Editor and Game View Visualizer for SafeSight AR simulation.
    /// Draws dynamic connection vectors between high-risk object pairs, renders floating
    /// proximity bubbles and threshold hazard envelopes, and displays world-anchored HUD badges.
    /// </summary>
    [ExecuteAlways]
    public class SpatialVisualizerGizmo : MonoBehaviour
    {
        [Header("Visualization Toggles")]
        [Tooltip("Draw dynamic connection vector rays between interacting hazardous entities.")]
        [SerializeField] private bool renderConnectionVectors = true;

        [Tooltip("Render 3D wireframe spherical proximity bubbles around critical items (e.g. laptop, bottle).")]
        [SerializeField] private bool renderProximityBubbles = true;

        [Tooltip("Render table edge and walkway threshold hazard volumes.")]
        [SerializeField] private bool renderHazardEnvelopes = true;

        [Tooltip("Render floating world-space distance badges in Game view.")]
        [SerializeField] private bool renderScreenBadges = true;

        [Header("Threshold Settings")]
        [Tooltip("Liquid spill threshold bubble radius (meters).")]
        [SerializeField] private float spillProximityRadius = 0.15f; // 15 cm

        [Tooltip("Knife edge proximity threshold (meters).")]
        [SerializeField] private float knifeEdgeThreshold = 0.05f;   // 5 cm

        [Header("Color Palette")]
        [SerializeField] private Color safeColor = new Color(0.1f, 0.9f, 0.4f, 0.8f);
        [SerializeField] private Color cautionColor = new Color(1.0f, 0.8f, 0.1f, 0.85f);
        [SerializeField] private Color criticalColor = new Color(1.0f, 0.15f, 0.15f, 0.95f);
        [SerializeField] private Color bubbleColor = new Color(0.2f, 0.6f, 1.0f, 0.25f);

        private Camera activeCamera;

        #region Unity Lifecycle

        private void OnEnable()
        {
            FindActiveCamera();
        }

        private void Update()
        {
            FindActiveCamera();
        }

        private void FindActiveCamera()
        {
            if (activeCamera == null || !activeCamera.gameObject.activeInHierarchy)
            {
                activeCamera = Camera.main ?? FindFirstObjectByType<Camera>();
            }
        }

        #endregion

        #region Gizmos & Spatial Vectors

        private void OnDrawGizmos()
        {
            AntiGravityTableRig table = FindFirstObjectByType<AntiGravityTableRig>();
            AntiGravityInteractable[] interactables = FindObjectsByType<AntiGravityInteractable>(FindObjectsSortMode.None);

            AntiGravityInteractable bottle = null;
            AntiGravityInteractable laptop = null;
            AntiGravityInteractable knife = null;
            AntiGravityInteractable drawer = null;
            AntiGravityInteractable cable = null;

            for (int i = 0; i < interactables.Length; i++)
            {
                var item = interactables[i];
                if (item == null) continue;
                string cls = item.EntityClass.ToLowerInvariant();

                if (cls == "bottle") bottle = item;
                else if (cls == "laptop") laptop = item;
                else if (cls == "knife") knife = item;
                else if (cls == "drawer") drawer = item;
                else if (cls == "cable") cable = item;
            }

            // 1. Proximity Spheres around Hazardous items
            if (renderProximityBubbles)
            {
                if (laptop != null)
                {
                    Gizmos.color = bubbleColor;
                    Gizmos.DrawWireSphere(laptop.transform.position, spillProximityRadius);
                }

                if (bottle != null)
                {
                    Gizmos.color = new Color(0.1f, 0.8f, 1f, 0.35f);
                    Gizmos.DrawWireSphere(bottle.transform.position, 0.08f);
                }

                if (knife != null)
                {
                    Gizmos.color = new Color(1.0f, 0.4f, 0.1f, 0.35f);
                    Gizmos.DrawWireSphere(knife.transform.position, knifeEdgeThreshold);
                }
            }

            // 2. Dynamic Connection Vector: Bottle <-> Laptop (Spill Hazard)
            if (renderConnectionVectors && bottle != null && laptop != null)
            {
                Vector3 bPos = bottle.transform.position;
                Vector3 lPos = laptop.transform.position;
                float dist = Vector3.Distance(bPos, lPos);

                Color vecColor = dist <= spillProximityRadius ? criticalColor : (dist <= 0.30f ? cautionColor : safeColor);
                Gizmos.color = vecColor;

                // Draw vector line
                Gizmos.DrawLine(bPos, lPos);

                // Draw end caps
                Gizmos.DrawSphere(bPos, 0.015f);
                Gizmos.DrawSphere(lPos, 0.015f);

                // Draw animated or pulsing pulse indicator when critical
                if (dist <= spillProximityRadius)
                {
                    float pulse = 0.03f + 0.015f * Mathf.Sin(Time.time * 10f);
                    Gizmos.DrawWireSphere(Vector3.Lerp(bPos, lPos, 0.5f), pulse);
                }
            }

            // 3. Dynamic Connection Vector: Knife <-> Table Edge (Fall Hazard)
            if (renderConnectionVectors && knife != null && table != null)
            {
                Vector3 kPos = knife.transform.position;
                Vector3 nearestEdge = table.GetNearestPerimeterPoint(kPos);
                float edgeDist = Vector3.Distance(kPos, nearestEdge);

                Color edgeVecColor = edgeDist <= knifeEdgeThreshold ? criticalColor : (edgeDist <= 0.12f ? cautionColor : safeColor);
                Gizmos.color = edgeVecColor;

                Gizmos.DrawLine(kPos, nearestEdge);
                Gizmos.DrawSphere(nearestEdge, 0.018f);

                // Draw danger strip on table edge near knife
                if (edgeDist <= knifeEdgeThreshold)
                {
                    Gizmos.color = criticalColor;
                    Vector3 tangent = Vector3.Cross(table.SurfaceNormal, (kPos - nearestEdge).normalized).normalized * 0.10f;
                    Gizmos.DrawLine(nearestEdge - tangent, nearestEdge + tangent);
                }
            }

            // 4. Drawer & Cable Obstruction Envelopes
            if (renderHazardEnvelopes)
            {
                if (drawer != null)
                {
                    Gizmos.color = new Color(1.0f, 0.6f, 0.0f, 0.4f);
                    Gizmos.DrawWireCube(drawer.WorldBounds.center, drawer.WorldBounds.size);
                }

                if (cable != null)
                {
                    Gizmos.color = new Color(1.0f, 0.9f, 0.0f, 0.4f);
                    Gizmos.DrawWireCube(cable.WorldBounds.center, cable.WorldBounds.size);
                }
            }
        }

        #endregion

        #region Game View Screen Badges

        private void OnGUI()
        {
            if (!renderScreenBadges || activeCamera == null) return;

            AntiGravityTableRig table = FindFirstObjectByType<AntiGravityTableRig>();
            AntiGravityInteractable[] interactables = FindObjectsByType<AntiGravityInteractable>(FindObjectsSortMode.None);

            AntiGravityInteractable bottle = null;
            AntiGravityInteractable laptop = null;
            AntiGravityInteractable knife = null;

            for (int i = 0; i < interactables.Length; i++)
            {
                var item = interactables[i];
                if (item == null) continue;
                string cls = item.EntityClass.ToLowerInvariant();
                if (cls == "bottle") bottle = item;
                else if (cls == "laptop") laptop = item;
                else if (cls == "knife") knife = item;
            }

            // Spill Vector Badge (Bottle <-> Laptop)
            if (bottle != null && laptop != null)
            {
                Vector3 midPoint = (bottle.transform.position + laptop.transform.position) * 0.5f;
                float dist = Vector3.Distance(bottle.transform.position, laptop.transform.position);
                RenderWorldBadge(midPoint, $"Liquid Clearance: {dist * 100f:F1} cm", dist <= spillProximityRadius, "SPILL RISK");
            }

            // Knife Edge Fall Badge
            if (knife != null && table != null)
            {
                Vector3 kPos = knife.transform.position;
                Vector3 edgePos = table.GetNearestPerimeterPoint(kPos);
                Vector3 midPoint = (kPos + edgePos) * 0.5f;
                float edgeDist = Vector3.Distance(kPos, edgePos);
                RenderWorldBadge(midPoint, $"Edge Clearance: {edgeDist * 100f:F1} cm", edgeDist <= knifeEdgeThreshold, "EDGE CUT RISK");
            }

            // Grabbed Item Hover Depth Badge
            for (int i = 0; i < interactables.Length; i++)
            {
                var item = interactables[i];
                if (item != null && item.IsGrabbed)
                {
                    Vector3 screenPos = activeCamera.WorldToScreenPoint(item.transform.position + Vector3.up * 0.12f);
                    if (screenPos.z > 0)
                    {
                        float depth = Vector3.Distance(activeCamera.transform.position, item.transform.position);
                        Rect badgeRect = new Rect(screenPos.x - 70, Screen.height - screenPos.y, 140, 24);
                        GUI.color = new Color(0.1f, 0.9f, 1.0f, 0.9f);
                        GUI.Box(badgeRect, $"Depth: {depth:F2} m");
                    }
                }
            }
        }

        private void RenderWorldBadge(Vector3 worldPosition, string text, bool isCritical, string criticalTag)
        {
            Vector3 screenPos = activeCamera.WorldToScreenPoint(worldPosition);
            if (screenPos.z <= 0) return; // Behind camera

            float w = isCritical ? 170 : 150;
            float h = isCritical ? 36 : 24;
            Rect rect = new Rect(screenPos.x - (w * 0.5f), Screen.height - screenPos.y - (h * 0.5f), w, h);

            GUI.color = isCritical ? new Color(1.0f, 0.2f, 0.2f, 0.95f) : new Color(0.2f, 0.2f, 0.2f, 0.8f);
            GUI.Box(rect, GUIContent.none);

            GUIStyle labelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 11,
                fontStyle = FontStyle.Bold
            };

            if (isCritical)
            {
                labelStyle.normal.textColor = Color.yellow;
                GUI.Label(new Rect(rect.x, rect.y + 1, rect.width, 16), $"⚠️ {criticalTag}!", labelStyle);
                labelStyle.normal.textColor = Color.white;
                GUI.Label(new Rect(rect.x, rect.y + 17, rect.width, 16), text, labelStyle);
            }
            else
            {
                labelStyle.normal.textColor = Color.white;
                GUI.Label(rect, text, labelStyle);
            }
        }

        #endregion
    }
}
