using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.RiskEngine;

namespace SafeSightAR.UI
{
    /// <summary>
    /// Renders 3D Spatial Holographic Overlay visualizers:
    /// 3D dynamic bounding brackets around high-risk object pairs, 
    /// glowing laser lines connecting hazard pairs, and surface hazard markers.
    /// </summary>
    public class ARHazardOverlay : MonoBehaviour
    {
        [Header("Visualization Settings")]
        [SerializeField] private Material laserLineMaterial;
        [SerializeField] private Color criticalColor = new Color(1.0f, 0.15f, 0.15f, 1.0f);
        [SerializeField] private Color warningColor = new Color(1.0f, 0.6f, 0.0f, 1.0f);
        [SerializeField] private float lineWidth = 0.02f;

        private List<LineRenderer> activeLaserLines = new List<LineRenderer>();

        private void Update()
        {
            if (RiskEvaluator.Instance == null) return;
            RenderHazardPairConnections(RiskEvaluator.Instance.ActiveAlerts);
        }

        private void RenderHazardPairConnections(List<HazardAlert> alerts)
        {
            // Clear or resize line pool
            int requiredLines = alerts != null ? alerts.Count : 0;

            while (activeLaserLines.Count < requiredLines)
            {
                GameObject lineObj = new GameObject($"HazardLaser_{activeLaserLines.Count}");
                lineObj.transform.SetParent(transform);
                LineRenderer lr = lineObj.AddComponent<LineRenderer>();
                lr.startWidth = lineWidth;
                lr.endWidth = lineWidth;
                lr.positionCount = 2;
                lr.material = laserLineMaterial != null ? laserLineMaterial : new Material(Shader.Find("Sprites/Default"));
                activeLaserLines.Add(lr);
            }

            for (int i = 0; i < activeLaserLines.Count; i++)
            {
                if (i < requiredLines)
                {
                    var alert = alerts[i];
                    activeLaserLines[i].gameObject.SetActive(true);
                    activeLaserLines[i].SetPosition(0, alert.primaryWorldPos);
                    activeLaserLines[i].SetPosition(1, alert.secondaryWorldPos);

                    Color c = alert.severity == HazardSeverity.Critical ? criticalColor : warningColor;
                    activeLaserLines[i].startColor = c;
                    activeLaserLines[i].endColor = c;
                }
                else
                {
                    activeLaserLines[i].gameObject.SetActive(false);
                }
            }
        }
    }
}
