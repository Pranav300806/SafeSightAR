using System.Collections.Generic;
using UnityEngine;
using SafeSightAR.RiskEngine;

namespace SafeSightAR.UI
{
    /// <summary>
    /// User Interface HUD & AR Hazard Overlay Controller.
    /// Renders dynamic warning banners, risk gauges, contextual instruction cards,
    /// and generates spatial audio warning signals based on risk severity.
    /// </summary>
    public class HazardHUD : MonoBehaviour
    {
        [Header("Audio Alert Cues")]
        [SerializeField] private AudioSource audioSource;
        [SerializeField] private AudioClip criticalBeepClip;
        [SerializeField] private AudioClip warningBeepClip;

        private List<HazardAlert> currentAlerts = new List<HazardAlert>();
        private float nextAudioBeepTime = 0.0f;
        private GUIStyle headerStyle;
        private GUIStyle cardStyle;
        private GUIStyle iconStyle;

        private void Start()
        {
            if (audioSource == null) audioSource = GetComponent<AudioSource>();
            if (RiskEvaluator.Instance != null)
            {
                RiskEvaluator.Instance.OnHazardAlertsUpdated += HandleAlertsUpdated;
            }
        }

        private void OnDestroy()
        {
            if (RiskEvaluator.Instance != null)
            {
                RiskEvaluator.Instance.OnHazardAlertsUpdated -= HandleAlertsUpdated;
            }
        }

        private void HandleAlertsUpdated(List<HazardAlert> alerts)
        {
            currentAlerts = alerts ?? new List<HazardAlert>();
            TriggerAudioFeedback();
        }

        private void TriggerAudioFeedback()
        {
            if (currentAlerts.Count == 0) return;
            if (Time.time < nextAudioBeepTime) return;

            bool hasCritical = currentAlerts.Exists(a => a.severity == HazardSeverity.Critical);

            if (audioSource != null)
            {
                AudioClip clipToPlay = hasCritical ? criticalBeepClip : warningBeepClip;
                if (clipToPlay != null)
                {
                    audioSource.PlayOneShot(clipToPlay);
                }
            }

            // Frequency rate: Critical beeps every 0.4s, Medium every 1.0s
            nextAudioBeepTime = Time.time + (hasCritical ? 0.4f : 1.0f);
        }

        private void OnGUI()
        {
            InitStyles();

            // Render Header Banner
            DrawHeaderBanner();

            // Render Active Hazard Alert Cards
            DrawHazardCards();
        }

        private void InitStyles()
        {
            if (headerStyle == null)
            {
                headerStyle = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 18,
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = Color.white }
                };

                cardStyle = new GUIStyle(GUI.skin.box)
                {
                    padding = new RectOffset(10, 10, 10, 10),
                    alignment = TextAnchor.UpperLeft
                };
            }
        }

        private void DrawHeaderBanner()
        {
            float w = 420;
            float h = 45;
            float x = (Screen.width - w) * 0.5f;
            float y = 15;

            Color statusColor = currentAlerts.Count == 0 
                ? new Color(0.0f, 0.6f, 0.3f, 0.85f) 
                : new Color(0.85f, 0.15f, 0.15f, 0.9f);

            GUI.color = statusColor;
            GUI.Box(new Rect(x, y, w, h), "");

            GUI.color = Color.white;
            string statusText = currentAlerts.Count == 0
                ? "🛡️ SAFESIGHT AR: ENVIRONMENT SECURE"
                : $"⚠️ SAFESIGHT AR: {currentAlerts.Count} HAZARD(S) DETECTED";

            GUI.Label(new Rect(x, y + 10, w, 25), statusText, headerStyle);
        }

        private void DrawHazardCards()
        {
            if (currentAlerts.Count == 0) return;

            float cardW = 380;
            float cardH = 90;
            float startX = Screen.width - cardW - 20;
            float startY = 70;

            for (int i = 0; i < currentAlerts.Count; i++)
            {
                var alert = currentAlerts[i];
                Rect cardRect = new Rect(startX, startY + (i * (cardH + 10)), cardW, cardH);

                Color cardBg = alert.severity == HazardSeverity.Critical
                    ? new Color(0.9f, 0.1f, 0.1f, 0.88f)
                    : new Color(0.9f, 0.55f, 0.0f, 0.88f);

                GUI.color = cardBg;
                GUI.Box(cardRect, "");

                GUI.color = Color.white;
                GUILayout.BeginArea(cardRect);
                GUILayout.Label($"<b>[{alert.severity.ToString().ToUpper()}] {alert.rule.ruleName}</b>", GUI.skin.label);
                GUILayout.Label($"Metric: <b>{(alert.currentDistanceMeters * 100f):F1} cm</b> | Persistent: {alert.persistenceTime:F1}s", GUI.skin.label);
                GUILayout.Label($"💡 <i>{alert.rule.actionRecommendation}</i>", GUI.skin.label);
                GUILayout.EndArea();
            }
        }
    }
}
