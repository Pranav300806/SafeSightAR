using System.Collections.Generic;
using UnityEngine;

namespace SafeSightAR.Vision
{
    /// <summary>
    /// Renders 2D object detection bounding boxes, labels, and confidence tags 
    /// over the camera feed HUD view.
    /// </summary>
    public class BoundingBoxVisualizer : MonoBehaviour
    {
        [Header("UI Style Settings")]
        [SerializeField] private Color bottleColor = new Color(0.1f, 0.8f, 1.0f, 0.9f);
        [SerializeField] private Color laptopColor = new Color(0.2f, 1.0f, 0.4f, 0.9f);
        [SerializeField] private Color knifeColor = new Color(1.0f, 0.2f, 0.2f, 0.9f);
        [SerializeField] private Color drawerColor = new Color(1.0f, 0.7f, 0.0f, 0.9f);
        [SerializeField] private Color defaultColor = new Color(0.8f, 0.8f, 0.8f, 0.9f);
        [SerializeField] private int borderThickness = 3;
        [SerializeField] private bool showConfidence = true;

        private List<DetectionResult> activeDetections = new List<DetectionResult>();
        private Texture2D borderTexture;
        private GUIStyle labelStyle;

        private void Awake()
        {
            borderTexture = new Texture2D(1, 1);
            borderTexture.SetPixel(0, 0, Color.white);
            borderTexture.Apply();
        }

        public void UpdateDetections(List<DetectionResult> detections)
        {
            activeDetections = detections ?? new List<DetectionResult>();
        }

        private void OnGUI()
        {
            if (activeDetections == null || activeDetections.Count == 0) return;

            InitStyles();

            foreach (var det in activeDetections)
            {
                Color classColor = GetColorForClass(det.label);
                DrawOutline(det.rect, classColor, borderThickness);

                // Draw Label Box
                string labelText = showConfidence 
                    ? $"{det.label.ToUpper()} {(det.confidence * 100f):F0}%" 
                    : det.label.ToUpper();

                Vector2 size = labelStyle.CalcSize(new GUIContent(labelText));
                Rect labelRect = new Rect(det.rect.x, det.rect.y - size.y - 4, size.x + 12, size.y + 4);

                GUI.color = classColor;
                GUI.DrawTexture(labelRect, borderTexture);

                GUI.color = Color.black;
                GUI.Label(new Rect(labelRect.x + 6, labelRect.y + 2, size.x, size.y), labelText, labelStyle);
            }
        }

        private void InitStyles()
        {
            if (labelStyle == null)
            {
                labelStyle = new GUIStyle(GUI.skin.label)
                {
                    fontSize = 12,
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleLeft
                };
            }
        }

        private Color GetColorForClass(string label)
        {
            switch (label.ToLower())
            {
                case "bottle": return bottleColor;
                case "laptop": return laptopColor;
                case "knife": return knifeColor;
                case "drawer": return drawerColor;
                default: return defaultColor;
            }
        }

        private void DrawOutline(Rect rect, Color color, int thickness)
        {
            GUI.color = color;
            // Top border
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width, thickness), borderTexture);
            // Bottom border
            GUI.DrawTexture(new Rect(rect.x, rect.y + rect.height - thickness, rect.width, thickness), borderTexture);
            // Left border
            GUI.DrawTexture(new Rect(rect.x, rect.y, thickness, rect.height), borderTexture);
            // Right border
            GUI.DrawTexture(new Rect(rect.x + rect.width - thickness, rect.y, thickness, rect.height), borderTexture);
            GUI.color = Color.white;
        }
    }
}
