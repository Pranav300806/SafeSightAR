Shader "SafeSightAR/HazardHighlight"
{
    Properties
    {
        _MainColor ("Hazard Glow Color", Color) = (1.0, 0.2, 0.2, 1.0)
        _RimColor ("Rim Glow Color", Color) = (1.0, 0.8, 0.2, 1.0)
        _RimPower ("Rim Power", Range(0.5, 8.0)) = 3.0
        _PulseSpeed ("Pulse Speed Rate", Range(0.5, 10.0)) = 3.5
        _GridScale ("Grid Pattern Scale", Float) = 20.0
    }
    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Transparent" }
        LOD 200
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float3 normal : TEXCOORD0;
                float3 viewDir : TEXCOORD1;
                float2 uv : TEXCOORD2;
            };

            fixed4 _MainColor;
            fixed4 _RimColor;
            float _RimPower;
            float _PulseSpeed;
            float _GridScale;

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.normal = UnityObjectToWorldNormal(v.normal);
                
                float3 worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
                o.viewDir = normalize(_WorldSpaceCameraPos - worldPos);
                o.uv = v.uv;
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                // Rim Lighting calculation
                float NdotV = 1.0 - saturate(dot(i.normal, i.viewDir));
                float rim = pow(NdotV, _RimPower);

                // Animated Pulse Signal
                float pulse = 0.5 + 0.5 * sin(_Time.y * _PulseSpeed);

                // Holographic Grid Scanline Pattern
                float grid = frac(i.uv.y * _GridScale + _Time.y * 0.5);
                float lineMask = step(0.85, grid);

                fixed3 finalColor = lerp(_MainColor.rgb, _RimColor.rgb, rim) + (lineMask * 0.3);
                float finalAlpha = saturate(rim * 1.5 + (pulse * 0.3) + (lineMask * 0.4));

                return fixed4(finalColor * (1.0 + pulse * 0.5), finalAlpha);
            }
            ENDCG
        }
    }
    FallBack "Transparent/Cutout/VertexLit"
}
