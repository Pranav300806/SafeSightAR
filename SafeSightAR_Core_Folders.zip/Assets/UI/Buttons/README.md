# SmartSpace AR - UI Buttons Directory

This directory stores reusable button assets and prefabs:
- `CatalogItemButton.prefab`: Item card button with icon, label, and price badge
- `ActionControlButton.prefab`: Circular floating action buttons for Rotate, Scale, and Delete
