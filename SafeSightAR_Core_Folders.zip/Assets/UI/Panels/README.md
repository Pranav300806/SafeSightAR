# SmartSpace AR - UI Panels Directory

This directory stores UI panel assets and prefabs:
- `TopBarPanel.prefab`: App title ("SMARTSPACE AR") + Mode toggle (AR / Simulation)
- `CatalogPanel.prefab`: Bottom horizontal scroll view containing furniture item cards
- `ActionBarPanel.prefab`: Floating action bar ([Rotate 45°], [Scale +/-], [Delete], [Done])
